/* Used in toolchain_features.cmake */
#pragma GCC system_header
