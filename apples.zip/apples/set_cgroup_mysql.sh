#!/bin/bash
PID=`ps aux | grep mysqld | grep -v grep | awk '{print $2}'`
#PID="5"
echo $PID > /cgroup2/cg1/cgroup.procs
#echo ${PID} > file1.txt
cat /cgroup2/cg1/cgroup.threads
