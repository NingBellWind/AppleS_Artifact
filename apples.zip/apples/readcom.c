/*
 The program readcom is app-level monitor;
 *
 *  Ning Li <leening0810@163.com> <ning.li@uta.edu>
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/shm.h>  
#include <sys/timeb.h>
#include <math.h>
#include <assert.h>
//#include <engine.h>
#include <sys/time.h>

/**************************************2015.9.27   application-level performance statistics*******************************/
#include "app_perf.h"
/**************************************2015.9.27   application-level performance statistics*******************************/

char ** alloc_arr(int x,int y)
{
	if(x<=0||y<=0) return 0;
	char **ptr = (char**)malloc(x * sizeof(char*));
	int i=0;
	for(i=0;i<x;i++)
	{
		ptr[i] = (char*)malloc(y * sizeof(char));
		memset(ptr[i],0,sizeof(char)*y);
	}
	return ptr;
}

int del_arr(char ** ptr,int x,int y)
{
	if(ptr==0||x<=0||y<=0) return 0;
	int i=0;
	for(i=0;i<x;i++)
	{
		free(ptr[i]);
		ptr[i] = 0;
	}
	free(ptr);
	ptr = 0;
	return 1;
}

/*****************************UDP client 2015.1.22***********************************/
#define closesocket close

//UDP�˿ڣ�8001��
#define UDP_PORT 8003

#define UDP_IP   239.0.1.1
#define UDP_BUFF_MAX_SIZE 1024
#define UDP_IP_LEN 16
#define UDP_SEND_MAX_LEN 1024*1.5


#define CLT_UDP_PORT 8003
#define MAX_VMM_NUM 10

#include "common.h"

#define MAX_NAME_LEN	72

#define MAX_SPLIT_LEN 32

#define UINTERFACE	"/root/"DIR"/bslo_interface_log1.txt"

FILE * istream = NULL;
int i_handle = 0;

struct sockaddr_in	m_sockaddr_loc_c1[MAX_VMM_NUM];
int m_sock_loc_c1[MAX_VMM_NUM];

char m_pBuffer[UDP_BUFF_MAX_SIZE];
struct sockaddr_in	m_sockaddr_loc[MAX_VMM_NUM];
int m_sock_loc[MAX_VMM_NUM];

int udpclt(char * udp_ip, int idx)
{
	if(udp_ip==NULL) return -1;
	memset(&m_sockaddr_loc_c1[idx], 0, sizeof(m_sockaddr_loc_c1[idx]));
	m_sockaddr_loc_c1[idx].sin_family = AF_INET;
	int port = CLT_UDP_PORT + idx;
	m_sockaddr_loc_c1[idx].sin_port = htons(port);
	printf("\nClient udp_ip:%s \n", udp_ip);
	m_sockaddr_loc_c1[idx].sin_addr.s_addr = inet_addr(udp_ip);
	if((m_sock_loc_c1[idx] = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
	{
		perror("Error in create socket!");
		return 0;
	}
	return 1;
}

int UdpInit(char * udp_ip, int udp_port, int idx)
{
	int ret_flag = 1;
	if(udp_port<=0 || udp_port>65535) return -1;

		memset(&m_sockaddr_loc[idx], 0, sizeof(m_sockaddr_loc[idx]));
		m_sockaddr_loc[idx].sin_family = AF_INET;
		m_sockaddr_loc[idx].sin_port = htons(udp_port);
		if(udp_ip!=NULL)
		{
			printf("\nudp_ip:%s \n", udp_ip);
			m_sockaddr_loc[idx].sin_addr.s_addr = inet_addr(udp_ip);
		}
		else
		{
			m_sockaddr_loc[idx].sin_addr.s_addr = INADDR_ANY;
		}
		printf("\nudp_port:%d \n", udp_port);
	if((m_sock_loc[idx] = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
	{
		perror("\nError in create socket!");
		return 0;
	}

	if(udp_ip==NULL)
	{
		if (bind(m_sock_loc[idx],(struct sockaddr *)&m_sockaddr_loc[idx],sizeof(m_sockaddr_loc[idx]))<0)
		{
				closesocket(m_sock_loc[idx]);
				printf("\nError wehn bind...");
				return 0;
		}
		printf("\n[%d] Binding is ok.", idx+1);
	}

     //   if(set_fl(m_sock_loc, O_NONBLOCK) < 0) {
      //      return 0;
       // }

	if(udp_ip!=NULL)
		printf("\nUDP sernder has initialized successfully��");
	else
		printf("\nUDP receiver has initialized successfully��");
	return ret_flag;
}

int UdpClose(int idx)
{
	int ret_flag = 1;
	shutdown(m_sock_loc[idx],2);
	closesocket(m_sock_loc[idx]);
	return ret_flag;
}

/*void ms_ret(int sig)
{
  struct timeval  t;
  t.tv_usec = 0;
  t.tv_sec = 0;
  select(1, 0, 0, 0, &t);
  return;
}

//FENG-090210 HEAD;
void sys_ms_sleep(int ms_num)
{
  struct timeval  t;
  int  status;
  sigset(SIGALRM, ms_ret);
  t.tv_usec = (ms_num % 1000) * 1000;
  t.tv_sec = ms_num / 1000;
  alarm(1);
  status = select(1, 0, 0, 0, &t);
  alarm(0);
  sigrelse(SIGALRM);
  return;
}*/

int IpCheck(char *address)
{
    char address_buf[20];
    memset(address_buf,0,20);
    if(address==0) return -1;
    int i=0,j=0,snum=0,slen=strlen(address),sval = 0;
    for(i=0;i<slen;i++)
	{
       if(address[i]!= '.' && address[i]!= '\0')
	   {
    	  if(address[i]<'0'||address[i]>'9') return -1;
          address_buf[j++] = address[i];
          if(i>=slen-1)
          {
        	  sval = atoi(address_buf);
        	  if(sval>255 || sval < 0)
        	     return -1;
        	  else
        		  snum++;
          }
       }
       else
	   {
    	  sval = atoi(address_buf);
          if(sval>255 || sval< 0)
            return -1;
          else
	      {
        	 memset(address_buf,0,20);
        	 snum++;
             j = 0;
          }
       }
    }
    if(snum==4) return 1;
    else return -1;
}

int udpcltsend(char * send_str,int send_len, int idx)
{
	 int rcode;
	  rcode = 0;
	  //print;
	  printf("\nClient[%d] Msg len = %d %s\n",idx, send_len,send_str);

	  rcode = sendto(m_sock_loc_c1[idx], send_str,send_len, 0, (struct sockaddr*)&(m_sockaddr_loc_c1[idx]),sizeof(struct sockaddr_in));
	  if(rcode < 0) {
		  printf("\nsend error = %d",rcode);
	  }
	  return rcode;
}

char x_ip_arr[5][32];
int x_ip = 0;
int x_id = 0;
int vx_num = 0;

/********************************2015.1.24  VM multi-VMM*********************************/
//x_ip is the combination of host_id + vm_id;


/********************************2015.1.24  VM multi-VMM*********************************/

int send_info(int info, int vr, int per, int slo)
{
	int ret = 1;

	int i=0;
	char str_info[128];
	memset(str_info,0,128);

	for(i=0;i<vx_num;i++)
	{
		//int iflag = udpclt(x_ip_arr[i]);
		int iflag = 1;

		if(iflag>0)
		{
			sprintf(str_info,"%d,%d,%d,%d,%d,%d", x_id, x_ip, info, vr, per, slo);
			udpcltsend(str_info, strlen(str_info), i);
			//sys_ms_sleep(100);
		}
	}
	return ret;
}

/**************************************2015.9.15   dd->latency_g input*******************************/
int xsend_f = 1;

int xsend_info(int info)
{
	int ret = 1;

	int i=0;
	int idx = vx_num-1;
	char str_info[128];
	memset(str_info,0,128);

	for(i=idx;i<vx_num;i++)
	{
		//int iflag = udpclt(x_ip_arr[i]);
		int iflag = 1;

		if(iflag>0)
		{
			if(xsend_f>0)
			{
				x_id = 1000 + x_id;
				xsend_f = 0;
			}
			sprintf(str_info,"%d,%d,%d", x_id,x_ip, info);
			udpcltsend(str_info, strlen(str_info), i);
			//sys_ms_sleep(100);
		}
	}
	return ret;
}

int open_interface()
{
	int i_ret = 1;
	istream = fopen(UINTERFACE,"r");

	if(istream==NULL)
	{
		printf("\nUtil_max cannot be read!\n");
		return 0;
	}

	i_handle = fileno(istream);

	return i_ret;
}

int last_ver = -1;

int get_interface_d(int * ver, float * thpt_target, float * thpt_present)
{
	int i_ret = 0;
	//int ver = 0;
	char line[128];
	memset(line, 0, 128);
	lseek(i_handle,0L,SEEK_SET);
	fgets(line, 128, istream);

	int x_i = sscanf(line, ",%d,%f,%f\n",ver, thpt_target, thpt_present);

	//if(*ver!=last_ver)
	{
		i_ret = *ver;
		last_ver = *ver;
		send_info((int) *thpt_target, (int) *thpt_present, 0, 0);
	}
	//else
	//printf( ",%d,%f,%f\n",*ver, *thpt_target, *thpt_present);

	return i_ret;
}

int main(int argc, char *argv[])
{
	if(open_interface()<=0)
		printf("COM_READ fails to read the file bslo_interface_log1.txt!\n");

	printf(">>> COM_READ starts.......\n");

	//Read configuration;
	//percentile;
	unsigned int per = 0;
	//latency;
	unsigned int lat = 100;
	//the id of VM/container/application;
	unsigned int ip = 1;
	//the id of host;
	unsigned int id = 1;
	//the number of hosts that are required to communicate with;
	unsigned int n = 3;
	//the ip address array of the aforementioned host; 
	//unsigned int ip_arr[MAX_HOST_CON];
	char ** ip_arr = alloc_arr(MAX_HOST_CON, MAX_SPLIT_LEN);

	char x_ip_arr[5][32];
	//int x_ip = 0;
	//int x_id = 0;
	//int vx_num = 0;

	int r_f = APOI_config(&per, 
						  &lat, 
						  &ip, 
						  &id, 
						  &n, 
						  ip_arr);

	if(r_f<=0)
	{
		printf("\n READCOM APOI_config failure...exit...\n");
		return 0;
	}

	x_ip = ip;
	x_id = id;
	vx_num = n;

	int i=0;

	for(i=0;i<vx_num;i++)
	{
		sprintf(x_ip_arr[i],"%s",ip_arr[i]);
	}
	
	del_arr(ip_arr,MAX_HOST_CON, MAX_SPLIT_LEN);
	ip_arr = NULL;

	if(vx_num<=0)
	{
		printf("\nREADCOM has no back-end server!");
		return 0;
	}

	//printf("\nVQC enforces the %f th percentile latency SLO: %d <<<\n", tail_slo_num[0], tail_slo[0]);

	printf("\nConnect to server num(%d)  ip(%s) with vm id (%d) on the host with id (%d)", vx_num, x_ip_arr[0], x_ip, x_id);

	for(i=0; i<vx_num; i++)
	{
		/*int port = CLT_UDP_PORT + i;
		int i_f = UdpInit(0,port,i);
		if(i_f<=0)
		{
			printf("\nREADCOM CLT_UDP_PORT initialization failure!");
			return 0;
		}*/
		int iflag = udpclt(x_ip_arr[i],i);
	}

    int ver=0;
	float thpt_target = 0, thpt_present = 0;

	//while loop for read and communicate with the remote server;
	while(1){
		get_interface_d(&ver, &thpt_target, &thpt_present);
		sys_ms_sleep(1000);
	}
	
	return 0;
}
