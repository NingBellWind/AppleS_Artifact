#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/utsname.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/shm.h>  
#include <sys/timeb.h>
#include <math.h>
#include <assert.h>
//#include <engine.h>
#include <sys/time.h>

#include "shm.h"
#include "queue.h"

int main(int argc, char *argv[])
{
	/*int i_ret = shm_init();

	int depth = 5;

	if(i_ret<0)
	{
		printf("\nShare memory allocation failed!\n");
		return 0;
	}

	while(1)
	{
		//int depth =  get_diskstats_io("xvdb1");

		depth++;

		shared->value[0] = depth;

		printf("\nSetting dev qlen = %d\n", shared->value[0]);

		usleep(1000);
	}*/

	io_util_open(DEV);

	 //2019.8.29 Clear history data;
     open_his_sig(0);

	while(1)
	{
		get_io_util(DEV);
		usleep(1000000);
	}
	
	return 0;
}
