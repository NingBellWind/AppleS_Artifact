#ifndef TIMESTA_H
#define TIMESTA_H

#include <unistd.h>
#include <math.h>
#include <sys/time.h>
#include <time.h>
#include "common.h"
#include "rec.h"
#include "tail.h"

//Give each user throughput performance;
get_user_throughput()
{
	int i=0;
	if(data_rec_f<=0) return 0;
	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM) return 0;
	//experienced period of time (ms);
	long long period = mtime_since_now(&estart);
	if(period <= 500) return 0;

	double tsum = 0;

	for(i=1;i<fd_id_ptr;i++){
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
			//the total number of latency violations out of all the requests;
					double thpt_n = (1000.0 * app_req_tot[i])/(double)period;
					app_pnt_arr[i] = thpt_n;
					tsum += thpt_n;
	    }
    }

	tot_throughput = tsum;
}

//2020.2.4; Give the user with worst throughput performance;
int get_hard_user()
{
	int i_ret = 0, i=0;
	if(data_rec_f<=0) return 0;
	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM) return 0;
	//experienced period of time (ms);
	long long period = mtime_since_now(&estart);
	if(period <= 500) return 0;
	
	double klmt = 9999999.0;

	for(i=1;i<fd_id_ptr;i++){
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
			//the total number of latency violations out of all the requests;
					double thpt_n = (1000.0 * app_req_tot[i])/(double)period;
                    //////////////////////////////////////////////////////////////
					app_pnt_arr[i] = thpt_n;
					//////////////////////////////////////////////////////////////

				if( !is_user_priviliged(i))
				 if(app_thptslo_arr[i] > 0.1){
					double kratio = 100.0 * (thpt_n - app_thptslo_arr[i])/app_thptslo_arr[i];
					if(kratio < klmt){
						klmt = kratio;
						i_ret = i;
					}
			  }
		}
	}
	//////////////////////////////////////////////////////////////
	pnt_num_t = i_ret;
	i_ret = 0;
	//////////////////////////////////////////////////////////////
	return i_ret;
}

//Initilization for the struct flow_id_u;
void init_flow_arr()
{
	int i=0;
	memset(flow_id_arr, 0, MAX_FD_NUM *  sizeof(struct  flow_id_u));

    //For all the network links in control; //1/24/2019;
	memset(net_id_arr, 0, MAX_FD_NUM *  sizeof(struct  net_id_u));
	memset(net_id_list, 0, MAX_FD_VAL * sizeof(short));

	memset(req_buf_arr, 0, MAX_FD_NUM *  sizeof(struct  req_buf));

    /*************************************2018.11.5**************************************/
	//gang ID groups;  /11/5/2018;
    memset(gang_id_arr, 0, MAX_GANG_NUM * MAX_GANG_MEM * sizeof(int));
    memset(gang_nr_arr, 0, MAX_GANG_NUM * sizeof(int));

	//Distinct file names;  /11/5/2018;
	memset(dist_file_name, 0, MAX_DIST_FNUM * MAX_FNAME_LEN);
	memset(file_id_list, 0, MAX_FD_VAL * sizeof(short));

	// The critical resources under control;  /11/5/2018;
	memset(res_str_arr, 0, MAX_RES_NUM * MAX_FNAME_LEN);
	/*************************************2018.11.5**************************************/

	for(i=0;i<MAX_FD_NUM;i++)
	{
		//for fio read 128KB 50 threads;
		flow_id_arr[i].throughput_slo = 16;

		//for fio read 4KB 50 threads;
		//flow_id_arr[i].throughput_slo = 2000;

		//for fio read 32KB 50 threads;
		//flow_id_arr[i].throughput_slo = 180;

         //for fio read 4KB 50 threads; us;//8/24/2018;
		flow_id_arr[i].tail_slo = 100000;

		  //for fio read 4KB 50 threads; us;//8/24/2018;
		flow_id_arr[i].head_slo = 30;

		//for fio write 128KB 50 threads;
		//flow_id_arr[i].throughput_slo = 120;

		//2018.9.7 initialize P ratio and I ratio;
		flow_id_arr[i].proportional_ratio = 100;

		flow_id_arr[i].integral_ratio = 0;
		
		//the times for standard I/O delay unit; 1/22/2020;
		flow_id_arr[i].times_delay = 1;

		//the ratio of waiting time; 4/18/2020;
		flow_id_arr[i].wt_ratio = 5;
	}
}

//Get outstanding requests of all the threads; 2019.10.3;
int get_outstanding()
{
	 int out_io = 0, i = 0;
	 for(i=1;i<=fd_id_ptr;i++)
	{
		 //get outstanding I/Os; 2019.2.27;
		 if(flow_id_arr[i].sched_avoid_f == 2)
			  out_io +=  flow_id_arr[i].head_num;
	}
	return out_io;
}

//Get most urgent reserved requests of all the threads; 2019.10.3;
int active_io = 0;
int px_num = 500;
int p_idx = 0;

int get_clock(int id)
{
	 int i_ret = 0, i = 0;
	 unsigned long long tdiff = 0;
	 struct timeval t;
	 sc_gettime(&t);

	 //return id;

	 int r_tag = 0;
	 int l_tag = 0;
	 int p_tag = 0;

	 int r_min = 999999;
	 int l_min = 999999;
	 int p_min = 999999;
	 int r_id = 0;
	 int l_id = 0;
	 int p_id = 0;

	  if(flow_id_arr[id].last_tv.tv_sec==0)
			 return id;

	// for(i=1;i<=fd_id_ptr;i++)
	 for(i=id;i<=id;i++)
	{
		 //mClock logic; 2019.10.3;
		 if(flow_id_arr[i].sched_avoid_f == 2)
		{
			 if(flow_id_arr[i].throughput_slo>0)
				 r_tag = 1000/flow_id_arr[i].throughput_slo;
			 if(flow_id_arr[i].head_slo>0)
				 l_tag = 1000/flow_id_arr[i].head_slo;
			 if(flow_id_arr[i].proportional_ratio>0)
				 p_tag = 1000/flow_id_arr[i].proportional_ratio;

			tdiff = mtime_since(&flow_id_arr[i].last_tv, &t);

			//if(tdiff<0) return i;

			if(r_tag - tdiff - flow_id_arr[i].integral_ratio  < r_min)
			{
				r_min = r_tag - tdiff - flow_id_arr[i].integral_ratio;
				r_id = i;
				flow_id_arr[i].integral_ratio = 0;
			}

			if(l_tag - tdiff  < l_min)
			{
				l_min = l_tag - tdiff;
				l_id = i;
			}

			if(p_tag - tdiff  < p_min)
			{
				p_min = p_tag - tdiff;
				p_id = i;
			}
		}
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/*if(p_idx++<px_num)
	{
		char str_line[32];
		sprintf(str_line, ">>> r_min[%4d]:  %8d   t1:[%8d, %8d]   t2:[%8d, %8d]\n", id, r_min, flow_id_arr[i].last_tv.tv_sec, flow_id_arr[i].last_tv.tv_usec, t.tv_sec, t.tv_usec);
		fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
		fflush(wstream_mem[0]);
	}*/
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    if(r_min <= 0)
		i_ret = r_id;
	else
	{
		//Let E�� be the set of requests with L tag �� t
		if(l_min<=0 || active_io<=0)
		{
			i_ret = p_id;
			flow_id_arr[p_id].integral_ratio += r_tag;
		}
	}

	return i_ret;
}

//mclock algorithm ; 2019.10.3;
int mclock(int id)
{
	int active_io = get_outstanding();
	//if(active_io > thread_con) return 0;

	//Let E be the set of requests with R tag �� t;
	int oid = get_clock(id);

	if(oid==id)
		return 1;
	return 0;
}

//Update the sleep time required for each I/O flow system call delay;
int update_sleep_time(int idx)
{
	int i_ret = 1;

	if(idx < 0 || idx >=MAX_FD_NUM)
		return -1;

		 ////////////////////////////////////////////////////////////////////////////////////////////////////
	   /* if(idx == 1)
		{
			char str_line[32];
			sprintf(str_line,"idx = %8d  it_val = %8d  slo = %6d\n", idx, flow_id_arr[idx].it_val, flow_id_arr[idx].throughput_slo);
			fwrite(str_line,1,strlen(str_line),wstream_cmd[0]);
			fflush(wstream_cmd[0]);
		}*/
		 ////////////////////////////////////////////////////////////////////////////////////////////////////

	if(flow_id_arr[idx].throughput_slo<=0)
	{
		flow_id_arr[idx].sleep_time = 0;
		return 0;
	}

	int usec_time = 1000000;
	//int s_time = usec_time/flow_id_arr[idx].throughput_slo;
	 //The central throughput target;//8/26/2018;
	 //central_throughput_slo = 200; //9/7/2018 for test 4kB RR;
	int s_time = usec_time/(central_throughput_slo+1);

    if(flow_id_arr[idx].it_val<=0)
	{
		flow_id_arr[idx].sleep_time = 0;
	}
	else
	{
		int kv = s_time - flow_id_arr[idx].it_val;

		//2018.9.7 adding PI control for coordinating sleep time;
		//flow_id_arr[idx].sleep_time = kv;
		flow_id_arr[idx].integral_sleep_time += kv;

		flow_id_arr[idx].sleep_time = (flow_id_arr[idx].proportional_ratio * kv + flow_id_arr[idx].integral_ratio * flow_id_arr[idx].integral_sleep_time)/1000;

		int max_sleep_time = 200000;

		if(flow_id_arr[idx].throughput_val > 0)
		{
			//Not exceeding the 100 percent of the average I/O delay;
			//max_sleep_time = 1000000/flow_id_arr[idx].throughput_slo;
		}

		if(flow_id_arr[idx].sleep_time > max_sleep_time)
			flow_id_arr[idx].sleep_time = max_sleep_time;

         ////////////////////////////////////////////////////////////////////////////////////////////////////
		/*char str_line[32];
		sprintf(str_line,"s_time = %8d  it_val = %8d\n", s_time, flow_id_arr[idx].it_val);
		fwrite(str_line,1,strlen(str_line),wstream_cmd[0]);
	    fflush(wstream_cmd[0]);*/
		 ////////////////////////////////////////////////////////////////////////////////////////////////////
	}

	return i_ret;
}

//Tell if it is in the congestion sleep state;  //8/21/2018;
int is_congestion_sleep()
{
	int i_ret = 0;
	int i=0;
	for(i=1;i<=fd_id_ptr;i++)
	{
			if(flow_id_arr[fd_id_map[fd_id_list[i]]].state==1)
		   {
				 i_ret = 1;
				 break;
		   }
	}
	if(i_ret == 0)
		alarm_congestion = 0;
	return i_ret;
}

// the fastest K I/O threads; //8/21/2018;
int fast_k_threads_throttling()
{
	int i_ret = 1;
	int i=0, j=0;
	//Choose an appropriate k;
	int k = fd_id_ptr/8;

	if(k > 2 * core_num)
		k = 2 * core_num;
	else if(k<1)
		k = 1;

	int v_arr[MAX_FD_NUM];
	int v_brr[MAX_FD_NUM];
	int v_idx[MAX_FD_NUM];
	int v_ave = 0;
	//The number of running thread;
	int v_num = 0;

	memset(v_arr, 0, MAX_FD_NUM * sizeof(int));
	memset(v_idx, 0, MAX_FD_NUM * sizeof(int));

	for(i=1;i<=fd_id_ptr;i++)
	{
		int idx_val = fd_id_map[fd_id_list[i]];
		v_idx[i] = idx_val;
		v_brr[i] = flow_id_arr[v_idx[i]].cs_num;
		v_arr[i] = flow_id_arr[v_idx[i]].cs_num_all;
		//flow_id_arr[v_idx[i]].cs_sleep_time = 0;
		
		//The basic idea is to tell if it the IO intensive threads under controlling;
		if( v_arr[i]>0
	  && v_brr[i]>CTL_Q_NUM/(5*fd_id_ptr))
		{
			v_ave += v_arr[i];
			v_num++;
		}
	}

   if(v_num>fd_id_ptr/5)
		v_ave /= v_num;
   else
	   return 0;

   if(v_ave<=0)
	   v_ave = 1;

	 ////////////////////////////////////////////////////////////////////////////////////////////////////
	 /*    if(1)
		{
			char str_line[2048];
			char p_s[32];

			sprintf(str_line,"AAA[vn:%04d,va:%04d]",v_num,v_ave);

			for(i=1;i<=fd_id_ptr;i++)
	       {
				sprintf(p_s,"(%08d,%08d);", v_arr[i], flow_id_arr[v_idx[i]].cs_sleep_time);
				strcat(str_line, p_s);
		   }
		   strcat(str_line,"\n");
			fwrite(str_line,1,strlen(str_line),wstream_rec[0]);
			fflush(wstream_rec[0]);
		}*/
		 ////////////////////////////////////////////////////////////////////////////////////////////////////

    //Quick sorting;  
	quick_sort(v_arr, v_idx, 1,fd_id_ptr) ;

	int base = v_num*10;

	for(i=1;i<=k;i++)
	//for(i=1;i<=1;i++)
	{
		flow_id_arr[v_idx[i]].state = 1;
		//flow_id_arr[v_idx[i]].cs_sleep_time = (IT_SLEEP *  (flow_id_arr[v_idx[i]].cs_num_all - v_ave)) / base;
		flow_id_arr[v_idx[i]].cs_sleep_time = IT_SLEEP *  10 * (k - i + 1);
	}

	 ////////////////////////////////////////////////////////////////////////////////////////////////////
	     if(1)
		{
		char str_line[2048];
			char p_s[64];

			sprintf(str_line,"BBB[vn:%04d,va:%04d]",v_num,v_ave);

			for(i=1;i<=fd_id_ptr;i++)
	       {
				sprintf(p_s," (<%04d>  %010d,%010d);", flow_id_arr[v_idx[i]].id, v_arr[i], flow_id_arr[v_idx[i]].cs_sleep_time);
				strcat(str_line, p_s);
		   }
		   strcat(str_line,"\n");
			fwrite(str_line,1,strlen(str_line),wstream_rec[0]);
			fflush(wstream_rec[0]);
		}
		 ////////////////////////////////////////////////////////////////////////////////////////////////////

	return i_ret;
}

//Once the indication of congestion was detected, sleep; //8/21/2018;
int congestion_throttling_signal(int idx)
{
	int i_ret = 0;

	if( flow_id_arr[idx].last_it_val > 0)
		flow_id_arr[idx].ra = (double)flow_id_arr[idx].it_val/(double)flow_id_arr[idx].last_it_val;
    
	int usec_time = 1000000;

	if(flow_id_arr[idx].ra>=IT_LIMIT 
&& flow_id_arr[idx].it_val > 5 * usec_time/(2 * flow_id_arr[idx].throughput_slo))
	{
		int i=0;
		//Tell if it is in the congestion sleep state;  //8/21/2018;
        //if(!is_congestion_sleep())
		{
			//Congestion sleep for the fastest K I/O threads;
			for(i=1;i<=fd_id_ptr;i++)
			{
				flow_id_arr[fd_id_map[fd_id_list[i]]].state = 1;
			}
			i_ret = 1;
		}
	}

	return i_ret;
}

//congestion throttling; //8/21/2018;
void act_congestion_throttling(int fd_id, int idx)
{
	if(flow_id_arr[idx].state>0)
	{
		//flow_id_arr[idx].cs_num++;
		 ////////////////////////////////////////////////////////////////////////////////////////////////////
	     /* if(1)
		{
			char str_line[256];
			sprintf(str_line,"act_congestion_throttling: >>> fd_id = %04d  idx = %4d  it_val = %08d  cs_num = %04d  state = %04d\n", fd_id, idx, flow_id_arr[idx].it_val, flow_id_arr[idx].cs_num, flow_id_arr[idx].state);
			fwrite(str_line,1,strlen(str_line),wstream_rec[0]);
			fflush(wstream_rec[0]);
		}*/
		 ////////////////////////////////////////////////////////////////////////////////////////////////////
		usleep(flow_id_arr[idx].cs_sleep_time);
		flow_id_arr[idx].state = 0;
	}
}

//Clean visiting times; 8/21/2018;
void clean_visits_rec()
{
		int i=0;
		for(i=1;i<=fd_id_ptr;i++)
		{
				flow_id_arr[fd_id_map[fd_id_list[i]]].cs_num = 0;
				flow_id_arr[fd_id_map[fd_id_list[i]]].sta_times = 0;

				//The ave congestion time (us); //12/15/2018;
				flow_id_arr[fd_id_map[fd_id_list[i]]].cs_sleep_time = 0;
				flow_id_arr[fd_id_map[fd_id_list[i]]].sched_times = 0;
		}
		//app_cs_num = 0;
        //app_sta_times = 0;
}

//Clean long visiting times; 8/26/2018;
int integral_clear_num = 0;
void clean_long_visits_rec()
{
		int i=0;
		for(i=1;i<=fd_id_ptr;i++)
		{
				flow_id_arr[fd_id_map[fd_id_list[i]]].long_cs_num = 0;
				flow_id_arr[fd_id_map[fd_id_list[i]]].long_sta_times = 0;

				//The ave congestion time (us); //12/15/2018;
				//flow_id_arr[fd_id_map[fd_id_list[i]]].cs_sleep_time = 0;
				//flow_id_arr[fd_id_map[fd_id_list[i]]].sched_times = 0;
				
				//clear the integral part ; 9/7/2018;
				integral_clear_num++;
				if(integral_clear_num>CTL_I_NUM)
				{
					flow_id_arr[fd_id_map[fd_id_list[i]]].integral_sleep_time = 0;
					integral_clear_num = 0;
				}
		}
}

char ** alloc_arr(int x,int y)
{
	if(x<=0||y<=0) return 0;
	char **ptr = (char**)malloc(x * sizeof(char*));
	int i=0;
	for(i=0;i<x;i++)
	{
		ptr[i] = (char*)malloc(y * sizeof(char));
		memset(ptr[i],0,sizeof(char)*y);
	}
	return ptr;
}

int del_arr(char ** ptr,int x,int y)
{
	if(ptr==0||x<=0||y<=0) return 0;
	int i=0;
	for(i=0;i<x;i++)
	{
		free(ptr[i]);
		ptr[i] = 0;
	}
	free(ptr);
	ptr = 0;
	return 1;
}

int init_buf()
{
	memset(rec_buf_n, 0, MAX_FD_NUM *sizeof(int));
    memset(rec_buf_act_size, 0, MAX_FD_NUM *sizeof(int));
    memset(rec_buf_f, 0, MAX_FD_NUM *sizeof(int));
    
	//the maximum number of priviliged users; 2020.3.23;
	rec_buf_p = (char**) alloc_arr(MAX_PU_NUM, REC_BUF_SIZE);
	//rec_buf_p = (char**) alloc_arr(MAX_FD_NUM, REC_BUF_SIZE);
	if(rec_buf_p == NULL)
		return 0;
	return 1;
}

//Enforce thread recording at the last round if any 2018.12.8;
int enforce_record_que()
{
	int i_ret = 1;
    int idx=0;

	//Configure the functionality of recording all the requests to the file; 2020.5.1;
    if(!file_reqs) return 1;

	for(idx=1;idx<fd_id_ptr;idx++)
	{
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//char str[64];
		//sprintf(str, "\nB The %d th thread  [state: %d] [size: %d]\n",  idx,  rec_buf_f[idx-1], rec_buf_act_size[idx-1]);
		//fwrite(str,1,strlen(str),wstream_mem[0]);
		//fflush(wstream_mem[0]);
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		//if(is_active(fd_id_list[idx]
		if(is_active(fd_id_list[idx]) && is_user_priviliged(idx)>0
	 && rec_buf_f[idx-1]<2)
		{
			if(rec_buf_act_size[idx-1]>0)
			{
				fwrite(rec_buf_p[idx-1],1,rec_buf_act_size[idx-1],wstream_que[0]);
				fflush(wstream_que[0]);
				rec_buf_f[idx-1] = 2;
			}
		}
	}

	return i_ret;
}

//Recording buffer 2018.10.11
int record_que(char * buf, int idx)
{
	int i_ret = 1;
	int r_num = strlen(buf);

	//Configure the functionality of recording all the requests to the file; 2020.5.1;
    if(!file_reqs) return 1;

    //if(r_num<=0 || rec_buf_f[idx-1] == 2)
	if(r_num<=0 || rec_buf_f[idx-1] == 2 ||  is_user_priviliged(idx)<=0)
		return 0;

	if(rec_buf_f[idx-1] ==0)
	{
		memcpy(&rec_buf_p[idx-1][rec_buf_act_size[idx-1]],buf,r_num);
		rec_buf_act_size[idx-1] += r_num; 
		rec_buf_n[idx-1]++;
		rec_buf_f[idx-1] = 1;
	}
	else if(rec_buf_f[idx-1] == 1)
	{
         if(rec_buf_act_size[idx-1] < REC_BUF_SIZE-r_num 
	 && rec_buf_n[idx-1]<REC_BUF_NUM)
		{
			 memcpy(&rec_buf_p[idx-1][rec_buf_act_size[idx-1]],buf,r_num);
			 rec_buf_act_size[idx-1] += r_num; 
			 rec_buf_n[idx-1]++;
		}
		else
		{  
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//char str[64];
			//sprintf(str, "\nA The %d th thread  [state: %d] [size: %d]\n",  idx,  rec_buf_f[idx-1], rec_buf_act_size[idx-1]);
			//fwrite(str,1,strlen(str),wstream_mem[0]);
			//fflush(wstream_mem[0]);
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			//if(rec_buf_lock == idx)
			{
				fwrite(rec_buf_p[idx-1],1,rec_buf_act_size[idx-1],wstream_que[0]);
				fflush(wstream_que[0]);
				rec_buf_lock++;
				rec_buf_f[idx-1] = 2;
			}
		}
	}

	return i_ret;
}

//buffer the requests with the same address; 10/8/2018;
int buf_req_same_addr(int idx, long addr, long off, int thread_id)
{
	int i_ret = 1;

	if(idx < 0 || idx >=MAX_FD_NUM ||  is_user_priviliged(idx)<=0)
		return -1;

    //The previous request record has been flushed;
    if(req_buf_arr[idx].resp_time<=0)
	{
		req_buf_arr[idx].start_time_sec = flow_id_arr[idx].last_tv.tv_sec;
		req_buf_arr[idx].start_time_us = flow_id_arr[idx].last_tv.tv_usec;
		req_buf_arr[idx].req_addr = addr;
		req_buf_arr[idx].req_off = off;
		req_buf_arr[idx].thread_id = thread_id;
		req_buf_arr[idx].resp_time = 9999;
	}
	else
	{
		req_buf_arr[idx].resp_time = flow_id_arr[idx].it_val;
		/*req_buf_arr[idx].start_time_sec = flow_id_arr[idx].last_tv.tv_sec;
		req_buf_arr[idx].start_time_us = flow_id_arr[idx].last_tv.tv_usec;
		req_buf_arr[idx].req_addr = addr;
		req_buf_arr[idx].req_off = flow_id_arr[idx].last_it_val;
		req_buf_arr[idx].thread_id = idx;*/

		char f_str[128];
		sprintf(f_str," <%06d,%06d,%08d,0x%x,0x%x,%08d>\n"
		                     , req_buf_arr[idx].start_time_sec
							 , req_buf_arr[idx].start_time_us
							 , req_buf_arr[idx].thread_id
							 , req_buf_arr[idx].req_addr
							 , req_buf_arr[idx].req_off
							 , req_buf_arr[idx].resp_time);
		//fwrite(f_str,1,strlen(f_str),wstream_que[0]);
		//fflush(wstream_que[0]);

		//Recording buffer 2018.10.11
		record_que(f_str, idx);

		req_buf_arr[idx].start_time_sec = flow_id_arr[idx].last_tv.tv_sec;
		req_buf_arr[idx].start_time_us = flow_id_arr[idx].last_tv.tv_usec;
		req_buf_arr[idx].req_addr = addr;
		req_buf_arr[idx].req_off = off;
		req_buf_arr[idx].thread_id = thread_id;
	}

	return i_ret;
}

//Update the start times (us) required for each I/O flow system call delay;
int update_st_val(int idx, int iosize)
{
	int i_ret = 1;

	if(idx < 0 || idx >=MAX_FD_NUM)
		return -1;

	if(app_ini_flag<=0)
	{
		sc_gettime(&app_last_tv);
		app_ini_flag = 1;
	}

	if(flow_id_arr[idx].ini_flag<=0)
	{
		 flow_id_arr[idx].it_val = 0;
		sc_gettime(&flow_id_arr[idx].last_tv);
		flow_id_arr[idx].ini_flag = 1;
	}
	else
	{
		struct timeval e;
		sc_gettime(&e);
		long long df = utime_since(&flow_id_arr[idx].last_tv, &flow_id_arr[idx].last_rp);
		if(df>0)
			sc_gettime(&flow_id_arr[idx].last_tv);
	}

	return i_ret;
}

//Update the interarrival times (us) required for each I/O flow system call delay;
///////////////////////////////////////////////////////////////////////
int count_it = 0;
///////////////////////////////////////////////////////////////////////
//t_type 0: request response time 1: interarrival time;
int update_it_val(int idx, int iosize, int t_type)
{
	int i_ret = 1;

	if(idx < 0 || idx >=MAX_FD_NUM)
		return -1;

     //visiting times; 8/21/2018;
	flow_id_arr[idx].cs_num++;
	 //visiting long times; 8/21/2018;
	 flow_id_arr[idx].long_cs_num++;
	flow_id_arr[idx].cs_num_all++;

	//For application-level statistics; //10/21/2018;
	if(data_rec_f)
	{
		app_cs_num++;
		app_bw_num += iosize;
	}

	////////////////////////////////////////////
	int pu =1; 
	//2021.9.1
	if(tail_lat_guarantee) pu = get_dry_user_priviliged();
	else pu = get_dry_users();
	/////////////////////////////////////////////
	//The number of scheduling threads, 2018.12.5;
	//if(app_cs_num > REC_BUF_NUM * fd_id_ptr + MAX_AHEAD_OP && sctl_flag>0)
	//if((app_cs_num > REC_BUF_NUM * sch_thread_num + (REC_BUF_NUM * sch_thread_num * 1)/10 || als_ctl==2) && sctl_flag>0)
	if((app_cs_num > REC_BUF_NUM * pu + (REC_BUF_NUM * pu * 1)/10 || als_ctl==2 || app_cs_num > end_rqs || rec_rounds > end_time * 1000000/CTL_T_NUM) && sctl_flag>0)
	{
		//The lock for threads; //9/28/2018;
		pthread_rwlock_wrlock(&ctlock);
		if(data_rec_f==1)
		{
			//Enforce thread recording at the last round if any 2018.12.8;
			if(record_reqs==1)
				enforce_record_que();

			 struct timeval e;
			sc_gettime(&e);
			 //Disable control; 2020.9.16;
			 //if(als_ctl==2)
			  if(als_ctl==2 
			   || app_cs_num > end_rqs 
			   || rec_rounds > end_time * 1000000/CTL_T_NUM)
				sctl_flag = 0;
			data_rec_f = 2;
			char str_line[512];
			//The end time for throughput statistics (ms); 2018.11.12;
			//sta_end_time = ( e.tv_sec%1000000) * 1000 + e.tv_usec/1000;
			//sta_end_time = e.tv_sec * 1000 + e.tv_usec/1000;
			sta_end_time = e.tv_sec;
			sta_end_ms =  e.tv_usec/1000;
			long  time_sta_sec = sta_end_time - sta_start_time;
			long time_sta_ms = 0;
			long time_sta = time_sta_sec * 1000 + time_sta_ms;
			double iops = ((float) app_cs_num * 1000)/time_sta;
			double band = ((float) app_bw_num * 1000)/time_sta;
			sprintf(str_line, "als_ctl = %d  app_cs_num = %d [priviliged users: %d  REC_BUF_NUM:%d]  app_bw_num = %d  sctl_flag = %d  (%08d, %08d)   timeline: (%08d, %08d),  [FT = %8d ms   IOPS = %8.2f iops   BW = %10.2f KB/s  record_reqs = %d]\n"
								  , als_ctl, app_cs_num, pu, REC_BUF_NUM, app_bw_num, sctl_flag, e.tv_sec, e.tv_usec,sta_end_time, sta_end_ms, time_sta, iops, band, record_reqs);
			als_ctl = 1;
			fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
			fflush(wstream_mem[0]);
		}
		//The lock for threads; //9/28/2018;
		 pthread_rwlock_unlock(&ctlock);
	}
	////////////////////////////////////////////
	struct timeval e;
    if(t_type){
		if(app_ini_flag<=0)
		{
			sc_gettime(&app_last_tv);
			app_ini_flag = 1;
		}

		if(flow_id_arr[idx].ini_flag<=0)
		{
			 flow_id_arr[idx].it_val = 0;
			sc_gettime(&flow_id_arr[idx].last_tv);
			flow_id_arr[idx].ini_flag = 1;
		}else{
			sc_gettime(&e);
			flow_id_arr[idx].it_val = utime_since(&flow_id_arr[idx].last_tv, &e);
		}
	}
	else
	{
			//struct timeval e;
			//sc_gettime(&e);
			sc_gettime(&flow_id_arr[idx].last_rp);
			//the last interarrival times (us); //8/21/2018;
			flow_id_arr[idx].last_it_val = flow_id_arr[idx].it_val;
			//flow_id_arr[idx].last_it_val = (e.tv_sec %1000) * 1000000 +  e.tv_usec;
			//flow_id_arr[idx].it_val = utime_since(&flow_id_arr[idx].last_tv, &e);
			flow_id_arr[idx].it_val = utime_since(&flow_id_arr[idx].last_tv, &flow_id_arr[idx].last_rp);
	}
		
		 //for fio read 4KB 50 threads; us;//8/24/2018;
		if(flow_id_arr[idx].it_val > flow_id_arr[idx].tail_slo)
			flow_id_arr[idx].tail_num++;

		 ///////////////////////////////////////////////////////
		/*long req_lng = (long)req_tot_all;
		if(req_lng > 0 && req_lng%5000==0){
			char str_linex[128];
			sprintf(str_linex, "\n [%lld] last_tv:[%lld, %lld]  last_rp:[%lld, %lld]\n"
									, flow_id_arr[idx].it_val, flow_id_arr[idx].last_tv.tv_sec, flow_id_arr[idx].last_tv.tv_usec,  flow_id_arr[idx].last_rp.tv_sec, flow_id_arr[idx].last_rp.tv_usec);
			fwrite(str_linex,1,strlen(str_linex),wstream_mem[0]);
			fflush(wstream_mem[0]);
		}*/
		///////////////////////////////////////////////////////

		//insert circular latency queue; 12/17/2019;
		en_cir_queue(idx, flow_id_arr[idx].it_val);
		//for tail latency prediction; 2020.3.15;
		p_en_cir_queue(idx, flow_id_arr[idx].it_val);

        ///////////////////////////////////////////////////////////////////////////////////////////////
		/*if(count_it<10000 && data_rec_f == 1)
		{
			char str_line[512];
			sprintf(str_line, "[%d]:  st.s = %d  st.us = %d    et.s = %d  et.us = %d\n"
									  , idx, flow_id_arr[idx].last_tv.tv_sec, flow_id_arr[idx].last_tv.tv_usec,  e.tv_sec, e.tv_usec);
			
			fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
			fflush(wstream_mem[0]);
			count_it++;
		}*/
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		//send system-call only update service time not the starting time;
		 if(t_type){
			flow_id_arr[idx].last_tv.tv_sec = e.tv_sec;
			flow_id_arr[idx].last_tv.tv_usec = e.tv_usec;
		 }

		//Update statistics time; //8/26/2018;
		if( flow_id_arr[idx].it_val>0)
		{
			flow_id_arr[idx].sta_times += flow_id_arr[idx].it_val;
			//For application-level statistics; //10/21/2018;
			app_sta_times += flow_id_arr[idx].it_val;
		}
		else
		{
			flow_id_arr[idx].sta_times += 1;
			//For application-level statistics; //10/21/2018;
			app_sta_times += 1;
		}
		//Update long-term statistics time; //8/26/2018;
		 if(ctl_central_val)
		{
			if( flow_id_arr[idx].it_val>0)
				flow_id_arr[idx].long_sta_times += flow_id_arr[idx].it_val;
			else
				flow_id_arr[idx].long_sta_times += 1;
		}
		//Update throughput slo; //8/26/2018;
		/*int usec_time = 1000000;
		if(flow_id_arr[idx].sta_times>0)
			flow_id_arr[idx].throughput_val = (flow_id_arr[idx].cs_num * usec_time)/(flow_id_arr[idx].sta_times + 1);
		 if(ctl_central_val)
		{
			 if(flow_id_arr[idx].long_sta_times>0)
				flow_id_arr[idx].throughput_slo = (flow_id_arr[idx].long_cs_num * usec_time)/(flow_id_arr[idx].long_sta_times + 1);
		}*/
		//Once the indication of congestion was detected, sleep; //8/21/2018;
		//alarm_congestion = congestion_throttling_signal(idx);
}

///////////////////// The round-robin scheduling algorithm for multi-threaded I/O (APP-RRS)  (2018.10.22)//////////////////////
void init_sched_algo()
{
	 memset(sched_thread_his_arr, 0, MAX_ROUND_NUM * MAX_THCON_NUM * sizeof(int));
	 memset(sched_his_idx_len, 0, MAX_ROUND_NUM * sizeof(int));
	 memset(req_token, 0, MAX_THCON_NUM * sizeof(int));
	 memset(pri_weight, 0, MAX_THCON_NUM * sizeof(int));
	 memset(last_fd_id_ptr, 0, MAX_THCON_NUM * sizeof(int));
	 //check the stability of management group ; 2019.1.1;
	 memset(last_man_id_ptr, 0, MAX_THCON_NUM * sizeof(int));
}

//APP-RRS can only run when all threads are ready;
int should_run_sched()
{
	int i_ret = 0;
	//For all the threads ready; 2018.12.5;
	if(fd_stable_num<10) //For shorter prerperation; 2019.3.8;
	//if(fd_stable_num<50)
	//Extended 12/11/2018;
	//if(fd_stable_num<100)
	{
		if(fd_check_num<=0)
			last_fd_id_ptr[fd_check_num++] = fd_id_ptr;
		else if(fd_check_num<MAX_THCON_NUM && fd_check_num>0)
		{
			if(last_fd_id_ptr[fd_check_num-1]==fd_id_ptr)
				fd_stable_num++;
			last_fd_id_ptr[fd_check_num++] = fd_id_ptr;
		}
	}
	else
	{
		//2018.12.13 to decide when to run als control;
		if(als_ctl<=0)
			als_ctl = read_als_sig();
		if(als_ctl==1)
			i_ret = 1;
	}
	return i_ret;
}

//Get the number of managed threads;
int get_thread_man()
{
	int i_ret = 0;
	int i=0;

	for(i=1;i<=fd_id_ptr;i++)
	{
		if( flow_id_arr[i].sched_avoid_f == 2)
			i_ret++;
	}
	
	return i_ret;
}

//check the stability of management group ; 2019.1.1;
int should_run_experiment()
{
	int i_ret = 0;
	//Expected the number of users; 2019.10.3;
	if(static_conf && fd_id_ptr >= expect_users) 
		return 1;

	//For all the managed threads ready; 2019.1.1;
	if(man_stable_num<50)
	{
		if(man_check_num<=0)
			last_man_id_ptr[man_check_num++] = get_thread_man();
		else if(man_check_num<MAX_THCON_NUM && man_check_num>0)
		{
			int man_num = get_thread_man();
			if(last_man_id_ptr[man_check_num-1]==man_num && man_num > 0)
				man_stable_num++;
			last_man_id_ptr[man_check_num++] = man_num;

			///////////////////////////////////
			if(print_class<=1)
			{
				char str_line[256];
				sprintf(str_line, "man_num = %d  concurrent_ios = %d\n"
					, man_num, concurrent_ios);
				fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
				fflush(wstream_mem[0]);
			}
			///////////////////////////////////
		}
	}
	else
	{
		//2018.12.13 to decide when to run als control;
		if(als_ctl<=0)
			als_ctl = read_als_sig();
		if(als_ctl==1)
			i_ret = 1;
	}
	return i_ret;
}

//Configure the value of req_token and give the worst case latency for scheduling;
int get_thread_con(int max_con)
{
	int i_ret = 4;
	int i=0,j=0;
	int latency = 0;

	int total_throughput = total_th;

	char str_line[64];

	sc_gettime(&pre_point);

	//Suppose to guarantee the latency each thread need to wait before scheduling; 
	for(i=1;i<=fd_id_ptr;i++)
	{
	    //Initialize req_token[i];
		//req_token[i] = (total_throughput * 64000) / (fd_id_ptr * 1000);
		pri_weight[i] = 1;
		req_token[i] = pri_weight[i] * DATA_SET;

		if(req_token[i] < 1)
			req_token[i] = 1;
		///////////////////////////////////
		if(i==1)
		{
			sprintf(str_line, "req_token[%3d] = %d \n", i, req_token[i]);
			fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
			fflush(wstream_mem[0]);
		}
		///////////////////////////////////
		//latency += (fd_id_ptr/max_con) * req_token[i] * (1000000/total_throughput);
	}

	///////////////////////////////////
	sprintf(str_line, "Threads = %d\n", fd_id_ptr-1);
	fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
	fflush(wstream_mem[0]);
	///////////////////////////////////

	i_ret = latency;
	return i_ret;
}

int screen_out_num = 0;

//Reclaim the quota assigned to dead threads; 2018.12.28;
int reclaim_quota_from_dead(long long life_t, int idx)
{
	int i_ret = 0;

	//The IOs for continuous running is 0 and time slice ran out; //12/27/2018;
	if( life_t > MAX_SLEEP_T/4 
&&  (flow_id_arr[idx].con_run_ios <= flow_id_arr[idx].last_con_run_ios || flow_id_arr[idx].con_run_ios==0)
&&  flow_id_arr[idx].sched_avoid_f == 2
&&  flow_id_arr[idx].req_quota > 0)
	{
		///////////////////////////////////
		if(print_class<=0)
		{
			char str_line[256];
			sprintf(str_line, "Reclaim Threads = %d  cri = %d  last_cri = %d  quota = %d  life_t = %d (ms)\n"
				, idx, flow_id_arr[idx].con_run_ios, flow_id_arr[idx].last_con_run_ios, flow_id_arr[idx].req_quota, life_t/1000);
			fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
			fflush(wstream_mem[0]);
		}
		///////////////////////////////////
		flow_id_arr[idx].req_quota = 0;
		//The times of reclaiming quota; //12/31/2018;
		flow_id_arr[idx].reclaim_times++;

        //Screen out those non-io-intensive threads;
		/*if(flow_id_arr[idx].reclaim_times > MAX_RECLAIM_TIMES)
		{
			flow_id_arr[idx].sched_avoid_f = 1;
			screen_out_num++;

			if(print_class<=3)
			{
				char str_line[256];
				sprintf(str_line, "<<(%03d) [Screen out the non-io-intensive thread = %d  cri = %d  last_cri = %d  quota = %d  reclaim_times = %d]>>\n"
					, screen_out_num, idx, flow_id_arr[idx].con_run_ios, flow_id_arr[idx].last_con_run_ios, flow_id_arr[idx].req_quota, flow_id_arr[idx].reclaim_times);
				fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
				fflush(wstream_mem[0]);
			}
		}*/
	}
	else 
	{
		if( flow_id_arr[idx].req_quota>0 && flow_id_arr[idx].sched_avoid_f == 2)
		{
			///////////////////////////////////
			if(print_class<=0)
			{
				char str_line[256];
				sprintf(str_line, "Unreclaim Threads = %d  cri = %d  last_cri = %d  quota = %d  life_t = %d (ms)\n"
					, idx, flow_id_arr[idx].con_run_ios, flow_id_arr[idx].last_con_run_ios, flow_id_arr[idx].req_quota, life_t/1000);
				fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
				fflush(wstream_mem[0]);
			}
			///////////////////////////////////
		}
		
		//Clean the times of reclaiming quota; //12/31/2018;
		if(flow_id_arr[idx].con_run_ios >0 && flow_id_arr[idx].sched_avoid_f == 2)
			flow_id_arr[idx].reclaim_times = 0;
	}

	flow_id_arr[idx].last_con_run_ios = flow_id_arr[idx].con_run_ios;

	return i_ret;
}

//Set quota for all the threads; 2019.1.2
int let_all_threads_run()
{
	int i_ret = 1;
	int i=0;
	for(i=1;i<=fd_id_ptr;i++)
	{
			if(flow_id_arr[i].sched_avoid_f == 2 
		&& flow_id_arr[i].req_quota<=0)
			{
						 flow_id_arr[i].req_quota = req_token[i];
						 //Clear the IOs for continuous running; //12/27/2018;
						 flow_id_arr[i].con_run_ios = 0;
			}
	}
	return i_ret;
}


//Get the number of concurrent threads;
int get_thread_concurrency(char * cstr)
{
	int i_ret = 0;
	int i=0;

    ////////////////////////////////////
	char xstr[64];
	memset(xstr, 0, 64);
	////////////////////////////////////

	struct timeval e;
	sc_gettime(&e);

	for(i=1;i<=fd_id_ptr;i++)
	{
		if(flow_id_arr[i].head_num > 0)
		{
				////////////////////////////////////
				//sprintf(xstr, " {%03d, %03d, %02d};", i, flow_id_arr[i].head_num, flow_id_arr[i].sched_avoid_f);
				//strcat(cstr, xstr);
				////////////////////////////////////
		}
		
		if(flow_id_arr[i].req_quota > 0)
		{
			long long ut = utime_since(&flow_id_arr[i].sched_tv, &e);

			//Reclaim the quota assigned to dead threads; 2018.12.28;
			reclaim_quota_from_dead(ut, i);
		}

		if(flow_id_arr[i].req_quota > 0)
		{
			long long cr = req_token[i] - flow_id_arr[i].req_quota;
			//int bw = (cr * 1000 * 1000)/(ut+1);

			//if(bw > req_token[i]/100 || bw > 50)
			if(flow_id_arr[i].sched_avoid_f == 2) //Only counting the threads under control 2018.11.5;
			{
				////////////////////////////////////
				//sprintf(xstr, " (%03d, %4d);", i, flow_id_arr[i].req_quota);
				//strcat(cstr, xstr);
				////////////////////////////////////
				i_ret++;
			}
		}
	}
	//concurrent_ios = i_ret;
	return i_ret;
}

int th_fir = 1;

//Get property of all the threads; 2018.12.27;
int get_th_num_pro(int type, int * list)
{
	 int i_ret = 0;
	 int i=0;
	 for(i=1;i<=fd_id_ptr;i++)
	{
		 //if(th_fir == 1)
		//	 flow_id_arr[i].head_num = 1;

			if(/*flow_id_arr[i].sched_avoid_f == 2 //The thread under control;
		&&*/ flow_id_arr[i].head_num > 0) //If  holding one or more requests 2018.12.25;
			{
				list[i] = i;
				i_ret++;
			}
	}
	if(th_fir==1)
		th_fir = 0;

	return i_ret;
}

//Get property of all the threads; 2018.12.27;
int get_run_num_pro(int type)
{
	 int i_ret = 0;
	 int i=0;
	 for(i=1;i<=fd_id_ptr;i++)
	{
		 //if(th_fir == 1)
		//	 flow_id_arr[i].head_num = 1;

			if(/*flow_id_arr[i].sched_avoid_f == 2 //The thread under control;
		&&*/ flow_id_arr[i].con_run_ios > 0) //If  holding one or more requests 2018.12.25;
			{
				i_ret++;
			}
	}
	if(th_fir==1)
		th_fir = 0;

	return i_ret;
}

//Get concurrency; 2018.12.27;
/*void show_thread_concurrency(int c_flag)
{
	char tstr[4096];
	memset(tstr, 0, 4096);
	int th_d = get_thread_concurrency(tstr);
	int q_n = get_th_num_pro(1);
	char cstr[4096];
	memset(cstr, 0, 4096);
	struct timeval e;
    sc_gettime(&e);
	sprintf(cstr, "[T: %05d] -th_d: %d  thread_con: %d [q_n: %d]- Time  (%08d, %08d)  <%s>\n", c_flag,  th_d, thread_con, q_n, e.tv_sec, e.tv_usec, tstr);
	fwrite(cstr,1,strlen(cstr),wstream_mem[0]);
	fflush(wstream_mem[0]);
}*/

//Token bucket algorithm; 2019.3.11;
void tb_scheduler()
{
	int i=0;
	for(i=1;i<=MAX_FD_NUM/2;i++)
	{
		if(req_token[i]>1)
			flow_id_arr[i].req_quota = req_token[i];
		else
			flow_id_arr[i].req_quota = tb_credits;
	}
}

//The 1st valid user; 2019.10.3;
void get_first_user()
{
	int i=0, i_ret=0;
	 for(i=1;i<=fd_id_ptr;i++)
	{
             //The thread under control;
			if(flow_id_arr[i].sched_avoid_f == 2) 
			{
					first_v_user = i;
					break;
			}
	}
}

//To make sure if the current round was completed; 2019.10.3;
//idx: the user index will be scheduled;
int keep_round_safe( int idx)
{
	 int i_ret = 0, i=0, min_diff  = 999999, min_id=0;

	 if(idx!=first_v_user) return 0;
	
	 for(i=first_v_user;i<=fd_id_ptr;i++)
	{
             //The thread under control;
			if(flow_id_arr[i].sched_avoid_f == 2) 
			{
				if(min_diff > flow_id_arr[i].sched_times - abs_round_idx)
				{
					min_diff = flow_id_arr[i].sched_times - abs_round_idx;
					min_id = i;
				}
			}
	}

	//The absolute index for scheduling rounds; 2019.10.3;
	if(min_diff - abs_round_idx < 0)
	{
		if(flow_id_arr[min_id].req_quota<=0)
			i_ret = i;
		else
		    i_ret = -1; //missing a round;
	}

	if(flow_id_arr[idx].sched_times + 1 - abs_round_idx<=0)
	   i_ret = 0;

	return i_ret;
}

  //Scheduling time slices for threads;
  void thread_scheduler(int c_flag, int type)
  {
	  //Token bucket algorithm; 2019.3.11;
	 if(tb_apples==1)  return;

    int i=0, j=0;
	////////////////////////////////////
	char tstr[2048];
	memset(tstr, 0, 2048);
	////////////////////////////////////
  	int th_d = get_thread_concurrency(tstr);

	char xstr[64];
	memset(xstr, 0, 64);

	 struct timeval e;
     sc_gettime(&e);

	 char cstr[2048];
	memset(cstr, 0, 2048);

	int q_arr[256];
	memset(q_arr, 0, 256);

	  //get the available number of threads; 2018.12.27;
	int q_n = get_th_num_pro(1, q_arr);

	int r_n = get_run_num_pro(1);

	long long tdiff = 0;

	//The 1st valid user; 2019.10.3;
	if(first_v_user<=0)
       get_first_user();
	
	//Update the standard time used in ALS for threads; 2019.1.2;
	if(type==0)
       als_time++;

	//////////////////////////////////////////////////////////////////////////
	if(sched_mode == FAIRNESS){
		//Keep a complete round; 2019.10.3;
		if(th_d > 0) return;
	}
	//////////////////////////////////////////////////////////////////////////
	else if(sched_mode == EFFICIENT){
		//if the number of concurrent threads is larger than thread_con, the scheduler exits;
		if(th_d >= thread_con) //Must allocate quota now!; 2018.12.31;
		{
			/////////////////////////////////////////////////////////////////////////
			if(print_class<=1)
			{
				sprintf(cstr, "[T: %05d %2d] #th_d: %d  thread_con: %d# The %04d round threads  (%08d, %08d) Wait: %8d (ms)\n"
					, c_flag, type, th_d, thread_con, round_idx+1, e.tv_sec, e.tv_usec, flow_id_arr[c_flag].con_sleep_time/1000);
				fwrite(cstr,1,strlen(cstr),wstream_mem[0]);
				fflush(wstream_mem[0]);
			}
			/////////////////////////////////////////////////////////////////////////
		   return;
		}
	}
	
	if(print_class<=2)
	{
		memset(cstr, 0, 2048);
		sprintf(cstr, "[T: %05d  op: %02d] -th_d: %04d  thread_con: %04d [q_n: %04d, fd_id_ptr: %05d,  sctl_flag: %d,  data_rec_f: %d ]- The %04d round  (%08d, %08d)  <%s>"
			, c_flag,  type, th_d, thread_con, q_n, fd_id_ptr, sctl_flag, data_rec_f, round_idx+1, e.tv_sec, e.tv_usec, tstr);
	}

	//Check the scheduling history;
	//index of running threads #1,#2,#3,#4
	int kk = 0;
	//Tell if having at least one backlogged thread; 2018.12.28;
    int blog_th_num = 0;

	if(sched_flag<=0)
	{
		for(i=1;i<=thread_con;i++)
		//for(i=1;i<=sch_thread_num/2;i++)
		{
			for(j=kk+1;j<=fd_id_ptr;j++)
			{
				if(flow_id_arr[j].sched_avoid_f == 2 //The thread under control;
			/*&& flow_id_arr[j].head_num > 0*/) //If  holding one or more requests 2018.12.25;
				{
					flow_id_arr[j].req_quota = req_token[j];
					sched_thread_his_arr[round_idx][sched_his_idx_len[round_idx]++] = j;

					//The total scheduled times; //10/3/2019;
	                 flow_id_arr[j].sched_times++;

					 //The absolute index for scheduling rounds; 2019.10.3;
				     if(j==first_v_user) abs_round_idx++;

					//Clear the IOs for continuous running; //12/27/2018;
				     flow_id_arr[j].con_run_ios = 0;

					//Tell if having at least one backlogged thread; 2018.12.28;
					if(flow_id_arr[j].head_num>0)
						blog_th_num++;
					///////////////////////////////////
					if(print_class<=2)
					{
						//printf("The %4d round threads[%2d] = %d [reqs = %d]\n", round_idx+1, sched_his_idx_len[round_idx], i, req_token[i]);
						sprintf(xstr, " (%03d,%03d,%03d),", j,flow_id_arr[j].sched_avoid_f,flow_id_arr[j].head_num);
						//sprintf(xstr, " %03d,", i);
						strcat(cstr, xstr);
					}
					///////////////////////////////////
					kk = j;
					break;
				}
			}
		}

		round_idx++;
		sched_flag = 1;
		strcat(cstr, "\n");
       }
       else
       {
       		//Check the scheduling history;
		//Last scheduled thread index;
		int last_idx = round_idx - 1;
		if(last_idx<0)
		   last_idx = MAX_ROUND_NUM - 1;

		int last_th_idx = sched_thread_his_arr[last_idx][sched_his_idx_len[last_idx]-1];

		sched_his_idx_len[round_idx] = 0;
		
		//Recording the cycle times; 2018.12.28;
		int cycle_times = 0;

		//Keep the original history index; 2018.12.30;
		int ori_idx = 0;

		//for the next thread_con threads unscheduled in the last turn;
		for(i=0;i<thread_con - th_d;i++)
		{
			//int th_idx = (last_th_idx + i + 1)%fd_id_ptr;
			//Search next available tid;  2018.12.26;
			int th_idx = (last_th_idx + 1)%fd_id_ptr;

			if(th_idx==0) th_idx = fd_id_ptr;

			//check on the validation of this thread;
			if(th_idx<=fd_id_ptr)
			{
			    //Not scheduled in the last turn;
	S:			if(!skip_last_round_con){
					for(j=0;j<sched_his_idx_len[last_idx];j++)
					{
						if(sched_thread_his_arr[last_idx][j] == th_idx)
						  break;
					}
	            }else{
					j = sched_his_idx_len[last_idx]; //2020.4.17; Neglect the conditon of scheduling: not choosing the user scheduled in the last round;
				}

				//tail_lat_guarantee state;
				if(tail_lat_guarantee){
					//2020.1.22 for congested situation;
					if(sys_state == 1){
						//for priviliged users, we give them more chances;
						if(is_user_priviliged(th_idx)){
							j = sched_his_idx_len[last_idx];
						}
						//for unpriviliged users, if priviliged users have not been fully scheduled, give up them;
						else {
							if(pu_n - sched_pu_n > 1){
								j = sched_his_idx_len[last_idx] - 1;
							}
							//All the priviliged users have been scheduled to run;
							else{
								int thpt_hard_user =  get_hard_user();
							   if(thpt_hard_user > 0){
									th_idx = thpt_hard_user;
									j = sched_his_idx_len[last_idx];
							   }
							}
						}
				   }
				   //Slack resources for throughput-SLO users; 2020.2.24;
				   else{
					   if(!is_user_priviliged(th_idx)){
						   int thpt_hard_user =  get_hard_user();
						   if(thpt_hard_user > 0){
								th_idx = thpt_hard_user;
								j = sched_his_idx_len[last_idx];
						   }
					   }
				   }
				}else{
					//2020.7.16 for current throughput aggregation;
					//int thpt_hard_user =  get_hard_user(); //This is a nonsense call (we don't need it) that can cause huge cost when goto is continuously enforced; 2020.9.16 
				}
				////////////////////////////////////////////////////////////
				
				//Scheduled in the last turn or a thread without the need to control; the latter part added on 2018.11.5;
				if(j<sched_his_idx_len[last_idx] 
				  || flow_id_arr[th_idx].sched_avoid_f < 2 //Unmanaged threads;
				  || flow_id_arr[th_idx].req_quota>0 //Scheduled now; 2018.12.28;
				  //|| flow_id_arr[th_idx].head_num<=0) //At least one thread is backlogged; 2018.12.28;
				  /*|| (i==thread_con - th_d - 1 && flow_id_arr[th_idx].con_run_ios<=0 && blog_th_num<=0)*/) //At least one thread is backlogged; 2018.12.28;
				{
					//Choose another thread;
					th_idx = (++th_idx)%fd_id_ptr;
					if(th_idx==0) th_idx = fd_id_ptr;
					//Recording the cycle times; 2018.12.28;
					cycle_times ++;
					//Avoiding dead cycle;
					if(cycle_times<fd_id_ptr)
						goto S;
					//Use the first thread scheduled in the last round; 2018.12.28;
					else
					{
						//th_idx = sched_thread_his_arr[last_idx][0];
						th_idx = c_flag; //for a feasible tread; 2018.12.30;
					}
				}
				
				//////////////////////////////////////////////////////////////////////////
				//Keep a complete round; 2019.10.3;
				 /*int sig = keep_round_safe(th_idx);
				 if(sig>0) th_idx = sig;
				 else if(sig<0) return;*/
				 //////////////////////////////////////////////////////////////////////////

				//for a feasible tread; 2018.12.30;
				if(type >= 2 && i==0)
				{
					ori_idx = th_idx - 1;
					if(ori_idx==0) ori_idx = fd_id_ptr;
					th_idx = c_flag;
					last_th_idx = ori_idx;
				}
				else
				{
					//Update the last_th_idx; 2018.12.26;
					 last_th_idx = th_idx;
				}

				//Tell if having at least one backlogged thread; 2018.12.28;
				if(flow_id_arr[th_idx].con_run_ios>0)
					blog_th_num++;

				//set scheduling time; //10/28/2018;
				sc_gettime(&flow_id_arr[th_idx].sched_tv);
				
				flow_id_arr[th_idx].req_quota = req_token[th_idx];
				sched_thread_his_arr[round_idx][sched_his_idx_len[round_idx]++] = th_idx;
				//The total scheduled times; //12/15/2018;
	            flow_id_arr[th_idx].sched_times++;
				//Clear the IOs for continuous running; //12/27/2018;
				flow_id_arr[th_idx].con_run_ios = 0;

				//The absolute index for scheduling rounds; 2019.10.3;
				if(th_idx==first_v_user) abs_round_idx++;

				//The ave congestion time (us); //12/15/2018;
				 //flow_id_arr[th_idx].ave_cs_sleep =  flow_id_arr[th_idx].cs_sleep_time/flow_id_arr[th_idx].sched_times;
				 //The ave it time (us); //12/15/2018;
				 //flow_id_arr[th_idx].ave_it_val = flow_id_arr[th_idx].long_sta_times / (flow_id_arr[th_idx].long_cs_num + 1);

				 //Update the last_th_idx; 2018.12.26;
				 //last_th_idx = th_idx;
				
				///////////////////////////////////
				if(print_class<=2)
				{
					//printf("The %4d round threads[%2d] = %d [reqs = %d]\n", round_idx+1, sched_his_idx_len[round_idx], th_idx, req_token[th_idx]);
					sprintf(xstr, " [%03d,%03d,%03d],", th_idx,flow_id_arr[th_idx].sched_avoid_f,flow_id_arr[th_idx].head_num);
					strcat(cstr, xstr);
				}
				///////////////////////////////////
			}
		}
		round_idx = (++round_idx)%MAX_ROUND_NUM;
		strcat(cstr, "\n");
       }
	   ////////////////////////////////////
	   if(print_class<=2)
	  {
		   fwrite(cstr,1,strlen(cstr),wstream_mem[0]);
		   fflush(wstream_mem[0]);
	  }
	   ////////////////////////////////////
  }


  //Tell if the thread can run;
 int run_it(int idx)
  {
	 //Get the App-level outstanding I/Os; 2019.3.12;
	 int out_f = 0;
	 /*int outs = get_app_outs();
	 if(outs>thread_con*ratio_out)
	 {
		 out_f = 1;
		 if(data_rec_f)
			out_num++;
	 }*///for future use;

	 if(!sctl_flag 
	   || flow_id_arr[idx].sched_avoid_f!=2)//run the unmanaged threads 2018.12.25;
	  {
		 //If  holding one or more requests 2018.12.25;
		flow_id_arr[idx].head_num = 0;
		//Add the 1-type thread into the managed group, i.e., type-2 threads; 2019.1.1;
		if(flow_id_arr[idx].sched_avoid_f!=2 
	&& !data_rec_f 
	&& !static_conf)
		{
				//2019.1.1 for I/O threads have ever issued I/Os;
				 th_erun_list[idx] = 1;
				 flow_id_arr[idx].sched_avoid_f = 2;

				  if(print_class<=2)
				  {
						char str_line[32];
						sprintf(str_line, ">>> Add thread %4d into managed group\n", idx);
						fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
						fflush(wstream_mem[0]);
				  }
		 }
		 return 1;
	  }

	 //If waiting too long, give a chance to issue requests; 2019.2.3;
	 //if(flow_id_arr[idx].con_sleep_time > REST_TIME * 2000
	 if((flow_id_arr[idx].con_sleep_time > REST_TIME * max_apples_delay || out_f || dis_app_delay_f)
  && flow_id_arr[idx].req_quota<=0)
	 {
		 flow_id_arr[idx].con_sleep_time = 0;
		 flow_id_arr[idx].req_quota = 1;
		 sta_steal_run++;
	 }

  	if(flow_id_arr[idx].req_quota > 0)
	{
		///////////////////////////////////
		/*char str_line[32];
		sprintf(str_line, "IDX = %4d [%2d]\n", idx, flow_id_arr[idx].req_quota);
		fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
		fflush(wstream_mem[0]);*/
		///////////////////////////////////
	   //If  holding one or more requests 2018.12.25;
	   //flow_id_arr[idx].head_num = 0;
	   flow_id_arr[idx].head_num--; //2021.8.26 TEST;
	   ////////////////////////////////////////////////////////
	   flow_id_arr[idx].req_quota--;
	   //The IOs for continuous running; //12/27/2018;
	   flow_id_arr[idx].con_run_ios++;
	   //2019.1.1 for I/O thread waiting for I/O dispatching;
       th_wait_list[idx] = 0;
	   //2019.1.1 for I/O threads have ever issued I/Os;
       th_erun_list[idx] = 1;

	   //concurrent_ios1--;

	   //////////////////////////////////////////////////
	   if(flow_id_arr[idx].req_quota<=0)
		{
		    //The lock for threads; //9/28/2018;
		   //pthread_rwlock_wrlock(&xtlock);
		  // concurrent_ios++;
		   //The lock for threads; //9/28/2018;
		  // pthread_rwlock_unlock(&xtlock);

		   //The lock for threads; //9/28/2018;
		   pthread_rwlock_wrlock(&stlock);
		   thread_scheduler(idx, 1);
		   //The lock for threads; //9/28/2018;
		   pthread_rwlock_unlock(&stlock);
		}
	   /////////////////////////////////////////////////
	    return 1;
	}
	
	//I/O request arrived, so head_num = 1; //2018.12.30
	if(flow_id_arr[idx].head_num<=0)
	 {
		flow_id_arr[idx].head_num = 1;
		///////////////////////////////////
		/*char str_line[32];
		sprintf(str_line, "Wait = %4d [%2d]\n", idx, flow_id_arr[idx].head_num);
		fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
		fflush(wstream_mem[0]);*/
		///////////////////////////////////
	 }

	 ///////////////////////////////////
	 //2019.1.1 for I/O thread waiting for I/O dispatching;
     th_wait_list[idx] = 1;

	 if(print_class<=0)
	  {
			char str_line[32];
			sprintf(str_line, "Wait = %4d [con_sleep: %8d (ms)]\n", idx, flow_id_arr[idx].con_sleep_time/1000);
			fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
			fflush(wstream_mem[0]);
	  }
		///////////////////////////////////

	return 0;
  }

//Run the thread or sleep it;
  void run_thread(int idx)
  {
	  //If  holding one or more requests 2018.12.25;
	  flow_id_arr[idx].head_num++;
		
		//////////////////////////////static_pri_set 2020.4.18///////////////////////////////////
	   if(static_pri_set){
		   if(flow_id_arr[idx].is_priviliged<=0){
			   //2) Adaptive control; 2020.4.18;
			   adaptive_control_delay(idx);
			   usleep(REST_TIME * flow_id_arr[idx].wt_ratio);
		   }
		   return;
	   }
	   //////////////////////////////static_pri_set 2020.4.18///////////////////////////////////

       /*if(!sched_flag)
	  {
		    //If  holding one or more requests 2018.12.25;
		  // flow_id_arr[idx].head_num--;
          return;
	  }*/

	  //concurrent_ios1++;
	
	////Under soft-throttling state; 2019.1.2;
	if(soft_throttling)
   {
		if(!run_it(idx))
	   {
			usleep(REST_TIME * throttling_level);
			//2018.12.15  accumulate the congestion time imposed by AppleS;
			flow_id_arr[idx].cs_sleep_time += REST_TIME * throttling_level;
			//The time for continuous sleeping; //12/27/2018;
			flow_id_arr[idx].con_sleep_time += REST_TIME * throttling_level;
	   }
	}
	else
	  {
		  //if(flow_id_arr[idx].times_delay<=1){ //priviliged users or BE users with the racing status; 2020.8.17;
		  if(1){
				 //AppleS; 2019.10.3;
			ML:	while(!run_it(idx))
				//mClock; 2019.10.3;
				//while(!mclock(idx))
				{
				   //if(flow_id_arr[idx].times_delay<=1){
				    if(1){
					   //the times for standard I/O delay unit; 1/22/2020;
						usleep(flow_id_arr[idx].times_delay * REST_TIME);
					   //2018.12.15  accumulate the congestion time imposed by AppleS;
					   flow_id_arr[idx].cs_sleep_time += flow_id_arr[idx].times_delay * REST_TIME;
						//The time for continuous sleeping; //12/27/2018;
					   flow_id_arr[idx].con_sleep_time += flow_id_arr[idx].times_delay * REST_TIME;
				   }else{
					    struct timeval e;
						sc_gettime(&e);
						struct timeval f = flow_id_arr[idx].last_tv;
						long long pt = utime_since(&f, &e);
						int sp_t = flow_id_arr[idx].times_delay;
					  //Ensure the I/O delay be  flow_id_arr[idx].times_delay * REST_TIME; 2020.8.17;
							while (pt - sp_t * REST_TIME < 0)
							{
								///////////////////////////////////
								 //2020.8.18 for time stamps;
								 /*if(print_class<=3)
								  {
										if(idx==20){
											char str_line[128];
											sprintf(str_line, "Time[%08d,  %08d] [%08d,  %08d] = %08d D [con: %08d]\n", f.tv_sec, f.tv_usec/1000,e.tv_sec, e.tv_usec/1000, pt/1000, sp_t);
											fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
											fflush(wstream_mem[0]);
										}
								  }*/
									///////////////////////////////////
							   //the times for standard I/O delay unit; 1/22/2020;
								usleep(REST_TIME);
							   //2018.12.15  accumulate the congestion time imposed by AppleS;
							   flow_id_arr[idx].cs_sleep_time += REST_TIME;
								//The time for continuous sleeping; //12/27/2018;
							   flow_id_arr[idx].con_sleep_time += REST_TIME;
							   //sc_gettime(&e);
							   //pt = utime_since(&f, &e);
							   pt = pt + REST_TIME + REST_TIME/8;
							}
					   }
				}
		   }else{ //BE users with backoff status; 2020.8.17
			   long usn =  flow_id_arr[idx].last_tv.tv_usec;
               if(usn > 1001 || usn < 0){
				   goto ML;
			   }else{
					struct timeval e;
					sc_gettime(&e);
					struct timeval f = flow_id_arr[idx].last_tv;
					long long pt = utime_since(&f, &e);
					int sp_t = flow_id_arr[idx].times_delay;

					//Ensure the I/O delay be  flow_id_arr[idx].times_delay * REST_TIME; 2020.8.17;
					while (pt - sp_t * REST_TIME < 0)
					{
						///////////////////////////////////
						 //2020.8.18 for time stamps;
						 /*if(print_class<=3)
						  {
								if(idx==20){
									char str_line[128];
									sprintf(str_line, "Time[%08d,  %08d] [%08d,  %08d] = %08d B [con: %08d]\n", f.tv_sec, f.tv_usec/1000,e.tv_sec, e.tv_usec/1000, pt/1000, sp_t);
									fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
									fflush(wstream_mem[0]);
								}
						  }*/
							///////////////////////////////////
					   //the times for standard I/O delay unit; 1/22/2020;
						usleep(REST_TIME);
					   //2018.12.15  accumulate the congestion time imposed by AppleS;
					   flow_id_arr[idx].cs_sleep_time += REST_TIME;
						//The time for continuous sleeping; //12/27/2018;
					   flow_id_arr[idx].con_sleep_time += REST_TIME;
					   sc_gettime(&e);
					   pt = utime_since(&f, &e);
					}
			   }
		   }
	  }
  }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#endif

