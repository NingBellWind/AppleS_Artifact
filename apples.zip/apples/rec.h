#ifndef REC_H
#define REC_H

#include "common.h"

#define FILE_NUM 1

FILE * wstream_cmd[FILE_NUM];
FILE * wstream_rec[FILE_NUM];
FILE * wstream_mem[FILE_NUM];
FILE * wstream_que[FILE_NUM];
FILE * wstream_net[FILE_NUM];
//add 3 logs; 2020.2.23;
FILE * wstream_oet[FILE_NUM];
FILE * wstream_pet[FILE_NUM];
FILE * wstream_qet[FILE_NUM];
//2019.3.19;
FILE * wstream_net1[FILE_NUM];
FILE * wstream_net2[FILE_NUM];
//2020.7.16;
FILE * wstream_interface[FILE_NUM];
//2020.8.12;
FILE * wstream_xput[FILE_NUM];
FILE * wstream_opt[FILE_NUM];

//file handle; 2018.8.19;
int cmd_handle[FILE_NUM];
int rec_handle[FILE_NUM];
int mem_handle[FILE_NUM];
int que_handle[FILE_NUM];
int net_handle[FILE_NUM];
//add 3 logs; 2020.2.23;
int oet_handle[FILE_NUM];
int pet_handle[FILE_NUM];
int qet_handle[FILE_NUM];
//2019.3.19;
int net_handle1[FILE_NUM];
int net_handle2[FILE_NUM];
//2020.7.16;
int interface_handle[FILE_NUM];
//2020.8.12;
int xput_handle[FILE_NUM];
int opt_handle[FILE_NUM];

int aslo_log_init()
{
	int i=0;
	for(i=0;i<FILE_NUM;i++)
	{
		wstream_cmd[i] = NULL;
		wstream_rec[i] = NULL;
		wstream_mem[i] = NULL;
		wstream_que[i] = NULL;
		wstream_net[i] = NULL;
		//add 3 logs; 2020.2.23;
		wstream_oet[i] = NULL;
		wstream_pet[i] = NULL;
		wstream_qet[i] = NULL;
		//2019.3.19;
		wstream_net1[i] = NULL;
		wstream_net2[i] = NULL;
		//2020.7.16;
		wstream_interface[i] = NULL;
		//2020.8.12;
		wstream_xput[i] = NULL;
		wstream_opt[i] = NULL;
	}

	//file handle; 2018.8.19;
	memset(cmd_handle, 0, FILE_NUM*sizeof(int));
	memset(rec_handle, 0, FILE_NUM*sizeof(int));
	memset(mem_handle, 0, FILE_NUM*sizeof(int));
	memset(que_handle, 0, FILE_NUM*sizeof(int));
	memset(net_handle, 0, FILE_NUM*sizeof(int));
	//add 3 logs; 2020.2.23;
	memset(oet_handle, 0, FILE_NUM*sizeof(int));
	memset(pet_handle, 0, FILE_NUM*sizeof(int));
	memset(qet_handle, 0, FILE_NUM*sizeof(int));
	//2019.3.19;
	memset(net_handle1, 0, FILE_NUM*sizeof(int));
	memset(net_handle2, 0, FILE_NUM*sizeof(int));
	//2020.7.16;
	memset(interface_handle, 0, FILE_NUM*sizeof(int));
	//2020.8.12;
	memset(xput_handle, 0, FILE_NUM*sizeof(int));
	memset(opt_handle, 0, FILE_NUM*sizeof(int));
}

int aslo_open_log(char * experiment, int index)
{
	int i=0;
	char f_str[128];

	for(i=0;i<FILE_NUM;i++)
	{
		sprintf(f_str,"/%s/bslo_cmd_log%d.txt", experiment, index, i+1);
		wstream_cmd[i] = fopen(f_str,"w+");

		sprintf(f_str,"/%s//bslo_rec_log%d.txt", experiment, index, i+1);
		wstream_rec[i] = fopen(f_str,"w+");

		sprintf(f_str,"/%s//bslo_mem_log%d.txt", experiment, index, i+1);
		wstream_mem[i] = fopen(f_str,"w+");

		sprintf(f_str,"/%s//bslo_que_log%d.txt", experiment, index, i+1);
		wstream_que[i] = fopen(f_str,"w+");

		sprintf(f_str,"/%s//bslo_net_log%d.txt", experiment, index, i+1);
		wstream_net[i] = fopen(f_str,"w+");

		//add 3 logs; 2020.2.23;
		sprintf(f_str,"/%s//bslo_oet_log%d.txt", experiment, index, i+1);
		wstream_oet[i] = fopen(f_str,"w+");
		sprintf(f_str,"/%s//bslo_pet_log%d.txt", experiment, index, i+1);
		wstream_pet[i] = fopen(f_str,"w+");
		sprintf(f_str,"/%s//bslo_qet_log%d.txt", experiment, index, i+1);
		wstream_qet[i] = fopen(f_str,"w+");

		//2019.3.19;
		sprintf(f_str,"/%s//bslo_net1_log%d.txt", experiment, index, i+1);
		wstream_net1[i] = fopen(f_str,"w+");
		sprintf(f_str,"/%s//bslo_net2_log%d.txt", experiment, index, i+1);
		wstream_net2[i] = fopen(f_str,"w+");

		//2020.7.16;
		sprintf(f_str,"/%s//bslo_interface_log%d.txt", experiment, index, i+1);
		wstream_interface[i] = fopen(f_str,"w");

		//2020.8.12;
		sprintf(f_str,"/%s//bslo_xput_log%d.txt", experiment, index, i+1);
		wstream_xput[i] = fopen(f_str,"w");

		//2020.8.12;
		sprintf(f_str,"/%s//bslo_opt_log%d.txt", experiment, index, i+1);
		wstream_opt[i] = fopen(f_str,"a+");

		//file handle; 2018.8.19;
		cmd_handle[i] = fileno(wstream_cmd[i]);
		rec_handle[i] = fileno(wstream_rec[i]);
		mem_handle[i] = fileno(wstream_mem[i]);
		que_handle[i] = fileno(wstream_que[i]);
		net_handle[i] = fileno(wstream_net[i]);
		//disk_handle = fileno(fp_diskstats);

		//add 3 logs; 2020.2.23;
		oet_handle[i] = fileno(wstream_net[i]);
		pet_handle[i] = fileno(wstream_net[i]);
		qet_handle[i] = fileno(wstream_net[i]);

		//2019.3.19;
		net_handle1[i] = fileno(wstream_net1[i]);
		net_handle2[i] = fileno(wstream_net2[i]);

		//2020.7.16;
		interface_handle[i] = fileno(wstream_interface[i]);

		//2020.8.12;
		xput_handle[i] = fileno(wstream_xput[i]);

		opt_handle[i] = fileno(wstream_opt[i]);

		//if(app_type==1) sprintf(db_str, "MySQL");
		//else if(app_type==2) sprintf(db_str, "MongoDB");
		//else sprintf(db_str, "No_supported_DB");

		//printf("\nonctl fileID = %6d  %6d  %6d  %6d\n", cmd_handle[i], rec_handle[i], mem_handle[i], que_handle[i]);
		 printf("\nAppleS [v %4.2f] running [(database: %s, version:%d) (L_target: %d, P_target: %d)  eff_delay:%d  disable_apples:%d  control_interval: %d  expect_users: %d  latencyVar_ub: %d  fairness_ub: %d  opt_run: %d]......\n"
			        , apples_version, db_str, app_version, DATA_SET, thread_con, eff_delay, disable_apples, CTL_T_NUM, expect_users, latencyCV_high_b, fairness_high_b, opt_run);
	}
	return 1;
}

int aslo_close_log()
{
	int i=0;

	for(i=0;i<FILE_NUM;i++)
	{
		if(wstream_cmd[i]!=NULL)
		{
			fclose(wstream_cmd[i]);
			wstream_cmd[i] = NULL;
		}

		if(wstream_rec[i]!=NULL)
		{
			fclose(wstream_rec[i]);
			wstream_rec[i] = NULL;
		}

		if(wstream_mem[i]!=NULL)
		{
			fclose(wstream_mem[i]);
			wstream_mem[i] = NULL;
		}

		if(wstream_que[i]!=NULL)
		{
			fclose(wstream_que[i]);
			wstream_que[i] = NULL;
		}

		if(wstream_net[i]!=NULL)
		{
			fclose(wstream_net[i]);
			wstream_net[i] = NULL;
		}
		
		//add 3 logs; 2020.2.23;
		if(wstream_oet[i]!=NULL)
		{
			fclose(wstream_oet[i]);
			wstream_oet[i] = NULL;
		}
		if(wstream_pet[i]!=NULL)
		{
			fclose(wstream_pet[i]);
			wstream_pet[i] = NULL;
		}
		if(wstream_qet[i]!=NULL)
		{
			fclose(wstream_qet[i]);
			wstream_qet[i] = NULL;
		}

		//2019.3.19;
		if(wstream_net1[i]!=NULL)
		{
			fclose(wstream_net1[i]);
			wstream_net1[i] = NULL;
		}

		if(wstream_net2[i]!=NULL)
		{
			fclose(wstream_net2[i]);
			wstream_net2[i] = NULL;
		}

		//2020.7.16;
		if(wstream_interface[i]!=NULL)
		{
			fclose(wstream_interface[i]);
			wstream_interface[i] = NULL;
		}

		//2020.8.12;
		if(wstream_xput[i]!=NULL)
		{
			fclose(wstream_xput[i]);
			wstream_xput[i] = NULL;
		}

		if(wstream_opt[i]!=NULL)
		{
			fclose(wstream_opt[i]);
			wstream_opt[i] = NULL;
		}
	}

	//file handle; 2018.8.19;
	memset(cmd_handle, 0, FILE_NUM*sizeof(int));
	memset(rec_handle, 0, FILE_NUM*sizeof(int));
	memset(mem_handle, 0, FILE_NUM*sizeof(int));
	memset(que_handle, 0, FILE_NUM*sizeof(int));
	memset(net_handle, 0, FILE_NUM*sizeof(int));

	//add 3 logs; 2020.2.23;
	memset(oet_handle, 0, FILE_NUM*sizeof(int));
	memset(pet_handle, 0, FILE_NUM*sizeof(int));
	memset(qet_handle, 0, FILE_NUM*sizeof(int));

	//2019.3.19;
	memset(net_handle1, 0, FILE_NUM*sizeof(int));
	memset(net_handle2, 0, FILE_NUM*sizeof(int));

	//2020.7.16;
	memset(interface_handle, 0, FILE_NUM*sizeof(int));

	//2020.8.12;
	memset(xput_handle, 0, FILE_NUM*sizeof(int));
	memset(opt_handle, 0, FILE_NUM*sizeof(int));
	return 1;
}

//update file handle for disk queue reading; 9/9/2018;
void update_disk_handle()
{
	if(fp_diskstats!=NULL)
		disk_handle = fileno(fp_diskstats);
}

//file handle; 2018.8.19;
int check_FD_noctl(int fd_id, int t_id)
{
	int i_ret = 0;

	int i=0;

	//update file handle for disk queue reading; 9/9/2018;
     update_disk_handle();

	for(i=0;i<FILE_NUM;i++)
	{
		if(fd_id==cmd_handle[i] || fd_id==rec_handle[i] || fd_id==mem_handle[i] || fd_id==que_handle[i] || fd_id==net_handle[i] || fd_id==oet_handle[i] || fd_id==pet_handle[i] || fd_id==qet_handle[i] 
			|| fd_id==net_handle1[i] || fd_id==net_handle2[i] || fd_id==disk_handle || fd_id==util_handle || fd_id==dfno || fd_id==efno || fd_id==hfno || fd_id==interface_handle[i] || fd_id==xput_handle[i] || fd_id==opt_handle[i])
		{
			 //Update the interarrival times (us) required for each I/O flow system call delay;
			i_ret = 1;
			break;
		}
	}

	return i_ret;
}

void open_doc()
{
    char str_c[32];
    aslo_log_init();
	int exp_idx = 1;
	int time_idx = 1;
	//sprintf(str_c, "xpslo_preload");
	//sys_xpslo_mon_dis
	sprintf(str_c, WDIR);
	aslo_open_log(str_c, time_idx);
}

#endif