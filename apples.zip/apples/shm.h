#ifndef SHM_H
#define SHM_H

#define TEXT_SZ 2048  
#define MAX_V_NUM 31

struct shared_use_st  
{  
    int written;
    //char text[TEXT_SZ];
	int value[MAX_V_NUM];
}; 

struct shared_use_st *shared = NULL;
void *shm = NULL;
int shmid;

int shm_init()
{
	int i_ret = 1;
	
    shmid = shmget((key_t)1334, sizeof(struct shared_use_st), 0666|IPC_CREAT);  
    if(shmid == -1)  
    {  
        fprintf(stderr, "shmget failed\n");  
        return -1;
    }  
    
    shm = shmat(shmid, 0, 0);  
    if(shm == (void*)-1)  
    {  
        fprintf(stderr, "shmat failed\n");  
        return -1;  
    }  
    printf("\nsys_xpslo_mon Action Database attached at %X\n", shm);  
     
    shared = (struct shared_use_st*)shm;  
    shared->written = 0;  
	memset(shared->value, 0, MAX_V_NUM * sizeof(int));
	return i_ret;
}

int shm_exit()
{
	int i_ret = 1;
	 
    if(shmdt(shm) == -1)  
    {  
        fprintf(stderr, "shmdt failed\n");   
    }  
    
    if(shmctl(shmid, IPC_RMID, 0) == -1)  
    {  
        fprintf(stderr, "shmctl(IPC_RMID) failed\n");  
    }  
	return i_ret;
}

int get_shm_val(int v_idx)
{
	int i_ret = 0;

	if(v_idx<0 || v_idx>=MAX_V_NUM)
		return 0;

	if(shared!=NULL)
		i_ret = shared->value[v_idx];

	return i_ret;
}

/*int get_srv_cmd()
{
	int i_ret = 0;
	char k_cmd[256];
	char * appstr = NULL;
	int val = 0;
	int idx = 0;

	if(shared->written != 0) 
    {  
		if(strlen(shared->text)<256)
			strcpy(k_cmd, shared->text);

	     printf("\nsys_xpslo_mon: get cmd >> %s", k_cmd);
		 i_ret = 1;
    }  

	return i_ret;
}*/
#endif