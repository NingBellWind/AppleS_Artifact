#ifndef FD_H
#define FD_H

#include "common.h"
#include "tail.h"

//Initialization;
void fd_inv_init()
{
	memset(fd_inv_num_arr, 0, MAX_OP_NUM * MAX_FD_NUM * sizeof(int));
	memset(fd_id_map, 0, MAX_FD_VAL * sizeof(short));
	memset(fd_id_list, 0, MAX_FD_NUM * sizeof(int));
	//memset(fd_type_list, 0, MAX_FD_NUM * sizeof(int));
	fd_id_ptr = 1;

    ///////////////////// Distinct net statistics;  /1/24/2019;//////////////////////
	memset(net_inv_num_arr, 0, MAX_OP_NUM * MAX_FD_NUM * sizeof(int));
	memset(net_id_map, 0, MAX_FD_VAL * sizeof(short));
	memset(net_id_list, 0, MAX_FD_NUM * sizeof(int));
	net_id_ptr = 1;
	///////////////////// Distinct net statistics;  /1/24/2019;//////////////////////

	//2019.1.1 for I/O thread waiting for I/O dispatching;
    memset(th_wait_list, 0, MAX_FD_NUM * sizeof(char));
    //2019.1.1 for I/O threads have ever issued I/Os;
    memset(th_erun_list, 0, MAX_FD_NUM * sizeof(char));

	//The user parallsliem limit for the 2nd point;
    P1= expect_users;

	memset(WDIR, 0, 128);
}

int get_fd_idx(int fd_id)
{
	return fd_id_map[fd_id];
}

//get the index of net ID; /1/24/2019;
int get_nd_idx(int nd_id)
{
	return net_id_map[nd_id];
}

//if the FD has been recorded, return 1;
int check_FD(int fd_id)
{
	int i_ret = 0;
	//No thread ID 0; 2018.12.6;
	//if(fd_id >= MAX_FD_VAL || fd_id<0)
	if(fd_id >= MAX_FD_VAL || fd_id<=0)
		return 2;
	if(fd_id_map[fd_id]>0)
		i_ret = 1;
	return i_ret;
}

//if the NetID has been recorded, return 1;  /1/24/2019;
int check_ND(int nd_id)
{
	int i_ret = 0;
	
	if(nd_id >= MAX_FD_VAL || nd_id<=0)
		return 2;
	if(net_id_map[nd_id]>0)
		i_ret = 1;
	return i_ret;
}

//Insert a new FD;
int insert_FD(int fd_id)
{
	int i_ret = 1;

	//The lock for threads; //9/28/2018;
  //pthread_rwlock_wrlock(&rwlock);
	
	//No thread ID 0; 2018.12.6;
	//if(fd_id >= MAX_FD_VAL || fd_id<0)
	if(fd_id >= MAX_FD_VAL || fd_id<=0)
	{
		//pthread_rwlock_unlock(&rwlock);
		return -1;
	}

	if(fd_id_ptr >= MAX_FD_NUM)
	{
		//pthread_rwlock_unlock(&rwlock);
		return -2;
	}
    
   fd_id_map[fd_id] = fd_id_ptr;
   //Add the FD in the list;
   fd_id_list[fd_id_ptr] = fd_id;
   //Set id; 8/23/2018
   flow_id_arr[fd_id_map[fd_id]] .id = fd_id;

    //print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*  char f_str[512];
		  struct timeval e;
	     sc_gettime(&e);
		  sprintf(f_str,"[insert_FD  fd_id_ptr: %05d  fd_id_list: %08d  map: %08d  td: %08d]  (%08d, %08d) >>\n"
			                     , fd_id_ptr,  fd_id_list[fd_id_ptr], fd_id_map[fd_id], fd_id, e.tv_sec, e.tv_usec);
		  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
		  fflush(wstream_mem[0]);*/
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//fd_id_ptr is the number of FDs plus 1;
   fd_id_ptr++;

   //The lock for threads; //9/28/2018;
  // pthread_rwlock_unlock(&rwlock);
	return 1;
}

//Insert a new NetID; //1/24/2019;
int insert_ND(int nd_id, int tid)
{
	int i_ret = 1;

	if(nd_id >= MAX_FD_VAL || nd_id<=0)
	{
		//pthread_rwlock_unlock(&rwlock);
		return -1;
	}

	if(net_id_ptr >= MAX_FD_NUM)
	{
		//pthread_rwlock_unlock(&rwlock);
		return -2;
	}
    
   net_id_map[nd_id] = net_id_ptr;
   //Add the NetID in the list;
   net_id_list[net_id_ptr] = nd_id;
   //Set id; 8/23/2018
   net_id_arr[fd_id_map[nd_id]] .id = nd_id;

    //print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		char f_str[512];
		  struct timeval e;
	     sc_gettime(&e);
		  sprintf(f_str,"[insert_ND  net_id_ptr: %05d  nd_id: %08d  tid: %08d]  (%08d, %08d) >>\n"
			                     , net_id_ptr,  net_id_list[net_id_ptr], tid, e.tv_sec, e.tv_usec);
		  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
		  fflush(wstream_mem[0]);
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//nd_id_ptr is the number of NetIDs plus 1;
   net_id_ptr++;

   //The lock for threads; //9/28/2018;
  // pthread_rwlock_unlock(&rwlock);
	return 1;
}

//Once invoking a syscall for a FD, increase the counter by 1;
int Invoke_FD(int fd_id, int op_type)
{
	int i_ret = 1;
	
//The lock for threads; //9/28/2018;
   pthread_rwlock_wrlock(&rwlock);

	if(!check_FD(fd_id))
	{
		i_ret =  insert_FD(fd_id);

		if(i_ret < 0)
		{
			pthread_rwlock_unlock(&rwlock);
			return -1;
		}
	}

	//Unlock threads; //9/28/2018;
	pthread_rwlock_unlock(&rwlock);

	if(op_type<=0)
		return -2;

	op_type -= 1;
	
	//Recording I/O requests; 2018.12.19
	if(data_rec_f==1)
		fd_inv_num_arr[op_type][fd_id_map[fd_id]]++;

	return i_ret;
}


//Once invoking a syscall for a NetID, increase the counter by 1; //1/24/2019;
int Invoke_ND(int nd_id, int op_type, int tid)
{
	int i_ret = 1;
	
    //The lock for threads; //9/28/2018;
    pthread_rwlock_wrlock(&rwlock);

	if(!check_ND(nd_id))
	{
		i_ret =  insert_ND(nd_id, tid);

		if(i_ret < 0)
		{
			pthread_rwlock_unlock(&rwlock);
			return -1;
		}
	}

	//Unlock threads; //9/28/2018;
	pthread_rwlock_unlock(&rwlock);

	if(op_type<=0)
		return -2;

	op_type -= 1;
	
	//Recording I/O requests; 
	if(data_rec_f==1)
		net_inv_num_arr[op_type][net_id_map[nd_id]]++;

	return i_ret;
}

//Invoking a syscall for a NetID; //1/24/2019;
int Invoke_ND_type(int nd_id, int sys_call, int tid)
{
	int i_ret = 1;
	int op_type = 0;

	if(sys_call == SYS_sendto)
		op_type = 0;
	else if(sys_call == SYS_recvfrom)
		op_type = 1;
	else if(sys_call == SYS_sendmsg)
		op_type = 2;
	else if(sys_call == SYS_recvmsg)
		op_type = 3;

	 i_ret = Invoke_ND(nd_id, op_type, tid);

	return i_ret;
}

//Tell if the system call is net-related; //1/24/2019;
int Is_net(int syscall_number)
{
	int i_ret = 0;

	if( syscall_number == SYS_sendto
	   || syscall_number == SYS_recvfrom
	   || syscall_number == SYS_sendmsg
	   || syscall_number == SYS_bind
	   || syscall_number == SYS_recvmsg)
		i_ret = 1;

	return i_ret;
}

//Tell if the system call is net-related I/O receiving; //1/29/2019;
int Is_net_recv(int syscall_number)
{
	int i_ret = 0;

	if( syscall_number == SYS_recvfrom)
	   //|| syscall_number == SYS_recvmsg)
		i_ret = 1;
	else if( syscall_number == SYS_recvmsg)
		i_ret = 2;

	return i_ret;
}

//Tell if the system call is net-related I/O sending; //12/5/2019;
/*int Is_net_send(int syscall_number)
{
	int i_ret = 0;

	if( syscall_number == SYS_sendmsg)
		i_ret = 1;
	else if( syscall_number == SYS_sendto)
		i_ret = 2;

	return i_ret;
}*/

//Tell if the system call is ppoll-related or epoll I/O receiving; //3/26/2019;
int Is_poll_recv(int syscall_number, int res)
{
	int i_ret = 0;

    //Test; 2019.5.3;
	//if(res<=0)
	//	return i_ret;

	if( syscall_number == SYS_ppoll)
		i_ret = PPOLL_D;
	else if( syscall_number == SYS_epoll_wait)
		i_ret = EPOLL_D;

	return i_ret;
}

//PPOLL_D handing; //3/26/2019;
int pp_idx = 0;
int pp_num = 50;

int ppoll_handle(int syscall_number,  long fds, long nfds, long * res)
{
	int i_ret = 1;

	if(syscall_number!=SYS_ppoll)
		return 0;

	if(pp_idx<pp_num)
		pp_idx++;
	else
		return 0;

	struct pollfd *pfds = (struct pollfd *)fds; 

	int i=0;

	for(i=0;i<nfds;i++)
	{
			  char f_str[256];
			  sprintf(f_str,">ppoll_handle[%06d]: %06d  %06d res = %d\n"
									 , pfds[i].fd, pfds[i].events, pfds[i].revents, *res);
			  //fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
			  //fflush(wstream_mem[0]);
	}

	return i_ret;
}

//Tell if the system call is net-related I/O receiving; //2/1/2019;
int Is_net_send(int syscall_number)
{
	int i_ret = 0;

	if( syscall_number == SYS_sendto)
	  // || syscall_number == SYS_sendmsg)
		i_ret = 1;
    else if( syscall_number == SYS_sendmsg)
		i_ret = 2;
	return i_ret;
}

//Tell if the system call is net-related I/O receiving; //2/1/2019;
int Is_net_connect(int syscall_number)
{
	int i_ret = 0;

	if( syscall_number == SYS_accept)
		i_ret = 11;

	/*if( syscall_number == SYS_connect)
		i_ret = 1;
    else if( syscall_number == SYS_accept)
		i_ret = 2;
	else if( syscall_number == SYS_accept4)
		i_ret = 3;
	elseif( syscall_number == SYS_bind)
		i_ret = 4;
	/*else if( syscall_number == SYS_socket)
		i_ret = 5;*/
	return i_ret;
}

//Tell if the system call is storage-IO-related; //1/29/2019;
int Is_storage(int syscall_number)
{
	int i_ret = 0;

	if( syscall_number == SYS_read
	   || syscall_number == SYS_write 
	   || syscall_number == SYS_readv
	   || syscall_number == SYS_writev
	   || syscall_number == SYS_pread64
	   || syscall_number == SYS_pwrite64
	   || syscall_number == SYS_preadv
	   || syscall_number == SYS_pwritev)
		i_ret = 1;

	return i_ret;
}

//Clean io statistics; 2020.8.24;
void clean_io_rec(int op_type)
{
		int i=0;
		for(i=1;i<=fd_id_ptr;i++)
		{
				 fd_inv_num_arr[op_type][i] = 0;
		}
}

//Get the statistics for a FD;
int get_FD_sta(int fd_id, int op_type)
{
	int i_ret = 0;

   if(fd_id >= MAX_FD_VAL || fd_id<0)
	   return i_ret;

   if(fd_id_map[fd_id] <= 0)
	   return i_ret;

   if(op_type>0)
	{
	     op_type -= 1;
		 i_ret = fd_inv_num_arr[op_type][fd_id_map[fd_id]];
	}
	else
	{
		int i=0;
		for(i=0;i<MAX_OP_NUM;i++)
		{
			i_ret += fd_inv_num_arr[i][fd_id_map[fd_id]];
		}
	}

	//The statistics for qualified I/O intervals;//8/26/2018;
    if( flow_id_arr[fd_id_map[fd_id]].cs_num > th_q_int)
		//frequency statistics; //8/26/2018;
	    flow_id_arr[fd_id_map[fd_id]].count_freq++;

	return i_ret;
}

//Get the statistics for a NetID; //1/24/2019;
int get_ND_sta(int nd_id, int op_type)
{
	int i_ret = 0;

   if(nd_id >= MAX_FD_VAL || nd_id<0)
	   return i_ret;

   if(net_id_map[nd_id] <= 0)
	   return i_ret;

   if(op_type>0)
	{
	     op_type -= 1;
		 i_ret = net_inv_num_arr[op_type][net_id_map[nd_id]];
	}
	else
	{
		int i=0;
		for(i=0;i<MAX_OP_NUM;i++)
		{
			i_ret += net_inv_num_arr[i][net_id_map[nd_id]];
		}
	}

	return i_ret;
}

//Once invoking a syscall for a FD, increase the counter by 1;
int Throttle_FD(int fd_id, int op_type)
{
	int i_ret = 1;

	if(!check_FD(fd_id))
	{
		i_ret =  insert_FD(fd_id);

		if(i_ret < 0)
			return -1;
	}

	if(op_type<=0)
		return -2;

	op_type -= 1;

	fd_thr_num_arr[op_type][fd_id_map[fd_id]]++;

	return i_ret;
}

//Get the throttling action statistics for a FD;
int get_th_sta(int fd_id, int op_type)
{
	int i_ret = 0;

   if(fd_id >= MAX_FD_VAL || fd_id<0)
	   return i_ret;

   if(fd_id_map[fd_id] <= 0)
	   return i_ret;

   /*if(op_type>0)
	{
	     op_type -= 1;
		 i_ret = fd_thr_num_arr[op_type][fd_id_map[fd_id]];
	}
	else
	{
		int i=0;
		for(i=0;i<MAX_OP_NUM;i++)
		{
			i_ret += fd_thr_num_arr[i][fd_id_map[fd_id]];
		}
	}*/

     //for fio read 4KB 50 threads; us;//8/24/2018;
	//i_ret = flow_id_arr[fd_id_map[fd_id]].tail_num;
	//for integral part of sleep time; us;//9/7/2018;
	//i_ret = flow_id_arr[fd_id_map[fd_id]].integral_sleep_time;
	i_ret = flow_id_arr[fd_id_map[fd_id]].integral_sleep_time;

	return i_ret;
}

//Get the throttling time statistics for a FD;
int get_tm_sta(int fd_id, int op_type)
{
	int i_ret = 0;

   if(fd_id >= MAX_FD_VAL || fd_id<0)
	   return i_ret;

   if(fd_id_map[fd_id] <= 0)
	   return i_ret;

    //i_ret = flow_id_arr[fd_id_map[fd_id]] .sleep_time;
	//i_ret = flow_id_arr[fd_id_map[fd_id]] .it_val;

	 //for fio read 4KB 50 threads; us;//8/24/2018;
	//i_ret = flow_id_arr[fd_id_map[fd_id]].head_num;
	//for real-time throughput;//8/26/2018;
	//i_ret = flow_id_arr[fd_id_map[fd_id]].throughput_val;
	i_ret = flow_id_arr[fd_id_map[fd_id]].ave_cs_sleep;

	return i_ret;
}

//Tell if IO speed is valid; 2019.8.28;
int tell_speed(float i_speed)
{
	int i_ret = 1;
	//if(ave_IO_speed > 0 && i_speed < 0.1 * ave_IO_speed)
	if(ave_IO_speed > 0 && i_speed < 0.1 * (100.0/(double)fd_id_ptr) * ave_IO_speed) //2020.8.27;
		return 0;
	return i_ret;
}

//Tell if this thread is I/O intensive and active;//8/26/2018;
int is_active(int fd_id)
{
	int i_ret = 0;

	////////////////////for test///////////////////////////
	return 1;
	////////////////////for test///////////////////////////

	   if(fd_id >= MAX_FD_VAL || fd_id<0)
	   return i_ret;

   if(fd_id_map[fd_id] <= 0)
	   return i_ret;

  //for SSD;
  //Fast SSD;
  //if(flow_id_arr[fd_id_map[fd_id]].count_freq>5)
  //Slow SSD;
 if(flow_id_arr[fd_id_map[fd_id]].count_freq>=1)
  //for HDD;
// if(flow_id_arr[fd_id_map[fd_id]].count_freq>=0)
	   i_ret = 1;

  //2018.12.5 A thread is active only if it accesses the critical I/O resources;
  //if(flow_id_arr[fd_id_map[fd_id]].sched_avoid_f==2)

   /* float i_speed = (float)get_FD_sta(fd_id, 1); 

   //if(flow_id_arr[fd_id_map[fd_id]].sched_avoid_f==2 && flow_id_arr[fd_id_map[fd_id]].count_freq>5)
   if(flow_id_arr[fd_id_map[fd_id]].sched_avoid_f==2 && tell_speed(i_speed)>0)
	   i_ret = 1;*/

	return i_ret;
}

//Get the App-level outstanding I/Os; 2019.3.12;
int get_app_outs()
{
	int outs = 0, i=0;
	for(i=1;i<=fd_id_ptr;i++)
	{
		if(is_active(fd_id_list[i]))
		{
			//get outstanding I/Os; 2019.2.27;
			outs +=  flow_id_arr[fd_id_map[fd_id_list[i]]].head_num;
		}
	}
	return outs;
}

//Get average I/O completions; 2019.8.28;
void get_ave_speed()
{
	int i=0;
	float fout = 0;
	int real_num = 0;

	for(i=1;i<=fd_id_ptr;i++)
	{
		if(flow_id_arr[i].sched_avoid_f == 2)
		{
			//get outstanding I/Os; 2019.2.27;
			fout +=  (float)get_FD_sta(fd_id_list[i], 1); 
			real_num++;
		}
	}

	if(real_num > 0)
	{
		fout /= real_num;
		ave_IO_speed = fout;
	}
}

int eff_fairness_guarantee(int op_type)
{
	int i_ret = 1;
	int i = 0;
	int s_val = 0;
	int max_s_val = 0;
	int min_s_val = 99999999;
	int ave_s_val = 0;
	int real_num = 0;

 if(fairness_low_b != 9 * fairness_high_b/10)
	fairness_low_b = 9 * fairness_high_b/10;

 if(latencyCV_low_b != 9 * latencyCV_high_b/10)
	latencyCV_low_b = 9 * latencyCV_high_b/10;

	 //for syscall statistics;
	for(i=1;i<=fd_id_ptr;i++)
	{
		s_val = get_FD_sta(fd_id_list[i], op_type);
		
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 
	&& s_val > 0) //2021.2.4;
		{
			if(s_val > max_s_val)
				max_s_val = s_val;
			if(s_val < min_s_val)
				min_s_val = s_val;

			ave_s_val += s_val;

			real_num++;
		}
	}

	if(real_num > 0)
		ave_s_val /= real_num;
	
	if(ave_s_val>1 && real_num>0)
	{
			int max_s_dev = 10000 * (max_s_val - ave_s_val)/ave_s_val;
			int min_s_dev = 10000 * (ave_s_val - min_s_val)/ave_s_val;

			last_fairness_v = fairness_v;

			if(max_s_dev > min_s_dev)
				fairness_v = max_s_dev;
			else
				fairness_v = min_s_dev;

			//Standard deviation; 2019.7.22
			int e=0;
			for(i=1;i<=fd_id_ptr;i++)
		   {
				if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2)
			   {
					int tval = get_FD_sta(fd_id_list[i], op_type);
					if(tval>0) //2021.2.4;
						e += (tval - ave_s_val) * (tval - ave_s_val);
			   }
		   }
			
			if(real_num>1)
				e /= real_num-1;
			
			last_fairness_d = fairness_d;
			fairness_d = (int)sqrt((float)e);
	}
    
	la_DATA_SET = DATA_SET;
    
	if(fairness_f)
	{
		if((fairness_high_b > 0 && fairness_v >= fairness_high_b /*&& (last_fairness_v>0 && fairness_v - last_fairness_v > fairness_high_b/8)*/) 
		  || (latencyCV_high_b > 0 && latencyCV_v >= latencyCV_high_b /*&& (last_latencyCV_v>0 && latencyCV_v - last_latencyCV_v > latencyCV_high_b/8)*/ ))
		{
			if(DATA_SET/fairness_step >= DATA_SET_min)
				DATA_SET /= fairness_step;
			else
				DATA_SET = DATA_SET_min;
		}
		else if((fairness_high_b > 0 && fairness_v > 0 && fairness_v < fairness_low_b /*&& last_fairness_v - fairness_v >fairness_high_b/8*/)
			  &&(latencyCV_high_b > 0 && latencyCV_v > 0 && latencyCV_v < latencyCV_low_b /*&& last_latencyCV_v - latencyCV_v > latencyCV_high_b/8*/))
		{
			if(DATA_SET+fairness_unit <= DATA_SET_max)
				DATA_SET += fairness_unit;
		}

		if(la_DATA_SET != DATA_SET)
		for(i=1;i<=fd_id_ptr;i++)
		{
			//Setup req_token[i];
			req_token[i] = pri_weight[i] * DATA_SET;

			if(req_token[i] < 1)
				req_token[i] = 1;
		}
	}

	last_latencyCV_v = latencyCV_v;

	return i_ret;
}

//Print all the statistical information for all the FDs;
//0:all;1: reads; 2:writes;
int pnt_FD_sta(int op_type)
{
	int i_ret = 1;

	if(fd_id_ptr<=0)
		return 0;

    char str_line[10240];
	char ptr_line[512];
	char str_line1[40960];
	memset(str_line, 0, 10240);

	int s_val = 0, t_val = 0, i=0;
	int max_val = 0;
	int ave_val = 0;
	int a_val  = 0;
	int b_val = 0;
	int c_val = 0;
	int pidx = 0;
	//outstanding I/Os;
	int out_io = 0;

     //for syscall statistics;
	 if(!disable_logs)
	{
		for(i=1;i<=fd_id_ptr;i++)
		{
			s_val = 0; //2021.2.4;
			s_val = get_FD_sta(fd_id_list[i], op_type);
			
			if((is_active(fd_id_list[i]) || recording_all) && flow_id_arr[i].sched_avoid_f == 2)
			{
				if(s_val > max_val)
				{
					max_val = s_val;
					fd_throttle = fd_id_list[i];
				}

				//sprintf(ptr_line,"ID:%6d V:%8d  ",  fd_id_list[i], s_val);
				if(s_val>0){ //2021.2.4;
					sprintf(ptr_line,"%08d ",   s_val);
					strcat(str_line, ptr_line);
					pidx++;
				}
			}
		}

	   if(pidx>0)
		{
			strcat(str_line, "\n");
			fwrite(str_line,1,strlen(str_line),wstream_rec[0]);
			fflush(wstream_rec[0]);
		}
	}

	 //for throttling time statistics;
	memset(str_line, 0, 10240);
	 pidx = 0;

	 //Statistics for special logged users; 2019.3.6
	 int s_avx[3];
	 int s_b_val[3];
	 int s_c_val[3];
	 int s_out_io[3];
	 int s_a_val[3];

	 //for special logged users; 2019.4.3
	 if(logged_fuser_id>0)
	 for(i=logged_fuser_id;i<=logged_fuser_id+2;i++)
	{
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2)
		{
			//The ave congestion time (us); //12/15/2018;
			flow_id_arr[fd_id_map[fd_id_list[i]]].ave_cs_sleep =  flow_id_arr[fd_id_map[fd_id_list[i]]].cs_sleep_time/(flow_id_arr[fd_id_map[fd_id_list[i]]].cs_num+1);

			s_avx[i-logged_fuser_id] = get_tm_sta(fd_id_list[i], op_type);

			s_b_val[i-logged_fuser_id] = flow_id_arr[fd_id_map[fd_id_list[i]]].sched_times;

			s_c_val[i-logged_fuser_id] = flow_id_arr[fd_id_map[fd_id_list[i]]].cs_num;
			
			//get outstanding I/Os; 2019.2.27;
			s_out_io[i-logged_fuser_id] =  flow_id_arr[fd_id_map[fd_id_list[i]]].head_num;
			
			//flow_id_arr[fd_id_map[fd_id_list[i]]].sta_times : all the inter-arrival times for each individual users;
			s_a_val[i-logged_fuser_id] =  flow_id_arr[fd_id_map[fd_id_list[i]]].sta_times / (flow_id_arr[fd_id_map[fd_id_list[i]]].cs_num + 1);
		}
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	 
	//for(i=logged_fuser_id+3;i<=fd_id_ptr;i++) // from the common user;
	for(i=1;i<=fd_id_ptr;i++) // from the 1st user;
	{
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2)
		{
			//The ave congestion time (us); //12/15/2018;
			//if(flow_id_arr[fd_id_map[fd_id_list[i]]].long_cs_num>0)
			//flow_id_arr[fd_id_map[fd_id_list[i]]].ave_cs_sleep =  flow_id_arr[fd_id_map[fd_id_list[i]]].cs_sleep_time/(flow_id_arr[fd_id_map[fd_id_list[i]]].long_cs_num+1);
			flow_id_arr[fd_id_map[fd_id_list[i]]].ave_cs_sleep =  flow_id_arr[fd_id_map[fd_id_list[i]]].cs_sleep_time/(flow_id_arr[fd_id_map[fd_id_list[i]]].cs_num+1);

			s_val = get_tm_sta(fd_id_list[i], op_type);

			b_val += flow_id_arr[fd_id_map[fd_id_list[i]]].sched_times;

			c_val += flow_id_arr[fd_id_map[fd_id_list[i]]].cs_num;

			ave_val += s_val;
			
			//get outstanding I/Os; 2019.2.27;
			out_io +=  flow_id_arr[fd_id_map[fd_id_list[i]]].head_num;

			//a_val += flow_id_arr[fd_id_map[fd_id_list[i]]].throughput_slo;
            //2018.12.16 for the ratio of user-delay/kernel-delay;
			//t_val = flow_id_arr[fd_id_map[fd_id_list[i]]].ave_it_val;
			//t_val = flow_id_arr[fd_id_map[fd_id_list[i]]].long_sta_times;
			//t_val = flow_id_arr[fd_id_map[fd_id_list[i]]].long_cs_num;

			//t_val =  flow_id_arr[fd_id_map[fd_id_list[i]]].long_sta_times / (flow_id_arr[fd_id_map[fd_id_list[i]]].long_cs_num + 1);

			//flow_id_arr[fd_id_map[fd_id_list[i]]].sta_times : all the inter-arrival times for each individual users;
			t_val =  flow_id_arr[fd_id_map[fd_id_list[i]]].sta_times / (flow_id_arr[fd_id_map[fd_id_list[i]]].cs_num + 1);
			flow_id_arr[fd_id_map[fd_id_list[i]]].ave_it_val = t_val;
			a_val += t_val;
			pidx++;
		}
	}

		//////////////////////////////////////////////TEST///////////////////////////////////////////////
		//sprintf(ptr_line,">>> pidx: %08d \n",   pidx);
		//fwrite(ptr_line,1,strlen(ptr_line),wstream_cmd[0]);
		//fflush(wstream_cmd[0]);
		/////////////////////////////////////////////////////////////////////////////////////////////

     if(pidx>0)
	{
		 ave_val /= pidx;
		 a_val /= pidx;
		 //c_val /= pidx;

		 //a_val = (a_val * 1200)/1000;

		 //The central throughput target;//8/26/2018;
		 if(ctl_central_val)
		{
		// if(ave_val<a_val)
			if(1)
				central_throughput_slo = a_val;
			 else
				central_throughput_slo = ave_val;
			
			int usec_time = 1000000;
			struct timeval e;
			sc_gettime(&e);
			app_sta_times = utime_since(&app_last_tv, &e);
			unsigned long long um_ll = app_cs_num * usec_time;
			//if(app_sta_times>0)
			//	total_th =  um_ll/(app_sta_times + 1);  //2018.12.27;
		}

		active_thread_num = pidx;

		//the number of concurrent thread within 250 ms;//9/8/2018;
		int con_num =  get_con_threads_num();

		int A = (pidx+1)/thread_con;

		int avx =  ave_val;

		int ratio_p = 0;

        //if(A>1)
		//	avx =  ave_val/(A - 1);
        
		if(c_val>=0)
		{
			////////////////////////////////////////////////////////////////////////////////////
			//FLEXIBLE CONTROL; 2019.3.4; 
			if(last_com_req_per<=0)
				last_com_req_per = c_val;
			else
			{
				ratio_com_req_per3 = ratio_com_req_per2;
				ratio_com_req_per2 = ratio_com_req_per;
				ratio_com_req_per = (1000 * c_val)/(last_com_req_per+1);
				
				ratio_p = ratio_com_req_per;

			     if(ratio_p<1500 && ratio_com_req_per2>1000)
				{
					ratio_p = (ratio_p * ratio_com_req_per2)/1000;

					if(ratio_p < 1500 && ratio_com_req_per3>1000)
						ratio_p = (ratio_p * ratio_com_req_per3)/1000;
				}


				if(ratio_com_req_per< 700 && flex_state != 1) 
				{
					last_flex_state = flex_state;
					//with at least one  apples_induced delay;
					//max_apples_delay = 0;
					//with no apples_induced delay;
					//dis_app_delay_f = 1;
					flex_state = 1;
					flex_times = 0;
				}
				else if((ratio_p>1500 || ratio_com_req_per2>1800) && dis_app_delay_f==1 && (flex_state<=0 || (flex_state==1 && flex_times>4)))  
				{
					last_flex_state = flex_state;
					//max_apples_delay = 100000;
					//dis_app_delay_f = 0;
					flex_state = 2;
					flex_times = 0;
				}
				else
				{
					flex_times++;
				}
				//else
				//	max_apples_delay = 10;
				last_com_req_per2 = last_com_req_per;
				last_com_req_per = c_val;
			}
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			//pidx: the number of controlled users;
			//app_cs_num: the number of all the issued requests;
			//c_val: the number of issued requests among users for this round (e.g., 100 ms);
			//b_val:  the number of scheduling actions for this round  (e.g., 100 ms);
			//out_io; the number of outstanding requests;
			//DATA_SET: the control parameter for locality and sequentiality;
			//latencyCV_v: latency variability : 1000 * CV;
			//fairness_v: fairness measure:  10000* MAX(abs(max-ave), abs(min-ave)/ave);
			
			if(!disable_logs)
			{
				sprintf(ptr_line,"%08d %08d %08d %08d %08d %08d %08d %08d",   pidx /*fairness_f*/, app_cs_num, c_val, b_val, out_io, DATA_SET, /*fairness_d*/latencyCV_v, fairness_v);
				strcat(str_line, ptr_line);
				//The number of recordings;
				rec_rounds++;
			}

			 //2019.4.1 max_apples_delay reference;
			 max_apples_delay_ref = avx;
             
			 //2019.7.24 set max_apples_delay automatically;
			 //max_apples_delay = 2 * max_apples_delay_ref;
			
			if(!disable_logs)
			{
				strcat(str_line, "\n");
				fwrite(str_line,1,strlen(str_line),wstream_cmd[0]);
				fflush(wstream_cmd[0]);
			}
			
			/*************************************Tail latency guarantee 2019.12.17*************************************/
			//translate latency slos into throughput slos; 
			//gamma is the default value of STD/mean;
			 translate_lat_slo(2.0);
			 int k_p = 0;
			 memset(str_line1, 0, 40960);
			
			//1) get the control target derived from average mean lat among LS users; 2020.4.18;
			if(static_pri_set) get_target_ls_mean();

			//wstream_net[0] for mean, std values and gamma, mean slos;
			if(!disable_logs){
				//The ave Gamma among all the user workloads; 2021.4.19;
				float ave_gamma = 0.0;

				//The ave Gamma for all the requests among all the user workloads;
				float ave_gamma_allreq = 0.0;

				for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
						//double ga = gamma_val(i);
						//sprintf(ptr_line,"%08.2f	",   app_mean_arr[i]);
						sprintf(ptr_line,"%08.2f	",   app_mean_allreq_arr[i]);
						strcat(str_line1, ptr_line);
						
						//The ave Gamma among all the user workloads; 2021.4.19;
						ave_gamma += app_std_arr[i]/app_mean_arr[i];
						ave_gamma_allreq += app_std_allreq_arr[i]/app_mean_allreq_arr[i];
						k_p++;
					}
				}

				if(k_p>0){
					strcat(str_line1, "\n");
					fwrite(str_line1,1,strlen(str_line1),wstream_net[0]);
					fflush(wstream_net[0]);

					//The ave Gamma among all the user workloads; 2021.4.19;
					ave_gamma /= k_p;
					ave_gamma_allreq /= k_p;
					latencyCV_v = ave_gamma_allreq * 1000;
				}

				memset(str_line1, 0, 40960);
				
				//The ave Gamma among all the user workloads; 2021.4.19;
				sprintf(str_line1,"%08.2f	%08.2f	",  ave_gamma_allreq, ave_gamma);
				
				//Gamma;
				for(i=1;i<=fd_id_ptr;i++){
					///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					//2021.9.1 for print out CV across users;
					//if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
					///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						//float ffv = (float)req_token[i];
						float ffv = 0;
						//ffv = app_std_arr[i]/app_mean_arr[i];
						ffv = app_std_allreq_arr[i]/app_mean_allreq_arr[i];
						sprintf(ptr_line,"%08.2f	",  ffv);
						strcat(str_line1, ptr_line);
					}
				}

                //Standard deviation;
				/*for(i=1;i<=fd_id_ptr;i++){
					//if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
						//sprintf(ptr_line,"%08.2f	",   app_std_arr[i]);
						float ffv = 0;
						//if(static_pri_set){
						//	ffv = (float)flow_id_arr[i].wt_ratio;
						//}else{
						//	ffv = (float)flow_id_arr[i].times_delay;
						//}
						ffv = app_std_arr[i];
						sprintf(ptr_line,"%08.2f	",  ffv);
						strcat(str_line1, ptr_line);
					}
				}
				
				//MP tail SLO violations;
				for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
						int j=0;
						for(j=0;j<1;j++){
						sprintf(ptr_line,"%08d	",   app_latvio_arr[i][j]);
						strcat(str_line1, ptr_line);
						}
						k_p++;
					}
				}

				for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
						int j=0;
						for(j=1;j<2;j++){
						sprintf(ptr_line,"%08d	",   app_latvio_arr[i][j]);
						strcat(str_line1, ptr_line);
						}
					}
				}

				for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
						int j=0;
						for(j=2;j<MAX_PER;j++){
						sprintf(ptr_line,"%08d	",   app_latvio_arr[i][j]);
						strcat(str_line1, ptr_line);
						}
					}
				}*/

				if(k_p>0){
					strcat(str_line1, "\n");
					fwrite(str_line1,1,strlen(str_line1),wstream_oet[0]);
					fflush(wstream_oet[0]);
				}else{
					sprintf(str_line1, "No active users!\n");
					fwrite(str_line1,1,strlen(str_line1),wstream_oet[0]);
					fflush(wstream_oet[0]);
				}

				memset(str_line1, 0, 40960);

				//Give each user throughput performance;
				get_user_throughput();

				for(i=1;i<=fd_id_ptr;i++){
				//for(i=1;i<=fd_id_ptr && i<MAX_GUA_NUM;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
						double ga = gamma_val(i);
						//sprintf(ptr_line,"%8.2f ",  ga);

						//float ffv = (float)req_token[i];

						float ffv = (float)app_pnt_arr[i];
						sprintf(ptr_line,"%08.2f	",  ffv);

						//sprintf(ptr_line,"%8d ",  flow_id_arr[i].times_delay);
						//sprintf(ptr_line,"%8d ",  pp_tmp1);							
						/**************************P99 prediction-actual measure verification******************************/
						//the idx user;
						//lat_p99: P99 tail latency in ms (23.5 ms);
						//pred_lat_p99: the estimated P99 tail latency;
						/*double lat_p99 = 0.0,  pred_lat_p99 = 0.0;
						int st = get_tail_latency_p99(i, &lat_p99, &pred_lat_p99);
						if(st)
						{
							sprintf(ptr_line,"%08.2f	%08.2f	",  lat_p99, pred_lat_p99);
							lat_p_arr[i] = lat_p99;
							lat_t_arr[i] = pred_lat_p99;
						}
						else if(lat_p_arr[i] > 0.01 || lat_t_arr[i]>0.01){
							sprintf(ptr_line,"%08.2f	%08.2f	",  lat_p_arr[i], lat_t_arr[i]);
						}
						else{
							sprintf(ptr_line,"%08.2f	%08.2f	",  lat_p99, pred_lat_p99);
						}*/
						/**************************P99 prediction-actual measure verification******************************/
						strcat(str_line1, ptr_line);
					}
				}

				if(k_p>0){
					strcat(str_line1, "\n");
					fwrite(str_line1,1,strlen(str_line1),wstream_pet[0]);
					fflush(wstream_pet[0]);
				}else{
					sprintf(str_line1, "No active users!\n");
					fwrite(str_line1,1,strlen(str_line1),wstream_pet[0]);
					fflush(wstream_pet[0]);
				}

				memset(str_line1, 0, 40960);

				for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
						sprintf(ptr_line,"%08.2f	",  app_meanslo_arr[i]);
						strcat(str_line1, ptr_line);

						//sprintf(ptr_line,"%08d	",    flow_id_arr[i].cs_sleep_time);
						//strcat(str_line1, ptr_line);
					}
				}
				
				if(k_p>0){
					strcat(str_line1, "\n");
					fwrite(str_line1,1,strlen(str_line1),wstream_qet[0]);
					fflush(wstream_qet[0]);
				}
			}

			k_p = 0;
			 memset(str_line1, 0, 40960);
			//wstream_net1[0] for P95, P99 and P99.9 latencies violation or not;
			if(!disable_logs){
				for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
						int j=0;
						//for(j=0;j<MAX_PER;j++){
						for(j=0;j<1;j++){
						//sprintf(ptr_line,"%08d	",   app_latvio_arr[i][j]);
						sprintf(ptr_line,"%08d	",   app_ptail_loc[i][j]);
						strcat(str_line1, ptr_line);
						}
						k_p++;
					}
				}

				for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
						int j=0;
						for(j=1;j<2;j++){
						//sprintf(ptr_line,"%08d	",   app_latvio_arr[i][j]);
						sprintf(ptr_line,"%08d	",   app_ptail_loc[i][j]);
						strcat(str_line1, ptr_line);
						}
					}
				}

				for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
						int j=0;
						for(j=2;j<MAX_PER;j++){
						//sprintf(ptr_line,"%08d	",   app_latvio_arr[i][j]);
						sprintf(ptr_line,"%08d	",   app_ptail_loc[i][j]);
						strcat(str_line1, ptr_line);
						}
					}
				}
				
				if(k_p>0){
					strcat(str_line1, "\n");
					fwrite(str_line1,1,strlen(str_line1),wstream_net1[0]);
					fflush(wstream_net1[0]);
				}
			}

			k_p = 0;
			memset(str_line1, 0, 40960);
			//wstream_net2[0] for P95, P99 and P99.9 latencies violations;
			if(!disable_logs){
				for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
						int j=0;
						//for(j=0;j<MAX_PER;j++){
						for(j=0;j<1;j++){
						//sprintf(ptr_line,"%08d	",   app_latvio_arr[i][j]);
						sprintf(ptr_line,"%08d	",   app_ptail_glb[i][j]);
						strcat(str_line1, ptr_line);
						}
						k_p++;
					}
				}

                 for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
						int j=0;
						for(j=1;j<2;j++){
						//sprintf(ptr_line,"%08d	",   app_latvio_arr[i][j]);
						sprintf(ptr_line,"%08d	",   app_ptail_glb[i][j]);
						strcat(str_line1, ptr_line);
						}
					}
				 }

                for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
						int j=0;
						for(j=2;j<MAX_PER;j++){
						//sprintf(ptr_line,"%08d	",   app_latvio_arr[i][j]);
						sprintf(ptr_line,"%08d	",   app_ptail_glb[i][j]);
						strcat(str_line1, ptr_line);
						}
					}
				}
				
				if(k_p>0){
					strcat(str_line1, "\n");
					fwrite(str_line1,1,strlen(str_line1),wstream_net2[0]);
					fflush(wstream_net2[0]);
				}
			}
			/*************************************Tail latency guarantee 2019.12.17*************************************/

           //Statistics for LL and HL status; 2020.8.12;
		   double ratio_LL = 0.0;
			if(period_LL + period_HL > 0){
				ratio_LL = (double)period_LL/((double)period_LL + (double)period_HL);
			}
			
			if(tot_period_LL + tot_period_HL > 0){
				tot_ratio_LL = (double)tot_period_LL/((double)tot_period_LL + (double)tot_period_HL);
			}
		   sprintf(str_line1,"%08d %08d %08.2f %08.2f %08.2f %08d %08d %08.2f %08.2f %08.2f %08.2f %08.2f %08.2f %08.2f %08d "
			                           , pre_sys_running_status, sys_running_status, sys_ave_xput, sys_LL_xput, sys_HL_xput, period_LL, period_HL, ratio_LL, tot_ratio_LL, his_sys_ave_xput, his_sys_LL_xput, his_sys_HL_xput, BE_xput, his_BE_xput, sys_state);
		   for(i=1;i<=fd_id_ptr;i++){
					if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
						if(is_user_priviliged(i)){
							sprintf(ptr_line,"%08d	 %08.2f	 %08.2f	",   req_token[i], perror_arr[i], quota_arr[i]);
							//sprintf(ptr_line,"%08d	 %08.2f	 %08.2f	",   req_token[i], app_thptslo_arr[i], his_quota_arr[i]);
							strcat(str_line1, ptr_line);
						}else{
							sprintf(ptr_line,"%08d	%08d	",   flow_id_arr[i].times_delay, req_token[i]);
							strcat(str_line1, ptr_line);
							break;
						}
					}
		   }
		   strcat(str_line1, "\n");
		   fwrite(str_line1,1,strlen(str_line1),wstream_xput[0]);
		   fflush(wstream_xput[0]);
		   /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			 //Statistics for specially logged users; 2019.3.6
			 int h = 0, pnt_disable=1;
			 if(logged_fuser_id>0 && !disable_logs && !pnt_disable)
			 for(h=0;h<3;h++)
			{
				sprintf(ptr_line,"%08d %08d %08d %08d %08d %08d %08d %08d %08d %08d %08d %08d ",   s_avx[h], s_a_val[h], (1000 * s_avx[h])/(s_a_val[h]+1), pidx, app_cs_num, s_c_val[h], s_b_val[h], s_out_io[h], ratio_com_req_per, ratio_p, max_apples_delay, dis_app_delay_f);
				strcat(ptr_line, "\n");
				if(h==0)
				{
					fwrite(ptr_line,1,strlen(ptr_line),wstream_net[0]);
					fflush(wstream_net[0]);
				}
				else if(h==1)
				{
					fwrite(ptr_line,1,strlen(ptr_line),wstream_net1[0]);
					fflush(wstream_net1[0]);
				}
				else if(h==2)
				{
					fwrite(ptr_line,1,strlen(ptr_line),wstream_net2[0]);
					fflush(wstream_net2[0]);
				}
			}
			//////////////////////////////////////////////////////////////////////////
		}
	}

	return i_ret;
}

/*************************************2018.11.5**************************************/
//Distinct file names;  /11/5/2018;
int ana_file_id(int tid, int fid)
{
	int i=0;

	if(noctl_tid<=0)
		return 0;

    if(file_id_list[fid] > 0)
		return file_id_list[fid];

	char fd_path[256];
	char filename[256];
	memset(filename, 0, 256);
	 ssize_t n;

	 //Get the absolute file name;
	 sprintf(fd_path, "/proc/self/fd/%d", fid);
	 n = readlink(fd_path, filename, 255);
	 if (n < 0)
	{
	  //print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  /*char f_str1[128];
	  sprintf(f_str1,"[S  fd : %05d  tn: %05d td: %08d]  >>  filename = %s\n"
		                     , fid,  fd_id_ptr, tid, filename);
	  fwrite(f_str1,1,strlen(f_str1),wstream_mem[i]);
	  fflush(wstream_mem[i]);*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		  //return -1;
		  sprintf(filename, "No name fd:%d", fid);
	}
    else
		filename[n] = '\0';

	 //Check if the file name has existed;
	for(i=0; i<dist_file_num; i++)
	{
		if(!strcmp(filename, dist_file_name[i]))
			//Return distinct file ID, minus one is the index;
			return i+1;
	}

	 //print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  /*char f_str[128];
	  struct timeval e;
      sc_gettime(&e);
	  sprintf(f_str,"[S  fd : %05d  tn: %05d td: %08d]  (%08d, %08d) >>  filename = %s\n"
		                     , fid,  fd_id_ptr, tid, e.tv_sec, e.tv_usec, filename);
	  fwrite(f_str,1,strlen(f_str),wstream_mem[i]);
	  fflush(wstream_mem[i]);*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//Add the file name;
	if(dist_file_num < MAX_DIST_FNUM)
	{
		sprintf(dist_file_name[dist_file_num++], filename);

		if(fid < MAX_FD_VAL)
			file_id_list[fid] = dist_file_num;

		 //print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			 char f_str[512];
			  struct timeval e;
		      sc_gettime(&e);
			  sprintf(f_str,"[S  fd : %05d  tn: %05d td: %05d]  (%08d, %08d) >>  dist_file_num = %04d, noctl_tid = %04d, fn = %s\n"
				                     , fid,  fd_id_ptr-1, tid, e.tv_sec, e.tv_usec, dist_file_num, noctl_tid, filename);
			  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
			  fflush(wstream_mem[0]);
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	}

	return dist_file_num;
}

//Set up file IDs for each correlated threads;
int add_file_id_th(int tid, int fid)
{
	int i_ret = 1, i=0;

	//Never running in non-thread-index case;
	if(!THREAD_ID_F || file_id_list[fid]<=0)
		return 0;

	int idx = get_fd_idx(tid);

   //Check if having the file ID already;
	for(i=0; i<flow_id_arr[idx].file_id_num; i++)
	{
		if(fid == flow_id_arr[idx].file_id_ser[i])
			return 0;
	}

	//Add the file ID;
	if(flow_id_arr[idx].file_id_num < MAX_TH_FILE_NUM)
		flow_id_arr[idx].file_id_ser[flow_id_arr[idx].file_id_num++] = fid;

	//print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/*char f_str[512];
	struct timeval e;
	sc_gettime(&e);
	sprintf(f_str,"[A  fd : %05d  idx: %05d td: %05d]  (%08d, %08d) >>  dist_file_num = %04d, idn = %04d\n"
		                     , fid,  idx, tid, e.tv_sec, e.tv_usec, file_id_list[fid], flow_id_arr[idx].file_id_num);
	fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
	fflush(wstream_mem[0]);*/
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	return i_ret;
}

//Set up socket IDs for each correlated threads; 2019.1.24;
int add_net_id_th(int tid, int nid)
{
	int i_ret = 1, i=0;

	//Never running in non-thread-index case;
	if(!THREAD_ID_F || net_id_list[nid]<=0)
		return 0;

	int idx = get_fd_idx(tid);

   //Check if having the net ID already;
	for(i=0; i<flow_id_arr[idx].net_id_num; i++)
	{
		if(nid == flow_id_arr[idx].net_id_ser[i])
			return 0;
	}

	//Add the net ID;
	if(flow_id_arr[idx].net_id_num < MAX_TH_NETF_NUM)
		flow_id_arr[idx].net_id_ser[flow_id_arr[idx].net_id_num++] = nid;

	//print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/*char f_str[512];
	struct timeval e;
	sc_gettime(&e);
	sprintf(f_str,"[A  fd : %05d  idx: %05d td: %05d]  (%08d, %08d) >>  dist_net_num = %04d, idn = %04d\n"
		                     , fid,  idx, tid, e.tv_sec, e.tv_usec, net_id_list[nid], flow_id_arr[idx].net_id_num);
	fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
	fflush(wstream_mem[0]);*/
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	return i_ret;
}

//Set up thread IDs for each correlated users; 2020.3.29;
int add_thread_id_th(int idx, int tid)
{
	int i_ret = 1, i=0;

   //Check if having the net ID already;
	for(i=0; i<flow_id_arr[idx].net_id_num; i++)
	{
		if(tid == flow_id_arr[idx].net_id_ser[i])
			return 0;
	}

	//Add the net ID;
	if(flow_id_arr[idx].net_id_num < MAX_TH_NETF_NUM)
		flow_id_arr[idx].net_id_ser[flow_id_arr[idx].net_id_num++] = tid;

	//print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	char f_str[128];
	struct timeval e;
	sc_gettime(&e);
	sprintf(f_str,"(<=> user[ %05d]  => td: %05d)  (%08d, %08d) >>  idn = %04d\n"
		                     , idx, tid, e.tv_sec, e.tv_usec, flow_id_arr[idx].net_id_num);
	fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
	fflush(wstream_mem[0]);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	return i_ret;
}

//2018.12.13 to decide when to run als control;
int open_als_sig()
{
	int i_ret = 1;

	dstream = fopen("./als_ctl.txt","r");

	if(dstream==NULL)
	{
		printf("\nThe als_ctl.txt cannot be opened!\n");
		return 0;
	}

	dfno = fileno(dstream);

	return i_ret;
}

int read_als_sig()
{
	int i_ret = 0;

	if(dstream==NULL)
		return i_ret;

	char line[16];
	memset(line, 0, 16);
	lseek(dfno,0L,SEEK_SET);
	
	if(fgets(line, 16, dstream))
	{
		i_ret = atoi(line);
	}

	return i_ret;
}

//Read critical resource configurations; 2018.11.5
/*int read_critical_cfg()
{
	int i_ret = 1;
	FILE * cstream = fopen("./critical_res.txt","r");

	if(cstream==NULL)
	{
		printf("\nThe file critical_res.txt cannot be read!\n");
		return 0;
	}

	int handle = fileno(cstream);

	char line[128];
	memset(line, 0, 128);
	lseek(handle,0L,SEEK_SET);
	
	while(fgets(line, 128, cstream))
	{
		if(res_num < MAX_RES_NUM)
		{
			//sprintf(res_str_arr[res_num++], line);
			strncpy(res_str_arr[res_num++],line,strlen(line)-1);

			 //print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			  char f_str[128];
			  struct timeval e;
			  sc_gettime(&e);
			  sprintf(f_str,"Initialization (%08d, %08d) >>  read_critical_cfg[%d] = %s\n"
									 , e.tv_sec, e.tv_usec, res_num, res_str_arr[res_num-1]);
			  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
			  fflush(wstream_mem[0]);
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		}
	}

	fclose(cstream);
	cstream = NULL;

	return i_ret;
}*/

//Read critical resource configurations; 2018.11.5
int read_critical_cfg()
{
	int i_ret = 1;
	FILE * cstream = fopen("./apples_configuration.txt","r");

	if(cstream==NULL)
	{
		printf("\nThe file apples_configuration.txt cannot be read!\n");
		return 0;
	}

	int handle = fileno(cstream);

	char line[128];
	memset(line, 0, 128);
	lseek(handle,0L,SEEK_SET);

	char *appstr;
	char str_tmp[32];
	
	while(fgets(line, 128, cstream))
	{
		////////////////////////////////////////////////////////////
		//printf("\n%s\n", line);
		////////////////////////////////////////////////////////////
		if ((appstr = strstr(line, "database")) != NULL)
		{
			sscanf(appstr, "database: %s", str_tmp);

			if(!strcmp(str_tmp, "mysql") || !strcmp(str_tmp, "MYSQL") || !strcmp(str_tmp, "MySQL")){
				app_type = 1;
			}
			if(!strcmp(str_tmp, "mongodb") || !strcmp(str_tmp, "MONGODB") || !strcmp(str_tmp, "MongoDB")){
				app_type = 2;
			}
		}

			if ((appstr = strstr(line, "version")) != NULL)
			{
				sscanf(appstr, "version: [%d.%d.%d]", &app_fver, &app_sver, &app_tver);
				app_version = app_fver * 10000 + app_sver * 100 + app_tver;

				//Concurrency must be tested under DATA_SET = 1; 2019.4.1;
				if(app_type==1){
					   if (app_fver>=8 && app_sver==0 && app_tver>=20){
							DATA_SET = 1;
							DATA_SET_min = 1;
					   }else{
						    DATA_SET = 16;
							DATA_SET_min = 16;
					   }
					}
				else{
					DATA_SET = 4;
					DATA_SET_min = 4;
				}
			}

			if ((appstr = strstr(line, "working_directory")) != NULL)
			{
				sscanf(appstr, "working_directory: %s", &WDIR);
				folder_mkdirs(WDIR);
			}

			if ((appstr = strstr(line, "expect_users")) != NULL)
			{
				sscanf(appstr, "expect_users: %u", &expect_users);
			}

			if ((appstr = strstr(line, "disable_apples")) != NULL)
			{
				sscanf(appstr, "disable_apples: %u", &disable_apples);
			}

			if ((appstr = strstr(line, "eff_delay")) != NULL)
			{
				sscanf(appstr, "eff_delay: %u", &eff_delay);
			}

			if ((appstr = strstr(line, "control_interval")) != NULL)
			{
				sscanf(appstr, "control_interval: %u", &CTL_T_NUM);
			}

			if ((appstr = strstr(line, "measure_rounds")) != NULL)
			{
				sscanf(appstr, "measure_rounds: %u", &CTL_M_NUM);
			}

			if ((appstr = strstr(line, "sampling_rounds")) != NULL)
			{
				sscanf(appstr, "sampling_rounds: %u", &CTL_L_NUM);
			}

			if ((appstr = strstr(line, "skip_sampling")) != NULL)
			{
				sscanf(appstr, "skip_sampling: %u", &i_sta_intervals);
			}

			if ((appstr = strstr(line, "sampling_times")) != NULL)
			{
				sscanf(appstr, "sampling_times: %u", &sample_times);
			}

			if ((appstr = strstr(line, "opt_run")) != NULL)
			{
				sscanf(appstr, "opt_run: %u", &opt_run);
				if(opt_run==1) fairness_f = 0;
			}

			if ((appstr = strstr(line, "latencyVar_ub")) != NULL)
			{
				sscanf(appstr, "latencyVar_ub: %u", &latencyCV_high_b);
			}

			if ((appstr = strstr(line, "fairness_ub")) != NULL)
			{
				sscanf(appstr, "fairness_ub: %u", &fairness_high_b);
			}

			if ((appstr = strstr(line, "end_rqs")) != NULL)
			{
				sscanf(appstr, "end_rqs: %u", &end_rqs);
			}

			if(latencyCV_high_b==0 || fairness_high_b==0) fairness_f = 0;
			else fairness_f = 1;

			if ((appstr = strstr(line, "end_time")) != NULL)
			{
				sscanf(appstr, "end_time: %u", &end_time);
			}

			if ((appstr = strstr(line, "P_target")) != NULL)
			{
				sscanf(appstr, "P_target: %u", &thread_con);
			}

			if ((appstr = strstr(line, "L_target")) != NULL)
			{
				sscanf(appstr, "L_target: %u", &DATA_SET);
			}
	}

	fclose(cstream);
	cstream = NULL;

	return i_ret;
}

//For P/L initial settings;
int open_P_L_set()
{
	int i_ret = 0;
	int t1=0, d1=0, p0=0, p1=0, p2=0;
	float la0=0, la1=0, la2=0;
	//For P/L initial settings;
	char *appstr;
	char line[128];
	memset(line, 0, 128);

	lseek(opt_handle[0], 0L, SEEK_SET);
	
	while(fgets(line, 128, wstream_opt[0])){

		sscanf(line, ",%d,%d,%d,%d,%d,%f,%f,%f", &t1, &d1, &p0, &p1, &p2, &la0, &la1, &la2);

		/////////////////////////////////////////////////////
		//printf("\n;%d;%d;%d;%d;%d;%8.2f;%8.2f;%8.2f, %d\n", t1, d1, p0, p1, p2, la0, la1, la2, expect_users);
		/////////////////////////////////////////////////////
		if (t1>1 && t1 <= expect_users && d1>0 && d1<=128 
	   &&p0>1 && p0 <= expect_users
	   &&p1>1 && p1 <= expect_users
	   &&p2>1 && p2 <= expect_users
	   &&la0 > 0 && la1>0 && la2 >0){
			i_ret = 1;
		}

		////////////////////////////////////////////////////////////////
		//2020.7.16 Output the initial value of P/L;
		/*char str_linex[16];

		t1 = 20;
		d1 = 32;
		p0 = 8;
		p1 = 256;
		p2 = 32;
		la0 = 1000.12;
		la1 = 2000.22;
		la2 = 3000.32;
		
		if(1){
			lseek(opt_handle[0], 0L, SEEK_SET);
			sprintf(str_linex, ",%d,%d,%d,%d,%d,%8.2f,%8.2f,%8.2f\n", t1, d1, p0, p1, p2, la0, la1, la2);
			fwrite(str_linex,1,strlen(str_linex),wstream_opt[0]);
			fflush(wstream_opt[0]);
			printf("\n;%d;%d;%d;%d;%d;%8.2f;%8.2f;%8.2f\n", t1, d1, p0, p1, p2, la0, la1, la2);
		}*/
		////////////////////////////////////////////////////////////////////////
	}

    if(i_ret){
		   thread_con = t1;
			DATA_SET = d1;

			P0 = p0;
			P1 = p1;
			P2 = p2;
			lambda0 = la0;
			lambda1 = la1;
			lambda2 = la2;

			app_p0 = (int)P0;
			app_px = (int)P2;
			app_thpt0 = lambda0;
			app_thpti = lambda1;
			app_thptx = lambda2;

			sprintf(line, ">>>>  Read optimized P: %d  L: %d  [ %4.0f, %8.2f ], [ %4.0f, %8.2f ], [ %4.0f, %8.2f ]\n"
				       , thread_con, DATA_SET, P0, lambda0, P1, lambda1, P2, lambda2);
			mem_log(line, 3);
			/////////////////////////////////////////////////////
		    printf("%s\n", line);
			//printf("\n;%d;%d;%d;%d;%d;%8.2f;%8.2f;%8.2f\n", t1, d1, p0, p1, p2, la0, la1, la2);
		    /////////////////////////////////////////////////////
	}

	return i_ret;
}

//Read user-centric priority configurations; 2019.3.6
int open_pri_sig()
{
	int i_ret = 1;

	estream = fopen("./user_pri.txt","r");

	if(estream==NULL)
	{
		//printf("\nThe user_pri.txt cannot be opened!\n");
		return 0;
	}

	efno = fileno(estream);

	return i_ret;
}

int ana_str_pri(char * cmd_str)
{
	int i_ret = 1;
	char *appstr;

	int port = 0;
	int pri = 1;
	char ip[32];
	memset(ip, 0, 32*sizeof(char));
	//Support priority setting for one or more users; 2019.5.10;
	int num = 1;

	if(cmd_str==NULL)
		return 0;

	if ((appstr = strstr(cmd_str, "port=")) != NULL)
	{
		sscanf(appstr, "port=%u", &port);

		if ((appstr = strstr(cmd_str, "priority=")) != NULL)
		{
			sscanf(appstr, "priority=%u", &pri);
		}

		if ((appstr = strstr(cmd_str, "ip=")) != NULL)
		{
			sscanf(appstr, "ip=%s", ip);
		}

		//Support priority setting for one or more users; 2019.5.10;
		if ((appstr = strstr(cmd_str, "num=")) != NULL)
		{
			sscanf(appstr, "num=%u", &num);
		}

		if(num < 0) num = 0;
		

		int i=0, j=0;

		//print; //////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*if(print_class<=3)
		{
			  char f_str[128];
			  struct timeval e;
			  sc_gettime(&e);
			  sprintf(f_str,"Plan Priority setting (%08d, %08d) >> port: %d  priority: %d  ip:%s\n"
									 , e.tv_sec, e.tv_usec, port, pri, ip);
			  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
			  fflush(wstream_mem[0]);
		}*/
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		for(i=1;i<=fd_id_ptr;i++)
		{
			if(num==0)
			{
				if(!strcmp(flow_id_arr[i].ip_str, ip) || strstr(flow_id_arr[i].ip_str, ip)!=NULL)
				{
					    if(pri<1)
							pri = 1;
						else if(pri>8)
							pri = 8;
						
						pri_weight[i] = pri;
						req_token[i] = pri_weight[i] * DATA_SET;

					  //print; //////////////////////////////////////////////////////////////////////////////////////////////////////////
						if(print_class<=3)
						{
							  char f_str[128];
							  struct timeval e;
							  sc_gettime(&e);
							  //sprintf(f_str,"Priority setting (0) (%08d, %08d) >>  user_cfg[%d] {%s, %d}= %d\n"
							  //						 , e.tv_sec, e.tv_usec, i, ip, flow_id_arr[i].port, req_token[i]);
							   sprintf(f_str,"Priority setting (0) (%08d, %08d) >>  user_cfg[%d] {%s, %d}= %d\n"
													 , e.tv_sec, e.tv_usec, i, ip, flow_id_arr[i].port, pri_weight[i]);
							  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
							  fflush(wstream_mem[0]);
						}
					///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				}
			}
			else
			{
				for(j=0;j<num;j++)
				{
					if(!strcmp(flow_id_arr[i].ip_str, ip) 
				  && flow_id_arr[i].port==port+j)
					{
						if(pri<1)
							pri = 1;
						else if(pri>8)
							pri = 8;

						pri_weight[i] = pri;
						req_token[i] = pri_weight[i] * DATA_SET;

					  //print; //////////////////////////////////////////////////////////////////////////////////////////////////////////
						if(print_class<=3)
						{
							  char f_str[128];
							  struct timeval e;
							  sc_gettime(&e);
							  sprintf(f_str,"Priority setting (%d) (%08d, %08d) >>  user_cfg[%d] {%s, %d}= %d\n"
													 , num, e.tv_sec, e.tv_usec, i, ip, flow_id_arr[i].port, pri_weight[i]);
							  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
							  fflush(wstream_mem[0]);
						}
					///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						//break;
					}
				}
			}
		}
	}

	return i_ret;
}

int read_pri_sig()
{
	int i_ret = 0;

	if(estream==NULL)
		return i_ret;

	char line[128];
	memset(line, 0, 128);
	lseek(efno,0L,SEEK_SET);
	
	while(fgets(line, 128, estream))
	{
		i_ret = ana_str_pri(line);
	}

	return i_ret;
}
///////////////////////////////////////////////////////////////////////////////

//Tell if we need to control the thread; 2018.11.5
int thread_ctl_info(int idx, int tid)
{
	int i_ret = 1;

	if(flow_id_arr[idx].sched_avoid_f > 0)
		return 0;

	int i,j;
	char * app = NULL;
	char cstr[256];
	memset(cstr, 0, 256);

	int fdist = 0;
	int fid = 0;

	for(i=0; i<flow_id_arr[idx].file_id_num; i++)
	{
		fid = flow_id_arr[idx].file_id_ser[i];

		fdist = file_id_list[fid] - 1;

		if(fdist>=0 && fdist<MAX_DIST_FNUM)
		{
			for(j=0; j<res_num; j++)
			{
				if((app=strstr(dist_file_name[fdist], res_str_arr[j]))!=NULL)
				{
					if(static_conf)
						flow_id_arr[idx].sched_avoid_f = 2;
					else
						flow_id_arr[idx].sched_avoid_f = 1; //for dynamically establishing managed group; 2019.1.1;
					sprintf(cstr, dist_file_name[fdist]);
					goto CT;
				}
				else if(i == flow_id_arr[idx].file_id_num-1 && j == res_num - 1)
					sprintf(cstr, dist_file_name[fdist]);
			}
		}
	}

	CT: if(flow_id_arr[idx].sched_avoid_f <=0)
	     {
		      if(NET_ID_F)
			 {
				  if((!strcmp(flow_id_arr[idx].ip_str, "0.0.0.0") ) || (flow_id_arr[idx].port<1000))  //cas;
				 // if(0)
					  flow_id_arr[idx].sched_avoid_f  = 1; 
				  else
					  flow_id_arr[idx].sched_avoid_f  = 2;
			 }
			  else
			      flow_id_arr[idx].sched_avoid_f  = 2; 
		 }

	//print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			  char f_str[512];
			  struct timeval e;
		      sc_gettime(&e);

			  if(NET_ID_F)
				 sprintf(cstr, flow_id_arr[idx].ip_str);

			  sprintf(f_str,"Initialization [S  td: %05d  ptr: %04d  fd: %05d  dn: %04d  nn: %04d  n0: %06d]  (%08d, %08d) >>   dist_file_num = %04d, sched_f = %04d, net_port = %05d, fn = %s\n"
				                     , tid, idx, fid, flow_id_arr[idx].file_id_num, flow_id_arr[idx].net_id_num, flow_id_arr[idx].net_id_ser[0], e.tv_sec, e.tv_usec, fdist+1, flow_id_arr[idx].sched_avoid_f, flow_id_arr[idx].port, cstr);
			  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
			  fflush(wstream_mem[0]);
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	return i_ret;
}

int poll_thread_ctl_info()
{
	int i_ret = 1, i;

	sch_thread_num = 0;

	char f_str[512];
	struct timeval e;
	sc_gettime(&e);

	//print networking connections; 2019.2.26;
	for(i=1;i<net_id_ptr;i++)
	{
		sprintf(f_str,"Initialization [N  cn: %05d]  (%08d, %08d) >>  The %04d connection = [port :%04d,  ip: %s]\n"
			                     , net_id_ptr-1, e.tv_sec, e.tv_usec, i, net_id_arr[i].port, net_id_arr[i].ip_str);
		fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
		fflush(wstream_mem[0]);
	}

	//print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		  char f_strs[512];
		 
		  for(i=1;i<fd_id_ptr;i++)
		{
			  if(fd_id_list[i]==0)
			{
			  sprintf(f_strs,"!!!!!   fd_id_list[%d] = 0\n"
									 , i);
			  fwrite(f_strs,1,strlen(f_strs),wstream_mem[0]);
			  fflush(wstream_mem[0]);
			}
		}
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   //Actual number of threads  fd_id_ptr -1; 2018.12.6
	//for(i=1;i<=fd_id_ptr;i++)
	for(i=1;i<fd_id_ptr;i++)
	{
		i_ret = thread_ctl_info(i, fd_id_list[i]);

		if(flow_id_arr[i].sched_avoid_f == 2)
		{
			//The number of scheduling threads, 2018.12.5;
			sch_thread_num++;
		}
	}

		//print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		sprintf(f_str,"Initialization [S  tn: %05d]  (%08d, %08d) >>  The number of scheduling threads = %04d   Other threads = %04d\n"
			                     , fd_id_ptr-1, e.tv_sec, e.tv_usec, sch_thread_num, fd_id_ptr - sch_thread_num - 1);
		fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
		fflush(wstream_mem[0]);
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	return i_ret;
}


void mem_log(char * str_line, int pnt_c)
{
	if(print_class<=pnt_c)
	{
	     if(str_line!=NULL)
		{
			fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
			fflush(wstream_mem[0]);
		}
	}
}
/*************************************2018.11.5**************************************/

#endif