#ifndef COMMON_H
#define COMMON_H

#include<pthread.h>
//Socket analysis; 2019.2.26;
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include<signal.h>
#include<sys/time.h>
#include <poll.h>
#include <sys/epoll.h> 
#include<math.h>

//RW lock; 2018.12.7;
pthread_rwlock_t rwlock;
//RW lock; 2018.12.7;
pthread_rwlock_t ctlock;
//RW lock; 2018.12.7;
pthread_rwlock_t stlock;
//RW lock; 2018.12.7;
pthread_rwlock_t xtlock;

//read, write, aiow, aior;
#define MAX_OP_NUM 4
//the maximum number of I/O files;
//#define MAX_FD_NUM 256 * 2
#define MAX_FD_NUM 256 * 8
//the maximum number of file ID;
#define MAX_FD_VAL 1024*1024 * 4

//the maximum number of priviliged users; 2020.3.23;
//#define MAX_PU_NUM 64
#define MAX_PU_NUM 128 //2020.4.26;

//fd_inv_num_arr[x][0] will be reserved for other statisdtics;
//fd_inv_num_arr[x][1]~[x]MAX_FD_NUM-1] for the X syscall invokes for the file ID y;
int fd_inv_num_arr[MAX_OP_NUM][MAX_FD_NUM];
//throttling actions statistics;
int fd_thr_num_arr[MAX_OP_NUM][MAX_FD_NUM];
//map a specific file ID to the 2nd dimensional index of fd_inv_num_arr
short fd_id_map[MAX_FD_VAL];
//recording the file ID list;
int fd_id_list[MAX_FD_NUM];
//recording the file ID op type;
//int fd_type_list[MAX_FD_NUM];
//the maximum value is MAX_FD_NUM;
int fd_id_ptr = 0;
//the FD needed to be throttled;
int fd_throttle = 0;

//buffer the requests with the same address; 10/8/2018;
struct req_buf
{
	//s: start time;
	unsigned int start_time_sec;
	//us: start time;
	unsigned int start_time_us;
	//us: response time;
	int resp_time;
	//IO request address;
	unsigned long req_addr;
	//IO request address;
	unsigned long req_off;
   //Thread ID;
   unsigned int thread_id;
};

//For all the I/O flows in control;
struct  req_buf req_buf_arr[MAX_FD_NUM];

struct tv_valid {
	struct timeval last_tv;
	unsigned long long last_cycles;
	int last_tv_valid;
};

#define MAX_TH_FILE_NUM 32

//The maximum number of socket descriptors for a thread; 2019.1.24;
#define MAX_TH_NETF_NUM 32

//For each I/O flow;
struct flow_id_u
{
	int ini_flag;
	//ID;
	int id;
	//Last response;
	struct timeval last_rp; //2019.12.9;
	//Last arrival;
	struct timeval last_tv; 
	//Interarrival times (us);
	unsigned long long it_val;
	//the last interarrival times (us); //8/21/2018;
	unsigned long long last_it_val;
	//the ratio of the it val to the last it val; //8/21/2018;
	double ra;
	//the state of the thread 1: stop 0:run; //8/21/2018;
	int state;
	//Long-term statistical interval;;//8/26/2018;
	unsigned long long  long_cs_num;
	//the congestion sleep times; //8/21/2018;
	int cs_num;
	//all the congestion sleep times; //8/23/2018;
	int cs_num_all;
	//Throughput slo for a specific flow;
	int throughput_slo;
    //Throughput for a specific flow;//8/26/2018
	int throughput_val;
	//Tail slo for a specific flow;//8/24/2018;
	int tail_slo;
	//Head slo for a specific flow;//8/24/2018;
	int head_slo;
	//The time for I/O delay;
	int sleep_time;//us;
	//The time for continuous sleeping; //12/27/2018;
	int con_sleep_time;
	//The time for congestion sleep;
	int cs_sleep_time;//us;
	//The IOs for continuous running; //12/27/2018;
	int con_run_ios;
	//The IOs for continuous running for the last time; //12/27/2018;
	int last_con_run_ios;
	//The times of reclaiming quota; //12/31/2018;
	int reclaim_times;
	//The number for straggler I/Os ;//8/24/2018;
	int tail_num;
	//The number requests held by ALS ;//12/25/2018;
	int head_num;
	//time statistics; //8/26/2018;
	int sta_times;
	//Long-term statistical interval;;//8/26/2018;
	unsigned long long long_sta_times;
	//frequency statistics; //8/26/2018;
	int count_freq;
	//The proportional part of sleep time;;//9/7/2018;
	long long proportional_sleep_time;
	//The integral part of sleep time;;//9/7/2018;
	long long integral_sleep_time;
	//The proportional ratio;;//9/7/2018;
	unsigned int proportional_ratio;
	//The integral ratio;;//9/7/2018;
	unsigned int integral_ratio;
	//The thread-level quota for I/O dispatching;//10/22/2018;
    int req_quota;
	//1: Without scheduling, 2: need to schedule; //10/28/2018;
	int sched_avoid_f;
	//Last scheduling; //10/28/2018;
	struct timeval sched_tv; 
	//The total scheduled times; //12/15/2018;
	int sched_times;
	//The ave congestion time; //12/15/2018;
	int ave_cs_sleep;
	//The ave it time; //12/15/2018;
	int ave_it_val;
	//file ID series;  /11/5/2018;
	int file_id_ser[MAX_TH_FILE_NUM];
	//The number of file ID series;  /11/5/2018;
	int file_id_num;
	//socket ID series;  /1/24/2019;
	int net_id_ser[MAX_TH_NETF_NUM];
	//The number of socket ID series;  /1/24/2019;
	int net_id_num;
	//IP string; /2/26/2019;
	char ip_str[48];
	//port;/2/26/2019;
	int port;
	//the times for standard I/O delay unit; 1/22/2020;
	int times_delay;
	//the user is priviliged with tail latency SLO; 3/29/2020;
	short is_priviliged;
	//the ratio of waiting time; 4/18/2020;
	short wt_ratio;
};

//For each net link; //1/24/2019;
struct net_id_u
{
	int ini_flag;
	//ID;
	int id;
	//Last arrival;
	struct timeval last_tv; 
	//Interarrival times (us);
	unsigned long long it_val;
	//the last interarrival times (us);
	unsigned long long last_it_val;
	//the state of the thread 1: stop 0:run; 
	int state;
	//Long-term statistical interval;
	unsigned long long  long_cs_num;
	//the congestion sleep times;
	int cs_num;
	//all the congestion sleep times;
	int cs_num_all;
	//Throughput slo for a specific net link;
	int throughput_slo;
    //Throughput for a specific  net link;
	int throughput_val;
	//Tail slo for a specific  net link;
	int tail_slo;
	//The percentile in which the tail latency defined for a specific net link;
	int per_slo;
	//IP string; /2/26/2019;
	char ip_str[32];
	//port;/2/26/2019;
	int port;
};


//The limit on the times of reclaiming quota; //12/31/2018;
#define MAX_RECLAIM_TIMES 10

//gang ID groups;  /11/5/2018;
#define MAX_GANG_NUM 128
#define MAX_GANG_MEM 16

int gang_num = 0;
int gang_id_arr[MAX_GANG_NUM][MAX_GANG_MEM];
int gang_nr_arr[MAX_GANG_NUM];
///////////////////// gang ID groups;  /11/5/2018;//////////////////////

//2019.1.1 for I/O thread waiting for I/O dispatching;
char th_wait_list[MAX_FD_NUM];

//2019.1.1 for I/O threads have ever issued I/Os;
char th_erun_list[MAX_FD_NUM];

//AbleQ thread ID, don't need to intercept;  /11/5/2018;
int noctl_tid = 0;

//the number of scheduled priviliged users; 1/22/2020; 
int sched_pu_n = 0; 
//the number of priviliged users; 1/22/2020;
int pu_n = 0;
//state of IO stack for tail latency enforcement;; 1/22/2020;
int sys_state = 0;
int last_sys_state = 0;

//only for printf; 1/22/2020;
int pp_tmp1 = 0;

//Distinct file names;  /11/5/2018;
//#define MAX_DIST_FNUM 1024
//Extended 12/11/2018;
#define MAX_DIST_FNUM 1024 * 8
#define MAX_FNAME_LEN 256
#define epslan   10E-12             //small value (used for convergence) 
#define EV       2.718281828459     //nature number value

//For print levels;
int print_class = 3;

int dist_file_num = 0;
char dist_file_name[MAX_DIST_FNUM][MAX_FNAME_LEN];

short file_id_list[MAX_FD_VAL];
///////////////////// Distinct file names;  /11/5/2018;//////////////////////

///////////////////// Distinct net statistics;  /1/24/2019;//////////////////////
//the distinct number of net IDs; 2019.1.24;
int dist_net_num = 0;

//The net ID list; 2019.1.24;
short net_id_list[MAX_FD_VAL];

//net_inv_num_arr[x][0] will be reserved for other statisdtics;
//net_inv_num_arr[x][1]~[x]MAX_NETF_NUM-1] for the X syscall invokes for the net ID y;
int net_inv_num_arr[MAX_OP_NUM][MAX_FD_NUM];
//throttling actions statistics;
int net_thr_num_arr[MAX_OP_NUM][MAX_FD_NUM];
//map a specific file ID to the 2nd dimensional index of fd_inv_num_arr
short net_id_map[MAX_FD_VAL];
//recording the file ID list;
//int net_id_list[MAX_FD_NUM];
//the maximum value is MAX_FD_NUM;
int net_id_ptr = 0;
///////////////////// Distinct net statistics;  /1/24/2019;//////////////////////

///////////////////// The critical resources under control;  /11/5/2018;//////////////////////
#define MAX_RES_NUM 8
int res_num = 0;
char res_str_arr[MAX_RES_NUM][MAX_FNAME_LEN];
///////////////////// The critical resources under control;  /11/5/2018;//////////////////////

//For application-level statistics; //10/21/2018;
unsigned long long app_cs_num = 0;
unsigned long long app_bw_num = 0;
unsigned long long app_sta_times = 0;
//Last arrival;
struct timeval app_last_tv; 
int app_ini_flag = 0;

struct timeval sch_last_tv; 
int sch_ini_flag = 1;

//SSD;
#define MAX_AHEAD_OP 100000

//HDD;
//#define MAX_AHEAD_OP 10000

//Maxinum time length for continuous sleeping (us); //12/27/2018;
#define MAX_SLEEP_T 100 * 1000


///////////////////// The round-robin scheduling algorithm for multi-threaded I/O  (2018.10.22)//////////////////////
//The rest time after that testing if it can run (us);
#define REST_TIME 200
//#define REST_TIME 10  //for test; 2021.1.30

#define MAX_ROUND_NUM 64

#define MAX_THCON_NUM MAX_FD_NUM

//Recording all the system calls; 2019.3.19;
int sys_call[512];
int sys_num[512];
int sys_call_idx = 0;
int sys_total_num = 0;
//the statistics for stealing running time due to waiting too long; (2020.1.7)
int sta_steal_run = 0;
//=================sys_xpslo_mon.c=================//

//Tell if the system call is ppoll-related or epoll I/O receiving; //3/26/2019;
#define PPOLL_D 101
#define EPOLL_D 102
#define EPOLL_PNT 0
#define PPOLL_PNT 1

int epoll_anum = 0;
int epoll_mnum = 0;

int ppoll_anum = 0;
int ppoll_mnum = 0;


//Special logged users; 2019.4.3
int logged_fuser_id = 6;


///////////////////////////////////////////////////////////////////////////////////////////////////
//The version of AppLeS; (1.06 support ppoll epoll)
//(1.07 support Fairness guarantee); 2019.4.18;
//(1.09 support accurate budget estimation and SLO enforcement); 2020.8.12;
float apples_version = 1.10;

//Disable AppLes or not;
int disable_apples = 0;

//Disable log function; 2019.10.5;
int disable_logs = 0;

//The ratio of the current outstanding I/Os to thread_con; 2019.3.12;
int ratio_out = 100;
int out_num = 0;
int dis_app_delay_f = 0; 

//Enable the functionality of recording all the requests; 2019.7.22;
int record_reqs = 1;
//int record_reqs = 0;

//Clear history data; 2019.8.28;
int his_sta_clear = 0;

//Average IO speed; 2019.8.28;
float ave_IO_speed = 0;

//Token bucket algorithm; 2019.3.11; 
int tb_apples = 0;
int tb_credits = 200;
int tb_span = 250000;//us;

//Static configure managed thread group or dynamically add them; 2019.1.2;
int static_conf = 1;

//Expected the number of users; 2019.10.3;
//int expect_users = 200;
int expect_users = 256;

//Under soft-throttling state; 2019.1.2;
int soft_throttling = 0;

//1: binary-searching; 0: sequential-searching; 2019.1.3;
int opt_mode_set  = 0;

//Need optimization or not; 1: run optimization; 0: don't need run;
int opt_run = 1;

//The type of the target server application; 1: MySQL; 2:MongoDB; 2021.2.19;
int app_type = 0;

//The version of the target server application; 1: MySQL; 2:MongoDB; 2021.2.19;
int app_version = 0;
int app_fver = 0;
int app_sver = 0;
int app_tver = 0;

//Recording all the threads;
int recording_all = 1;

//Fairness higher bound (e.g., 500/10000 = 5%); 2019.4.18;
//int fairness_high_b = 2000;
//#define fairness_high_b  500
int fairness_high_b = 0;

//Fairness lower bound; 2019.4.18;
int fairness_low_b = 0;

//Efficiency control unit for fairness; 2019.4.18;
int fairness_step = 2;

//Efficiency control unit for fairness; 2019.4.18;
int fairness_unit = 2;

//Fairness value;2019.4.18;
int fairness_v = 0;

//Fairness value of variance;2019.7.22;
int fairness_d = 0;

//Fairness value;2019.4.18;
int fairness_f = 0;

//the upper limit of latency CV (e.g., 2000/1000 = 2.0)
int latencyCV_high_b = 0;

//Latency CV lower bound;
int latencyCV_low_b = 0;

//Latency CV value;
int latencyCV_v = 0;

//Efficiency control unit for fairness; 2019.4.18;
int la_DATA_SET = 0;
int last_fairness_v = 0;
int last_fairness_d = 0;
int last_latencyCV_v = 0;

//Total thoughput;
int tot_throughput = 0;
//Used by control algotithm;
int total_throughput = 0;
int last_total_throughput = 0;

///////////////////////////////////////////////////////////////////////////////////////////////////
//Running status 1: high load (HL); 0: low load (LL); //2020.8.12;
int sys_running_status = -1;
int pre_sys_running_status = -1;
//LS user's total throughput budget; 2020.8.13;
double LS_xput_bg = 0.0;
int sys_aggregate_status = 0;
//Average thourghput;
double sys_ave_xput = 0;
double his_sys_ave_xput = 0;
double BE_xput = 0;
double his_BE_xput = 0;
int be_num = 1;
//Throughput obtained in high load (HL); //2020.8.12;
double sys_LL_xput = 0;
double his_sys_LL_xput = 0;
long long period_LL = 0;
long long tot_period_LL = 0;
double tot_ratio_LL = 0.0;
//Throughput obtained in low load (LL); //2020.8.12;
double sys_HL_xput = 0;
double his_sys_HL_xput = 0;
long long period_HL = 0;
long long tot_period_HL = 0;
//IO requests obtained in high load (HL); //2020.8.12;
double sys_LL_ios = 0.0;
//IO requests obtained in low load (LL); //2020.8.12;
double sys_HL_ios = 0.0;
//The start time for high load (HL); //2020.8.12;
struct timeval sys_LL_start;
//The start time for high load (HL); //2020.8.12;
struct timeval sys_HL_start;
//The history ratio of moving average; //2020.8.14;
double his_moving_ratio = 0.75;
double H1_his_moving_ratio = 0.95;

//Consideration for the estimation headroom; //2020.8.13;
double prediction_E = 0.95;
//Quota computation flag; //2020.8.14;
int Quota_f  = -1;

//Minimum BE user throughput; 2020.8.14;
double min_BE_xput = 20;
//Maximum quota; 2020.8.14;
double max_quota = 64;
//Smooth tail latency SLO guarantee; 2020.8.20;
int guarantee_smooth = 1;

//Resource quota (res);
//Time slice length in terms of the number of requests allowed to issue (Efficiency);
//int DATA_SET = 64;
int DATA_SET = 1;
int DATA_SET_min = 1;
int DATA_SET_max = 64;
//int DATA_SET = 16;
//int DATA_SET = 4;
//int DATA_SET = 2;
//int DATA_SET = 256;
//int DATA_SET = 96;

int thread_con = 16;
//int thread_con = 32;
//int thread_con = 22;
//int thread_con = 60; //200 users;
//int thread_con = 50; //150 users;
//int thread_con = 50; //100 users;
//int thread_con = 249;

//The number of recordings;
int rec_rounds = 0;
//The end condition in terms of the number of recordings;
int end_time = 300;
//The end codition in terms of the number of samplings;
int end_rqs = 9500000;

//Newton calculation switch;
#define NEWTON_F 1

//The user parallsliem limit for the first point;
double P0= 2;
//The user parallsliem limit for the 2nd point;
double P1= 128;
//The user parallsliem limit for the 3rd point;
double P2= 32;
//The throughput for the first point;
double lambda0= 0.0;
//The throughput for the 2nd point;
double lambda1= 0.0;
//The throughput for the 3rd point;
double lambda2= 0.0;

//normalized throuhput;
double app_thpt0 = 0;
//minimal user parallelism;
int app_p0 = 0;
//The specific throuhput;
double app_thptx = 0;
//The specific user parallelism;
int app_px = 0;
//The throuhput for all users;
double app_thpti = 0;

//Optimization flow control flag;
int c_fir = 0;


//2020.4.17; Neglect the conditon of scheduling: not choosing the user scheduled in the last round;
int skip_last_round_con = 0;

//2020.4.17; Static priority setting;
int static_pri_set = 0;

//2020.4.18; control target for static priority-based sharing;
double pri_target = 0.0;

//I/O thread concurrency (the default number is set at 2);
//int thread_con = 2;
//int thread_con = 32;
//int thread_con = 32;
//int thread_con = 24;  //computing3 cfq;
//int thread_con = 16;  //computing3 deadline;
//int thread_con = 24;//computing3 mq-deadline;
//int thread_con = 14;//computing3 Kyber;
//int thread_con = 16;//computing3 Kyber;

//Maximum AppleS-induced I/O delay;
//int max_apples_delay = 10;
//int max_apples_delay = 1000;
int max_apples_delay = 100000;

//2019.4.1 max_apples_delay reference;
int max_apples_delay_ref = 100000;

//This is enabled when  soft-throttling = 1  (the default number is set at 5);
int throttling_level = 5;

//the time delay before settings are effective;
//int eff_delay = 60;
int eff_delay = 60;
//int eff_delay = 600;
int eff_idx = 0;
int eff_flag = 0;

#define STA_CYCLE 6

//Configure the functionality of recording all the requests to the file; 2020.5.1;
int file_reqs = 1;
///////////////////////////////////////////////////////////////////////////////////////////////////

//1: All the parameters have been optimized! //2019.1.3;
//int opt_para_finished = 0;

//The number of scheduling threads, 2018.12.5;
int sch_thread_num = 0;

////////////////////////////////////////////////////////////////////////////////////
//FLEXIBLE CONTROL; 2019.3.4; 
//Last number of completed requests per client; 
int last_com_req_per = 0;
int last_com_req_per2 = 0;
//The ratio of the current number of completed requests per client to its last number; 
//(1000 = 1) if < 500; max_apples_delay = 10;
//(1000 = 1) if < 250; max_apples_delay = 5;
//if(ratio_com_req_per< 500) max_apples_delay = 2
//if(ratio_com_req_per>1500)  max_apples_delay = (max_apples_delay + 1) * 1000
int ratio_com_req_per = 0;
int ratio_com_req_per2 = 0;
int ratio_com_req_per3 = 0;
int flex_state = 0;
int last_flex_state = 0;
int flex_times = 0;
////////////////////////////////////////////////////////////////////////////////////

//The standard time used in ALS for threads; 2019.1.2;
int als_time = 0;

int round_idx = 0;

//The absolute index for scheduling rounds; 2019.10.3;
int abs_round_idx = 0; 

//The 1st valid user; 2019.10.3;
int first_v_user = 0;

int sched_flag = 0;

int sctl_flag = 0;

int sched_run_once = 1;

//The thread-level quota for I/O dispatching;
int req_quota;

int req_token[MAX_THCON_NUM];

//Weight for users;
int pri_weight[MAX_THCON_NUM];

 char db_str[64];

//The scheduling history, storing indices of threads scheduled for the last round;
int sched_thread_his_arr[MAX_ROUND_NUM][MAX_THCON_NUM];

int sched_his_idx_len[MAX_ROUND_NUM];

int last_fd_id_ptr[MAX_THCON_NUM];

int fd_check_num = 0;

int fd_stable_num = 0;

//check the stability of management group ; 2019.1.1;
int last_man_id_ptr[MAX_THCON_NUM];

int man_check_num = 0;

int man_stable_num = 0;
////////////////////////////////////////////////////////////////////////

//The start time for throughput statistics (ms); 2018.11.12;
unsigned long long sta_start_time = 0;
//The end time for throughput statistics (ms); 2018.11.12;
unsigned long long sta_end_time = 0;

unsigned long sta_start_ms = 0;

unsigned long sta_end_ms = 0;

//starting clock for the whole system; 2020.2.24; 
struct timeval estart;

//starting clock for 10-sec interval throughput; 2020.3.22;
struct timeval istart;
//How long does AppleS need to take to skip interim throughput fluctuation;
int i_sta_intervals = 6;
//int i_sta_intervals = 1;
//How long does AppleS need to take to capture valid throughput measure;
int sample_times = 6;
//int sample_times = 1;

int i_sta_index = 0;
int i_first_sta = 1;

//only for print; 2020.2.24;
unsigned long pnt_num_t = 0;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//The threshold for qualified I/O intervals;//8/26/2018;
int th_q_int = 10;

//The central throughput target;//8/26/2018;
int central_throughput_slo = 10000;

//The base time for I/O delay in terms of central_throughput_slo (us); //9//16/2018;
int base_service_time = 200;

//The number of active threads;
int active_thread_num = 0;

int concurrent_ios = 0;

int concurrent_ios1 = 0;

//Alarm for I/O congestion;//8/21/2018;
int alarm_congestion = 0;

//The threshold of the ratio of the current it value to the last it value,
//which is used for  I/O congestion alarming;//8/21/2018;
float IT_LIMIT = 10.0;

//Sleep IT_SLEEP us once alarming for each thread;//8/21/2018;
#define IT_SLEEP 1000

//How often executing a scheduling;
#define CTL_Q_NUM 5000

//How often executing a scheduling;;//8/26/2018;
//#define CTL_T_NUM 250000
int CTL_T_NUM =100000;
//#define CTL_T_NUM 500000

//Mid-term statistical interval;;//8/26/2018;
int CTL_M_NUM = 10;

//Long-term statistical interval;;//8/26/2018;
int CTL_L_NUM = 100;

//Long-term integral part clear;;//9/7/2018;
#define CTL_I_NUM 100

//The minimum value of the queue threshhold; //9/21/2018;
#define MIN_THRESHOLD_Q 4

//The experimental device; //9/27/2018;
//#define DEV	"sde"
//#define DEV	"sdh" //MySQL computing3
//#define DEV	"sdf"
#define DEV	"sdg"  //MongoDB computing3
//#define DEV	"xvdbp1"

//The working directory; //9/27/2018;
//#define DIR	"sys_xpslo_mon_dis_host"
char WDIR[128];

//Use thread id or file id to categorize I/O requests; //10/2/2018;
#define THREAD_ID_F 1

//Use socket id to categorize I/O requests; //1/29/2019;
#define NET_ID_F 1

//The lock for threads; //9/28/2018;
static int lock_thread_x = 0;

int ctl_central_val = 1;

static struct tv_valid static_tv_valid;

//For all the I/O flows in control;
struct  flow_id_u flow_id_arr[MAX_FD_NUM];

//For all the network links in control; //1/24/2019;
struct  net_id_u net_id_arr[MAX_FD_NUM];

//Recording buffer 2018.10.11
#define REC_BUF_SIZE 32*1024*1024
//#define REC_BUF_SIZE 1024*1024

//Slow HDD;
//#define REC_BUF_NUM 1000

//Remote storage;
//#define REC_BUF_NUM 4000 * 1
//#define REC_BUF_NUM 2500 * 40

//#define REC_BUF_NUM 10000 * 30  //20 users;
//#define REC_BUF_NUM 10000 * 45  // 30 users;
//#define REC_BUF_NUM 10000 * 60  // 40 users;
#define REC_BUF_NUM 10000 * 50  // 50 users; 2020.8.31;
//#define REC_BUF_NUM 10000 * 75  // 50 users;
//#define REC_BUF_NUM 10000 * 90  // 60 users;
//#define REC_BUF_NUM 10000 * 105  // 70 users;
//#define REC_BUF_NUM 10000 * 120  // 80 users;
//#define REC_BUF_NUM 10000 * 135  // 90 users;
//#define REC_BUF_NUM 10000 * 500  // 100 users;  //for long-term experiments; 2020.8.31;

//#define REC_BUF_NUM 10000 * 30 //60 users; read;
//#define REC_BUF_NUM 10000 * 35 //90 users; read;
//#define REC_BUF_NUM 10000 * 38 //100 users; read;

//#define REC_BUF_NUM 10000 * 10  //20 users;

//#define REC_BUF_NUM 5000 * 16
//40000 * 128 * 1.1 = 5632000 (5120000)
//#define REC_BUF_NUM 40000

//Local storage;
//#define REC_BUF_NUM 15000

//The scheduling mode for apples; (2020.1.7)
//EFFICIENT: refers to user-level scheduler allows scheduling interval overlapping, thus a higher I/O efficiency;
#define EFFICIENT 1
//FAIRNESS: refers to user-level scheduler doesn't allow scheduling interval overlapping, thus a higher I/O fairness;
#define FAIRNESS  0
//the switch for the scheduling mode for apples;
int sched_mode = EFFICIENT;

//for opt_algo, tail latency SLO mode 1: enable; 0: disable; (2020.8.31)
int tail_lat_opt = 0;
//tail latency guarantee mode 1: enable; 0: disable; (2020.1.7)
int tail_lat_guarantee = 0;
//measure variance/mean for each user; 2020.3.22;
int tail_measure = 0;
//the proportion of IO provisioning for a previliged user to a unpriviliged user; 2020.3.23;
//int max_provision_ratio = 4;
//int max_provision_ratio = 16;
//int max_provision_ratio = 2;
//int max_provision_ratio = 16;  //for 100 users;
//int max_provision_ratio = 32; //for 150 users;
//int max_provision_ratio = 48; //for 200 users;
int max_provision_ratio = 64; //for 200 users;
//int max_provision_ratio = 72; //for 250 users;

//int max_iodelay_ratio = 64;
//(max_iodelay_ratio) Round-robin order waiting relative to the total number of end users; 2020.4.7;
int max_iodelay_ratio = 100; //for 200 users;
//int max_iodelay_ratio = 100; //for 100, 150 users;
//int max_iodelay_ratio = 10; //for 1000 users;

//the smallest mean slo reuqired for the priviliged users' tail latency SLOs; 2020.6.5;
double least_mean_slo = 0.0;
double least_mean_tot = 0.0;
double least_mean_num = 0.0;

//the mode of tail latency guarantee; 2020.2.24;
//0: global window & local window sensitive; 
#define GLB_LOC_SEN 0
//1: global window sensitive; 
#define GLB_NON_SEN 1
//2: local window sensitive; 
#define NON_LOC_SEN 2
int  tail_guarantee_mode = GLB_NON_SEN;

//the mode of triggering tail latency guaranteeing; (2020.2.25)
//Only from tail latency measure;
#define MEASURE_SIG 0
//Only from tail latency prediction;
#define PREDICTION_SIG 1
//From the combination of tail latency prediction & measure;
#define PRED_MEA_SIG 2
//From 100% percentile guarantee;
#define WORST_SIG 3
//the mode of triggering tail latency guaranteeing; (2020.2.25)
//int tail_trigger_mode = PREDICTION_SIG;
//int tail_trigger_mode = WORST_SIG;
int tail_trigger_mode = MEASURE_SIG;

//1: Enable user-level parallelism optimization 2020.8.25;
int up_opt_f = 1;

int data_rec_f = 0;

struct timeval pre_point;

char ** rec_buf_p = NULL;

int rec_buf_n[MAX_FD_NUM];

int rec_buf_act_size[MAX_FD_NUM];

int rec_buf_f[MAX_FD_NUM];

//int rec_buf_f = 1;

int rec_buf_lock = 2;

//2018.12.13 to decide when to run als control;
FILE * dstream = NULL;
int dfno = 0;
int als_ctl = 0;
/////////////////////////////////////////////////////////

//2019.3.6 implement user-centric priority control;
FILE * estream = NULL;
int efno = 0;
/////////////////////////////////////////////////////////

//2019.8.29 Clear history data;
FILE * hstream = NULL;
int hfno = 0;
/////////////////////////////////////////////////////////

//core number;
int core_num = 4;

//the number of concurrent thread within 250 ms;//9/8/2018;
int con_threads_run[MAX_FD_NUM];

//Reading the device queue; 9/9/2018
FILE *fp_diskstats = NULL;

int disk_handle = 0;

FILE * pstream = NULL;

int ios_handle = 0;

FILE * ustream = NULL;

int util_handle = 0;

//The optimized queue size for the virtual disk;//9/20/2018;
int threshold_q = 4;

int threshold_add = 0;

int threshold_f = 1;

int s_v = 0;

//The service time obtained under the baseline environment;//9/20/2018;
float base_ss = 0;

int ss_setup = 0;

//Last service time in ms;//9/20/2018;
float last_ss = 0;

float ss_ratio = 0;

//Total I/O throughput 2018.10.21;
unsigned long long total_th = 0;

static void *__sc_gettime(struct timeval *tp)
{
	struct tv_valid *tv;
	tv = &static_tv_valid;
	gettimeofday(tp, NULL);
	return tv;
}

void sc_gettime(struct timeval *tp)
{
	struct tv_valid *tv;
	tv = __sc_gettime(tp);
	/*
	 * If Linux is using the tsc clock on non-synced processors,
	 * sometimes time can appear to drift backwards. Fix that up.
	 */
	if (tv) {
		if (tv->last_tv_valid) {
			if (tp->tv_sec < tv->last_tv.tv_sec)
				tp->tv_sec = tv->last_tv.tv_sec;
			else if (tv->last_tv.tv_sec == tp->tv_sec &&
				 tp->tv_usec < tv->last_tv.tv_usec)
				tp->tv_usec = tv->last_tv.tv_usec;
		}
		tv->last_tv_valid = 1;
		memcpy(&tv->last_tv, tp, sizeof(*tp));
	}
}

uint64_t utime_since(struct timeval *s, struct timeval *e)
{
	long sec, usec;
	uint64_t ret;

	sec = e->tv_sec - s->tv_sec;
	usec = e->tv_usec - s->tv_usec;
	if (sec > 0 && usec < 0) {
		sec--;
		usec += 1000000;
	}

	if (sec < 0 || (sec == 0 && usec < 0))
		return 0;
	
	sec *= 1000000UL;
	ret = sec + usec;

	return ret;
}

uint64_t mtime_since(struct timeval *s, struct timeval *e)
{
	long sec, usec, ret;

	sec = e->tv_sec - s->tv_sec;
	usec = e->tv_usec - s->tv_usec;
	if (sec > 0 && usec < 0) {
		sec--;
		usec += 1000000;
	}

	if (sec < 0 || (sec == 0 && usec < 0))
		return 0;

	sec *= 1000UL;
	usec /= 1000UL;
	ret = sec + usec;

	return ret;
}

uint64_t utime_since_now(struct timeval *s)
{
	struct timeval t;
	sc_gettime(&t);
	return utime_since(s, &t);
}

uint64_t mtime_since_now(struct timeval *s)
{
	struct timeval t;
	sc_gettime(&t);
	return mtime_since(s, &t);
}

uint64_t time_since_now(struct timeval *s)
{
	return mtime_since_now(s) / 1000;
}

void clear_con_threads()
{
	memset(con_threads_run, 0, MAX_FD_NUM * sizeof(int));
}

int set_fd_con_threads(int fd_id)
{
	if(fd_id >= MAX_FD_VAL || fd_id<0)
		return 2;
	int idx = fd_id_map[fd_id];
	if(idx < MAX_FD_NUM && idx>0)
	{
		if(flow_id_arr[fd_id_map[fd_id]].count_freq>5)
			con_threads_run[idx] = 1;
	}
	return 1;
}

int get_con_threads_num()
{
	int con_threads = 0;
	int i=0;
	for(i=1;i<MAX_FD_NUM;i++)
	{
		if(con_threads_run[i]>0)
			con_threads++;
	}
	return con_threads;
}

//Quick sorting;  
void quick_sort(int s[], int t[], int l, int r)  
{  
    if (l < r)  
    {  
        int i = l, j = r, x = s[l], y = t[l];  
        while (i < j)  
        {  
            while(i < j && s[j] <= x)  
                j--;    
            if(i < j)   
			{
                s[i++] = s[j];  
				t[i-1] = t[j]; 
			}
              
            while(i < j && s[i] > x)   
                i++;    
            if(i < j) 
			{
                s[j--] = s[i];
				t[j+1] = t[i];
			}
        }  
        s[i] = x;
		t[i] = y;
        quick_sort(s, t, l, i - 1); 
        quick_sort(s, t, i + 1, r);  
    }  
}  

void ms_ret(int sig)
{
  struct timeval  t;
  t.tv_usec = 0;
  t.tv_sec = 0;
  select(1, 0, 0, 0, &t);
  return;
}

//FENG-090210 HEAD;
void sys_ms_sleep(int ms_num)
{
  struct timeval  t;
  int  status;
  sigset(SIGALRM, ms_ret);
  t.tv_usec = (ms_num % 1000) * 1000;
  t.tv_sec = ms_num / 1000;
  alarm(1);
  status = select(1, 0, 0, 0, &t);
  alarm(0);
  sigrelse(SIGALRM);
  return;
}


//For socket analysis;

/**
 * function unwrap in_addr or in6_addr structure from
 * sockaddr structure depending on address family
 * AF_INET or AF_INET6
 */
void *get_in_addr(const struct sockaddr *sa) {

    if( sa->sa_family == AF_INET) // IPv4 address
        return &(((struct sockaddr_in*)sa)->sin_addr);
    // else IPv6 address
    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

/**
 * function unwrap in_port from sockaddr structure
 * depending on address family AF_INET or AF_INET6
 */
in_port_t get_in_port(const struct sockaddr *sa)
{
    if( sa->sa_family == AF_INET ) // IPv4 address
        return (((struct sockaddr_in*)sa)->sin_port);
    // else IPv6 address
    return (((struct sockaddr_in6*)sa)->sin6_port);
}

/**
 * function unwrap ip address and port from sockaddr structure
 */
int get_address_and_port_from_sockaddr(const struct sockaddr *sockaddr, char **ip_address, int *port) {

    //*ip_address = (char *) malloc(INET6_ADDRSTRLEN * sizeof(char));

    // converting network address to presentation address
    if(inet_ntop(sockaddr->sa_family, get_in_addr(sockaddr), *ip_address, INET6_ADDRSTRLEN * sizeof(char)) == NULL) {
        //fprintf(stderr, "inet_ntop: %s\n", strerror(errno));
        return 0;
    }

    // converting network port to host port
    *port = ntohs(get_in_port(sockaddr));

    return 1;
}

/**
 * function retrieves current ip address and port
 * socket is bound to for given socket file descriptor
 */
int get_current_address_and_port(int sockfd, char **ip_address, int *port) {

    struct sockaddr_storage address = {0};
    socklen_t sockaddrlen = sizeof(address);

    if(getsockname(sockfd, (struct sockaddr*)(&address), &sockaddrlen) < 0) {
        //fprintf(stderr, "getsockname: %s\n", strerror(errno));
        return 0;
    }

    return get_address_and_port_from_sockaddr((struct sockaddr*)(&address), ip_address, port);
}

/**
 * function retrieves peer ip address and port
 * socket is connected to for given socket file descriptor
 */
int get_peer_address_and_port(int sockfd, char **ip_address, int *port) {
    struct sockaddr_storage address = {0};
    socklen_t sockaddrlen = sizeof(address);

    if(getpeername(sockfd, (struct sockaddr*)(&address), &sockaddrlen) < 0) {
        //fprintf(stderr, "getpeername: %s\n", strerror(errno));
        return 0;
    }

    return get_address_and_port_from_sockaddr((struct sockaddr*)(&address), ip_address, port);
}


//Socket analysis; 2019.2.26;
int socket_ana_func(int type, long para, char * ip_str, int * port)
{
	int i_ref = 0;
	if(para!=0 && ip_str!=NULL && port!=NULL)
	{
			struct sockaddr_in* psin = (struct sockaddr_in*)para;
			sprintf(ip_str, inet_ntoa(psin->sin_addr));
			*port = ntohs(psin->sin_port);
			i_ref = 1;
	}
	else
	{
		sprintf(flow_id_arr[1].ip_str, "No net info");
		flow_id_arr[1].port = type;
	}
	return i_ref;
}

void socket_ana_foo(int newfd, char * ip_str, int * port) {
    int i_ref = 0;
	if(newfd>0 && ip_str!=NULL && port!=NULL)
	{
		get_peer_address_and_port(newfd, &ip_str, port); 
		/*struct sockaddr_in addr;
		//2019.5.23;
		socklen_t addr_size = sizeof(struct sockaddr_in);
		int res = getpeername(newfd, (struct sockaddr *)&addr, &addr_size);
		if(!res)
		{
			if(addr.sin_family==AF_INET)
			{
				sprintf(ip_str, inet_ntoa(addr.sin_addr));
				*port = ntohs(addr.sin_port);
			}
			else if(addr.sin_family==AF_INET6)
			{
				//struct sockaddr_in6 *s = (struct sockaddr_in6 *)&addr;
				//*port = ntohs(s->sin6_port);
				//inet_ntop(AF_INET6, &s->sin6_addr, ip_str, INET6_ADDRSTRLEN * sizeof(char));

				struct sockaddr_in6* addr6=(struct sockaddr_in6*)&addr;
				//if (IN6_IS_ADDR_V4MAPPED(&addr6->sin6_addr)) {
				if (1) {
					struct sockaddr_in addr4;
					memset(&addr4,0,sizeof(addr4));
					addr4.sin_family=AF_INET;
					addr4.sin_port=addr6->sin6_port;
					memcpy(&addr4.sin_addr.s_addr, addr6->sin6_addr.s6_addr+12, sizeof(addr4.sin_addr.s_addr));
					memcpy(&addr,&addr4,sizeof(addr4));

					sprintf(ip_str, inet_ntoa(addr.sin_addr));
				   *port = ntohs(addr.sin_port);
				   //sprintf(ip_str, ">> X");
				}
				else
					sprintf(ip_str, ">> %d", addr.sin_family);
			}

			///////////////////////////////////////////////////////////////
			//if(!strcmp(ip_str, "0.0.0.0") || !strcmp(ip_str, "8.8.8.8") )
			//{
			//	sprintf(ip_str, ">> %d", addr.sin_family);
			//}
			///////////////////////////////////////////////////////////////
		}*/
   }
	else
	{
		sprintf(flow_id_arr[1].ip_str, "No net info");
		flow_id_arr[1].port = 11;
	}
	return i_ref;
}

int tell_socket_quality(int newfd, int type)
{
		 char ips[32];
		 memset(ips, 0, 32 * sizeof(char));
		 int pp = 0;
		 socket_ana_foo(newfd, ips, &pp);

		 if(type == 0)
		{
			 if(pp <100)
					return 0;
		}
		else if(type == 1)
		{
			if(strcmp(ips, "127.0.0.1") || pp <100)
					return 0;
		}
		 return 1;
}

//Token bucket algorithm; 2019.3.11;
void set_time(void){
	struct itimerval itv;
   itv.it_interval.tv_sec=0;
   itv.it_interval.tv_usec=tb_span;
   itv.it_value.tv_sec=0;
   itv.it_value.tv_usec=0;
   setitimer(ITIMER_REAL,&itv,NULL);
}   

//2019.8.29 Clear history data;
int open_his_sig(int mode)
{
	int i_ret = 1;

    //char str_c[32];
	//sprintf(str_c, WDIR);
	char f_p[128];
	//sprintf(f_p, "/root/%s/als_his.txt", str_c);
	sprintf(f_p, "/%s/als_his.txt", WDIR);
	hstream = fopen(f_p,"w+");

	if(hstream==NULL)
	{
		printf("\nThe als_his.txt cannot be opened!\n");
		return 0;
	}

	hfno = fileno(hstream);

	return i_ret;
}

int write_his_sig(int v)
{
	int i_ret = 1;
	if(hstream==NULL)
		return 0;
	char v_line[8];
	sprintf(v_line, "%d", v);
	fseek(hstream,0,SEEK_SET);
	//printf("\n---%s---\n", v_line);
	fwrite(v_line,1,strlen(v_line),hstream);
	fflush(hstream);
	return i_ret;
}

int read_his_sig()
{
	int i_ret = 0;

	if(hstream==NULL)
		return i_ret;

	char line[16];
	memset(line, 0, 16);
	lseek(hfno,0L,SEEK_SET);
	
	if(fread(line,  1, 16, hstream)>0)
	{
		//printf("\n+++%s+++\n", line);
		i_ret = atoi(line);
	}

	return i_ret;
}

//2020.8.13  iterative moving average;
//double moving_his_ratio = 0.5;

int iterative_moving_ave(double * his_comp, double * cur_comp, double moving_his_ratio)
{
	int i_ret = 1;
	if(* his_comp < 0.00001)
		* his_comp = * cur_comp;
	else
		* his_comp = moving_his_ratio * (*his_comp) + (1.0 - moving_his_ratio) * (*cur_comp);
	return i_ret;
}

//To check the version of the target DB; 2021.2.20;
int check_db_version(int db_type)
{
	int f_val = 1;
	char cmd[64];

	if(app_version!=0) return 1;
     
	if(db_type==1)
		sprintf(cmd, "mysqld --version");
	else if(db_type==2)
		sprintf(cmd, "mongod --version");
	else return -1;

	//FILE * pxstream = NULL;

	pstream = popen(cmd,"r");

	if(pstream == NULL) return -2;

	ios_handle = fileno(pstream);

	char buf[256];
	memset(buf, 0, 256);

	int r_num = fread(buf,sizeof(char),sizeof(buf),pstream);

	if(r_num<=0) return -3;

	int c_str[4];
	memset(c_str,0,4*sizeof(int));

	//printf("\nbuf: %s\n", buf);

    if(db_type==1){
		//usr/sbin/mysqld  Ver 8.0.23 for Linux on x86_64 (MySQL Community Server - GPL) : app_version: 80023
		int x_i = sscanf(buf, "/usr/sbin/mysqld  Ver %d.%d.%d for", &c_str[0], &c_str[1] , &c_str[2]);
				
		if(x_i==3){
			app_version = c_str[0] * 10000 + c_str[1] * 100 + c_str[2];
			app_fver = c_str[0];
			app_sver = c_str[1];
			app_tver = c_str[2];
		}

	}else{
		//db version v4.4.3 : app_version: 40403
		int x_i = sscanf(buf, "db version v%d.%d.%d\n", &c_str[0], &c_str[1] , &c_str[2]);
				
		if(x_i==3){
			app_version = c_str[0] * 10000 + c_str[1] * 100 + c_str[2];
			app_fver = c_str[0];
			app_sver = c_str[1];
			app_tver = c_str[2];
		}
	}

	//printf("\napp_version: %d\n", app_version);
	
	return f_val;
}

int folder_mkdirs(char *folder_path)
{	
	if(!access(folder_path, F_OK)){                       
		return 1;
	}

	char path[256];                                        
	char *path_buf;                                        
	char temp_path[256];                                  
	char *temp;                                            
	int temp_len;                                          
	
	memset(path, 0, sizeof(path));
	memset(temp_path, 0, sizeof(temp_path));
	strcat(path, folder_path);
	path_buf = path;

	while((temp = strsep(&path_buf, "/")) != NULL){        
		temp_len = strlen(temp);	
		if(0 == temp_len){
			continue;
		}
		strcat(temp_path, "/");
		strcat(temp_path, temp);
		
		if(-1 == access(temp_path, F_OK)){                 
			if(-1 == mkdir(temp_path, 0777)){
				printf("Error: Fail to create working_directory = %s!\n", temp_path);
				return 2;
			}
		}
	}
	printf("Successfully create or access working_directory = %s\n", temp_path);
	return 1;
}

#endif