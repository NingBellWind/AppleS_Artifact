#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>

#include "common.h"

#define RAMLEN 1024*1024*16

char ram_cache[RAMLEN];
char sd[]={'a','a'};
int len = 0;

FILE * stream = NULL;

void func(int x)
{
	FILE * wstream;
	char f_str[64];
	char cmd[128];
	int i;
	sprintf(f_str,"iostat_info_all");
	wstream = fopen(f_str,"w+");
	
	printf("\n%s",ram_cache);
	
	fwrite(ram_cache,1,len,wstream);
	fclose(wstream);
	pclose(stream);
	
	int num = sd[1]-sd[0]+1;
	for(i=0; i < 2; i++)
	{
		if(i==0)
		{
			sprintf(f_str,"iostat_info_%s.txt", DEV);
			sprintf(cmd,"cat iostat_info_all | grep %s", DEV);
		}
		else if(i==1)
		{
			sprintf(f_str,"iostat_info_loop0.txt");
			sprintf(cmd,"cat iostat_info_all | grep loop0");
		}

		wstream = fopen(f_str,"w+");
		stream = popen(cmd,"r");
		
		int r_num = 0;
		do{
			r_num = fread(ram_cache,1,RAMLEN,stream);
			fwrite(ram_cache,1,r_num,wstream);
		}while(r_num);	
		fclose(wstream);
		pclose(stream);
	}	
	exit(0);
}

int main(int argc, char *argv[])
{
	
	char buf[512];
	char *cmd = "iostat -d -x -k 1";
	//char *cmd = "iostat -d -x -k 1 | grep td &";
	
	signal(SIGINT,func);

	stream = popen(cmd,"r");
	if(stream == NULL)
	{
		printf("\nfailed to call popen(%s,\"r\")",cmd);
	}

	while(len < RAMLEN)
	{
		int r_num = fread(buf,sizeof(char),sizeof(buf),stream);

		if(r_num + len > RAMLEN){
			printf("\nram_cache is enough ...");
			break;
		}

		if(r_num > 0)
		{
			memcpy(&ram_cache[len],buf,r_num);
			len += r_num;
		}
	}	
	func(0);
	return 0;
}