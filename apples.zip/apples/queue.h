#ifndef QUEUE_H
#define QUEUE_H

#include "common.h"

#define DISKSTATS	"/proc/diskstats"
 #define MAX_NAME_LEN	72

int open_diskstats_io()
{
	int i_ret = 1;

	fp_diskstats = fopen(DISKSTATS, "r");

	if(fp_diskstats==NULL)
		return 0;
	else
		disk_handle = fileno(fp_diskstats);

	return i_ret;
}

int close_diskstats_io()
{
	int i_ret = 1;

	fclose(fp_diskstats);

	fp_diskstats = NULL;

	return i_ret;
}

int get_diskstats_io(char * device)
{
	int i_ret = 1;

	char line[256];
	char dev_name[MAX_NAME_LEN];
	unsigned long long major[14];
	unsigned int depth = 0;

	if(fp_diskstats==NULL)
		return 0;

	while (fgets(line, 256, fp_diskstats) != NULL) {

		//sscanf(line, "%u %u %s %lu %*u %llu %*u %lu %*u %llu %llu %u %llu %llu",
		sscanf(line, "%u      %u %s %lu %u %lu %lu %lu %lu %lu %lu %u %lu %lu",
			   &major[0], &major[1], dev_name,
			   &major[2],  &major[3],  &major[4], &major[5], &major[6], &major[7], &major[8], &major[9], &depth, &major[10], &major[12], &major[13]);
			
			if (!strcmp(dev_name,device)) {
				i_ret = depth;
				break;
		     }
	}

	lseek(disk_handle,0L,SEEK_SET);

	return i_ret;
}

int io_util_open(char * device)
{
	int f_val = 1;

	char cmd[64];
     
	 //2019.8.28  10-second statistics;
	//sprintf(cmd, "iostat -d -x -k 1");
	sprintf(cmd, "iostat -d -x -k 10");

	printf("\nopen iostat for device : %s", device);

	pstream = popen(cmd,"r");

	if(pstream == NULL)
	{
		printf("\nFailed to call popen(%s,\"r\")",cmd);
		return -1;
	}
	else
	{
		ios_handle = fileno(pstream);
		printf("\nCall popen(%s,\"r\") successfully  ios_handle = %d",cmd,ios_handle);

		printf("\n");
		printf("\n");
	}
	
	return f_val;
}


#define RAMLEN 1024*16
//#define UTSTATS	"/root/"DIR"/util_max.txt"
//#define IOSTATS	"/root/"DIR"/iostat.txt"
//#define IOSTATR	"/root/"DIR"/iostat_rec.txt"
//#define UTSTATR	"/root/"DIR"/util_rec.txt"

char UTSTATS[128];
char IOSTATS[128];
char IOSTATR[128];
char UTSTATR[128];

FILE * futil = NULL;
FILE * fiost = NULL;
FILE * fiosr = NULL;
FILE * futilr = NULL;

char ram_cache[RAMLEN];
int len = 0;
//The length of statistical time period; 
int sta_len = STA_CYCLE;
int sta_idx = 0;
int e_idx = 0;
int version = 1;
float util_max = 0;
float util_now = 0;
float d_max = 0;
float d_now = 0;
float d_ave = 0;
float d_tot = 0;
float s_now = 0;
float s_ave = 0;
float s_tot = 0;

//read iops;
float r_io_now = 0;
float r_io_ave = 0;
float r_io_tot = 0;

//write iops;
float w_io_now = 0;
float w_io_ave = 0;
float w_io_tot = 0;

float rw_io_ave = 0;
float rw_io_tot = 0;

//read bw(KB/s);
float r_bw_now = 0;
float r_bw_ave = 0;
float r_bw_tot = 0;

//write bw(KB/s);
float w_bw_now = 0;
float w_bw_ave = 0;
float w_bw_tot = 0;

float rw_bw_ave = 0;
float rw_bw_tot = 0;

//2019.8.28 storing the history data;
#define MAX_STA_INT STA_CYCLE
float d_arr[MAX_STA_INT];
float s_arr[MAX_STA_INT];
float r_io_arr[MAX_STA_INT];
float w_io_arr[MAX_STA_INT];
float rw_io_arr[MAX_STA_INT];
float r_bw_arr[MAX_STA_INT];
float w_bw_arr[MAX_STA_INT];
float rw_bw_arr[MAX_STA_INT];

int open_max_util()
{
	int i_ret = 1;

    sprintf(UTSTATS, "%s/util_max.txt", WDIR);
	sprintf(IOSTATS, "%s/iostat.txt", WDIR);
	sprintf(IOSTATR, "%s/iostat_rec.txt", WDIR);
	sprintf(UTSTATR, "%s/util_rec.txt", WDIR);

	//ustream = fopen(UTSTATS,"r");
	ustream = fopen(UTSTATS,"w+");

	if(ustream==NULL)
	{
		printf("\nUtil_max cannot be read!\n");
		return 0;
	}

	util_handle = fileno(ustream);

	return i_ret;
}

int last_ver = 0;

int get_util_d(int * ver, float * util, float * d, float * s, float * r_io_ave, float * w_io_ave, float * r_bw_ave, float * w_bw_ave, float * rw_io_ave, float * rw_bw_ave)
{
	int i_ret = 0;
	//int ver = 0;
	char line[128];
	memset(line, 0, 128);
	lseek(util_handle,0L,SEEK_SET);
	fgets(line, 128, ustream);

	int x_i = sscanf(line, ",%d,%f,%f,%f,%f,%f,%f,%f,%f,%f,\n",ver, util, d, s, r_io_ave, w_io_ave, r_bw_ave, w_bw_ave, rw_io_ave, rw_bw_ave);

	if(*ver!=last_ver)
	{
		i_ret = *ver;
		last_ver = *ver;
	}
	//else
	//	printf("\nold_version = %d\n", last_ver);

	return i_ret;
}

float move_average(float h_a, float h_data, float n_data)
{
	float ans = 0;
	 ans = h_a * h_data + (1.0 - h_a) * n_data;
	return ans;
}

float r_bw_last = 0.0;
float w_bw_last = 0.0;


float get_io_util(char * device)
{
	float f_val = 0;

	if(pstream==NULL)
	{
		printf("\npstream==NULL\n");
		return 0;
	}

	char buf[512];
	char wuf[512];
	char * app_str = NULL;
	memset(ram_cache, 0, RAMLEN);
	memset(buf, 0, 512);
	memset(wuf, 0, 512);

	//2019.8.28 storing the history data;
	memset(d_arr, 0, MAX_STA_INT * sizeof(float));
	memset(s_arr, 0, MAX_STA_INT * sizeof(float));
	memset(r_io_arr, 0, MAX_STA_INT * sizeof(float));
	memset(w_io_arr, 0, MAX_STA_INT * sizeof(float));
	memset(rw_io_arr, 0, MAX_STA_INT * sizeof(float));
	memset(r_bw_arr, 0, MAX_STA_INT * sizeof(float));
	memset(w_bw_arr, 0, MAX_STA_INT * sizeof(float));
	memset(rw_bw_arr, 0, MAX_STA_INT * sizeof(float));


	futil =  fopen(UTSTATS,"w+");

	if(futil==NULL)
	{
		printf("\nfutil==NULL\n");
		return 0;
	}

	fiost =  fopen(IOSTATS,"w+");

	if(fiost==NULL)
	{
		printf("\nfiost==NULL\n");
		return 0;
	}

	fiosr =  fopen(IOSTATR,"w+");

	if(fiosr==NULL)
	{
		printf("\nfiosr==NULL\n");
		return 0;
	}

	futilr =  fopen(UTSTATR,"w+");

	if(futilr==NULL)
	{
		printf("\nfutilr==NULL\n");
		return 0;
	}

    //skip the first 3 results impacted by the previous configuration 2020.3.21;
	int skip_n = 2;

	while(len < RAMLEN)
	{
		int r_num = fread(buf,sizeof(char),sizeof(buf),pstream);

		if(r_num + len > RAMLEN){
			printf("\nram_cache is enough ...");
			break;
		}

		if(r_num > 0)
		{
			memcpy(&ram_cache[len],buf,r_num);
			len += r_num;

			if((app_str = strstr(ram_cache, device))!=NULL)
			{
				char c_str[16][32];
				memset(c_str,0,16*32);

				int x_i = sscanf(app_str, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",
										c_str[0],c_str[1] ,c_str[2], c_str[3], c_str[4], c_str[5]
									   ,c_str[6] ,c_str[7], c_str[8], c_str[9]
									   ,c_str[10] ,c_str[11], c_str[12], c_str[13]);
				
				if(x_i==14)
				{
					d_now = atof( c_str[8]);
					util_now =  atof( c_str[13]);
					s_now =  atof( c_str[12]);

					//read iops;
					r_io_now =  atof( c_str[3]);
					//write iops;
					w_io_now =  atof( c_str[4]);
					//read bw;
					r_bw_now =  atof( c_str[5]);
					//write bw;
					w_bw_now =  atof( c_str[6]);

					//Clear history data; 2019.8.28;
					//write_his_sig(1);
					his_sta_clear = read_his_sig();
                     if( his_sta_clear == 1)
					{
						 his_sta_clear = 0;
						 sta_idx = 0;
						 e_idx = 0;
						 write_his_sig(his_sta_clear);
						 printf("\nClear history data...[%d]\n", his_sta_clear);
					}

					if(d_now<1 && util_now<1 && s_now<1) 
					{
						memset(ram_cache, 0, RAMLEN);
						len = 0;
						continue;
					}
					
					//skip the first 3 results impacted by the previous configuration 2020.3.21;
					if(skip_n>0){
						/*if((r_bw_now - r_bw_last < 0.1 && r_bw_now - r_bw_last > -0.1) && (w_bw_now - w_bw_last < 0.1 && w_bw_now - w_bw_last > -0.1)){
							usleep(1000000);
							printf("\nTEST --- r_bw_now = %08.2f  r_bw_last = %08.2f  w_bw_now = %08.2f  w_bw_last = %08.2f\n"
						         , r_bw_now, r_bw_last, w_bw_now, w_bw_last);
							continue;
						}*/
						skip_n--;
						printf("\nSKIP --- D_now = %08.2f  Util_now = %08.2f  Ser_now = %08.2f  iops = %08.2f  bw = %08.2f\n"
						         , d_now, util_now, s_now, r_io_now + w_io_now, r_bw_now + w_bw_now);

						r_bw_last = r_bw_now;
						w_bw_last = w_bw_now;

						memset(ram_cache, 0, RAMLEN);
						len = 0;
						continue;
					}

					printf("\nD_now = %08.2f  Util_now = %08.2f  Ser_now = %08.2f  iops = %08.2f  bw = %08.2f\n"
						         , d_now, util_now, s_now, r_io_now + w_io_now, r_bw_now + w_bw_now);

					sprintf(wuf,"%08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f\n"
							, d_now, util_now, s_now, atof( c_str[7]), atof( c_str[8]), atof( c_str[9]), atof( c_str[10]), atof( c_str[11]), r_io_now, w_io_now, r_bw_now, w_bw_now, r_io_now + w_io_now, r_bw_now + w_bw_now);
					fwrite(wuf,1,strlen(wuf),fiost);
					fflush(fiost);

					d_arr[e_idx%MAX_STA_INT] = d_now;
					s_arr[e_idx%MAX_STA_INT] = s_now;
					r_io_arr[e_idx%MAX_STA_INT] = r_io_now;
					w_io_arr[e_idx%MAX_STA_INT] =  w_io_now;
					rw_io_arr[e_idx%MAX_STA_INT] = (r_io_now + w_io_now);
					r_bw_arr[e_idx%MAX_STA_INT] =  r_bw_now;
					w_bw_arr[e_idx%MAX_STA_INT] = w_bw_now;
					rw_bw_arr[e_idx%MAX_STA_INT] = (r_bw_now + w_bw_now);

					sta_idx++;
					e_idx++;

					d_tot += d_now;
					s_tot += s_now;

					r_io_tot += r_io_now;
					w_io_tot += w_io_now;
					rw_io_tot += (r_io_now + w_io_now);

					r_bw_tot += r_bw_now;
					w_bw_tot += w_bw_now;
					rw_bw_tot += (r_bw_now + w_bw_now);

					if(util_now > util_max)
						util_max = util_now;

					if(d_now > d_max)
						d_max = d_now;


					if(e_idx>=sta_len)
					{
						int ix=0;
						
						float d_total = 0;
						float s_total = 0;
						float r_io_total = 0;
						float w_io_total = 0;
						float rw_io_total = 0;
						float r_bw_total = 0;
						float w_bw_total = 0;
						float rw_bw_total = 0;

						for(ix = e_idx-sta_len;ix < e_idx-1;ix++)
						{
								d_total += d_arr[ix%MAX_STA_INT];
								s_total += s_arr[ix%MAX_STA_INT];
								r_io_total += r_io_arr[ix%MAX_STA_INT];
								w_io_total += w_io_arr[ix%MAX_STA_INT];
								rw_io_total += rw_io_arr[ix%MAX_STA_INT];
								r_bw_total += r_bw_arr[ix%MAX_STA_INT];
								w_bw_total += w_bw_arr[ix%MAX_STA_INT];
								rw_bw_total += rw_bw_arr[ix%MAX_STA_INT];
						}

						float h_a = 0.5;

						d_ave = move_average(h_a, d_total/(sta_len-1), d_now);
						s_ave = move_average(h_a, s_total/(sta_len-1), s_now);
						r_io_ave = move_average(h_a, r_io_total/(sta_len-1), r_io_now);
						w_io_ave = move_average(h_a, w_io_total/(sta_len-1), w_io_now);
						rw_io_ave = move_average(h_a, rw_io_total/(sta_len-1), r_io_now + w_io_now);
						r_bw_ave = move_average(h_a, r_bw_total/(sta_len-1), r_bw_now);
						w_bw_ave = move_average(h_a, w_bw_total/(sta_len-1), w_bw_now);
						rw_bw_ave = move_average(h_a, rw_bw_total/(sta_len-1), r_bw_now + w_bw_now);


						/*sprintf(wuf,",%8d,%8.2f,%8.2f,%8.2f,%8.2f,%8.2f,%8.2f,%8.2f,%8.2f,%8.2f,\n"
							, version, util_max, d_ave, s_ave, r_io_ave, w_io_ave, r_bw_ave, w_bw_ave, rw_io_ave, rw_bw_ave);
						printf("\n>>> Long-term statistcs (KB/S) = %s\n", wuf);
						fseek(futil,0,SEEK_SET);
						fwrite(wuf,1,strlen(wuf),futil);
						fflush(futil);*/

						sprintf(wuf,"%08d     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f \n"
							, version, util_max, d_ave, s_ave, r_io_ave, w_io_ave, r_bw_ave, w_bw_ave, rw_io_ave, rw_bw_ave);
						fwrite(wuf,1,strlen(wuf),futilr);
					    fflush(futilr);
					}

					if(sta_idx >= sta_len)
					{
						d_ave = d_tot / sta_idx;
						s_ave = s_tot / sta_idx;
						r_io_ave = r_io_tot/sta_idx;
						w_io_ave = w_io_tot/sta_idx;
						r_bw_ave = r_bw_tot/sta_idx;
						w_bw_ave = r_bw_tot/sta_idx;
						rw_io_ave = rw_io_tot/sta_idx;
						rw_bw_ave = rw_bw_tot/sta_idx;
						
						///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						sprintf(wuf,",%8d,%8.2f,%8.2f,%8.2f,%8.2f,%8.2f,%8.2f,%8.2f,%8.2f,%8.2f,\n"
							, version, util_max, d_ave, s_ave, r_io_ave, w_io_ave, r_bw_ave, w_bw_ave, rw_io_ave, rw_bw_ave);
						printf("\n>>> Long-term statistcs (KB/S) = %s\n", wuf);
						fseek(futil,0,SEEK_SET);
						fwrite(wuf,1,strlen(wuf),futil);
						fflush(futil);

						//skip the first 3 results impacted by the previous configuration 2020.3.21;
						skip_n = 3;
						///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

						sprintf(wuf,"%08d     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f     %08.2f \n"
							, version, util_max, d_ave, s_ave, r_io_ave, w_io_ave, r_bw_ave, w_bw_ave, rw_io_ave, rw_bw_ave);
						fwrite(wuf,1,strlen(wuf),fiosr);
					    fflush(fiosr);

						sta_idx = 0;
						util_max = 0;
						d_tot = 0;
						d_max = 0;
						s_tot = 0;
						r_io_tot = 0;
						w_io_tot = 0;
						rw_io_tot = 0;
						r_bw_tot = 0;
						w_bw_tot = 0;
						rw_bw_tot = 0;
				}
				version++;
				memset(ram_cache, 0, RAMLEN);
				len = 0;
			}
		}
	}	
	}
		
		/*if(r_num > 0)
		{
				
				char c_str[16][32];
				memset(c_str,0,16*32);

				int x_i = sscanf(line, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",
										c_str[0],c_str[1] ,c_str[2], c_str[3], c_str[4], c_str[5]
									   ,c_str[6] ,c_str[7], c_str[8], c_str[9]
									   ,c_str[10] ,c_str[11], c_str[12], c_str[13]);

				printf("\nx_i = %d  %s\n", x_i, c_str[0]);

				if(!strcmp(c_str[0], "xvdbp1"))
					printf("\n%s\n", line);
				
		}*/
	

	return f_val;
}

#endif