#ifndef TAIL_H
#define TAIL_H

#include "common.h"

#define JT 1                //number of types of SLO jobs
#define epsilon  10E-8


double diff_dig(double x)
{
  double y,z;
  int i;
  
    y=z=x/(1.+x);  i=2;
    while(1) { y+=x/i/(i+x); i++;
      if(fabs(z-y)<epsilon) { z=y; break; }
      else { z=y; }
      if(i>100000) { break; } //cout<<"No solution!"<<endl; break; 
   } 

  return y;
}

double diff_poly(double x)
{
  int i;
  double y,z;

  y=z=(2.*x+x*x)/(x+1)/(x+1); i=1;
  while(1) { y+=(2.*(i+1)*x+x*x)/(i+1)/(i+1)/(i+1+x)/(i+1+x); i++;
    if(fabs(z-y)<epsilon) { z=y; break; }
    else { z=y; }
   if(i>100000) { break; }
  }

  return z;
}

//E: mean latency time; (e.g., 32.334 ms)
//V: STD * STD; (e.g., 63.520 * 63.520)
//p: percentile (e.g., 0.99)
//k: fan-out (e.g., 1)
//return tail latency defined at the percentile (e.g., 308 ms for P99 tail latency) 
double find_tail(double E, double V, double p,  int k)
{
  double alpha, beta,aa,bb, x,y,z;
 int i,j;

  i=0; aa=1E-8; bb=1000000.;
  while(1) { i++;
      beta=E/diff_dig(aa);
      x=V-beta*beta*diff_poly(aa);
      beta=E/diff_dig(bb); 
      y=V-beta*beta*diff_poly(bb);
      beta=E/diff_dig((aa+bb)/2.);
      z=V-beta*beta*diff_poly((aa+bb)/2.0); 

      if(fabs(y-x)<epsilon) 
      { break; } //{cout<<" alpha: "<<(aa+bb)/2<<" beta: "<<beta<<endl; break; }
      if(x*z>0) {
            if(z*y>0) { return 0; }
            aa=(aa+bb)/2; 
      }
     else { 
          if(y*z<0) { return 0; }
          bb=(aa+bb)/2.;
     }
     if(i>100000) {  return 0;}
  }
   
   z=-beta*log(1-pow(p,1./k/aa));

  return z;
}

//given the fanout: fan, the p-th: pec tail latency: tl, and mean variance ratio: gamma 
//calculate the budget E=mean task response time
double get_budget(double tl, int fan, double pec, double gamma)
{
 double bg, bg1, bg2, var1, var2;
 double x, y,z;
 int j;

 bg1=epsilon; bg2=tl; j=0;
 while (1) { j++;
        var1=bg1*gamma*bg1*gamma; var2=bg2*gamma*bg2*gamma;
        x=find_tail(bg1, var1, pec, fan); if(fabs(x-tl)<epsilon) { bg=bg1; /*printf("\n1111  x = %f    tl = %f\n", x, tl);*/ break;}
        y=find_tail(bg2, var2, pec, fan); if(fabs(x-tl)<epsilon) {bg=bg2; /*printf("\n2222\n");*/ break; }
	if(x<=tl && y>=tl) { bg2=(bg1+bg2)/2.; } //move to the mid point 
        else if(x<=tl && y<=tl) { bg=bg2; bg2=bg+(bg2-bg1)/2.; bg1=bg; } //move to higher end
        else if(x>=tl && y>=tl) { bg=bg1; bg1=bg-(bg2-bg1)/2.; bg2=bg; } //move to the lower end	
        else 	{break; /*printf("\n3333\n");*/}	
		
	if(j>1000000) { break; /*printf("\n4444\n");*/}
 }
 
 return bg;	
}

//Budgets array;
//mean_bud_arr[i][j][k]; 
//i: percentiles(0: 0.95; 1:0.99; 2:0.999);
//j: 5 latency SLOs (ms) (for P95: 10, 20, 30, 40, 50);
//j: 5 latency SLOs (ms) (for P99: 20, 40, 60, 80, 100);
//j: 5 latency SLOs (ms) (for P99.9: 40, 80, 120, 160, 200);
//k: the gamma value increase from 0.5 to 2.9 by 0.01;
/*double mean_bud_arr[3][5][25]={{{5.131450, 4.651425, 4.244414, 3.864302, 3.569121, 3.313855, 3.092326, 2.899501, 2.731222, 2.584030, 2.455029, 2.341790, 2.242270, 2.154748, 2.077770, 2.010106, 1.950714, 1.898711, 1.853346, 1.813979, 1.780067, 1.751148, 1.726828, 1.706775, 1.690706},
{10.262899, 9.302850, 8.488828, 7.728603, 7.138243, 6.627711, 6.184653, 5.799002, 5.462445, 5.168060, 4.910057, 4.683579, 4.484540, 4.309496, 4.155539, 4.020212, 3.901429, 3.797423, 3.706692, 3.627959, 3.560134, 3.502296, 3.453656, 3.413549, 3.381413},
{15.394349, 13.954275, 12.733242, 11.592905, 10.707364, 9.941566, 9.276979, 8.698503, 8.193667, 7.752090, 7.365086, 7.025369, 6.726810, 6.464243, 6.233309, 6.030317, 5.852143, 5.696134, 5.560039, 5.441938, 5.340202, 5.253444, 5.180484, 5.120324, 5.072119},
{20.525798, 18.605700, 16.977656, 15.457207, 14.276486, 13.255422, 12.369306, 11.598004, 10.924890, 10.336120, 9.820115, 9.367159, 8.969080, 8.618991, 8.311079, 8.040423, 7.802858, 7.594846, 7.413385, 7.255918, 7.120269, 7.004592, 6.907312, 6.827098, 6.762825},
{25.657248, 23.257125, 21.222070, 19.321508, 17.845607, 16.569277, 15.461632, 14.497506, 13.656112, 12.920150, 12.275143, 11.708949, 11.211350, 10.773739, 10.388848, 10.050529, 9.753572, 9.493557, 9.266731, 9.069897, 8.900336, 8.755740, 8.634140, 8.533873, 8.453532}}, 
{{7.648282, 6.724423, 5.965503, 5.274765, 4.749083, 4.301143, 3.916705, 3.584702, 3.296363, 3.044633, 2.823784, 2.629126, 2.456798, 2.303598, 2.166862, 2.044362, 1.934224, 1.834868, 1.744953, 1.663338, 1.589047, 1.521242, 1.459204, 1.402308, 1.350014},
{15.296564, 13.448846, 11.931005, 10.549530, 9.498166, 8.602286, 7.833410, 7.169405, 6.592725, 6.089265, 5.647567, 5.258252, 4.913595, 4.607195, 4.333724, 4.088724, 3.868449, 3.669737, 3.489906, 3.326675, 3.178093, 3.042485, 2.918408, 2.804617, 2.700027},
{22.944846, 20.173270, 17.896508, 15.824295, 14.247249, 12.903429, 11.750114, 10.754107, 9.889088, 9.133898, 8.471351, 7.887379, 7.370393, 6.910793, 6.500587, 6.133086, 5.802673, 5.504605, 5.234859, 4.990013, 4.767140, 4.563727, 4.377613, 4.206925, 4.050041},
{30.593128, 26.897693, 23.862011, 21.099060, 18.996332, 17.204572, 15.666819, 14.338809, 13.185451, 12.178531, 11.295135, 10.516505, 9.827190, 9.214391, 8.667449, 8.177449, 7.736898, 7.339473, 6.979813, 6.653351, 6.356186, 6.084970, 5.836817, 5.609234, 5.400054},
{38.241411, 33.622116, 29.827513, 26.373825, 23.745415, 21.505715, 19.583524, 17.923512, 16.481813, 15.223163, 14.118918, 13.145631, 12.283988, 11.517988, 10.834311, 10.221811, 9.671122, 9.174341, 8.724766, 8.316689, 7.945233, 7.606212, 7.296021, 7.011542, 6.750068}}, 
{{11.237126, 9.651089, 8.386355, 7.263730, 6.427024, 5.725933, 5.132928, 4.627315, 4.193154, 3.817951, 3.491778, 3.206662, 2.956146, 2.734961, 2.538776, 2.364011, 2.207693, 2.067334, 1.940844, 1.826459, 1.722684, 1.628241, 1.542041, 1.463146, 1.390747},
{22.474251, 19.302178, 16.772710, 14.527460, 12.854048, 11.451865, 10.265857, 9.254630, 8.386309, 7.635903, 6.983556, 6.413324, 5.912293, 5.469922, 5.077551, 4.728023, 4.415386, 4.134668, 3.881688, 3.652919, 3.445367, 3.256482, 3.084082, 2.926292, 2.781493},
{33.711377, 28.953267, 25.159065, 21.791190, 19.281072, 17.177798, 15.398785, 13.881945, 12.579463, 11.453854, 10.475334, 9.619986, 8.868439, 8.204882, 7.616327, 7.092034, 6.623079, 6.202001, 5.822532, 5.479378, 5.168051, 4.884723, 4.626123, 4.389438, 4.172240},
{44.948503, 38.604356, 33.545421, 29.054920, 25.708096, 22.903731, 20.531714, 18.509260, 16.772618, 15.271806, 13.967112, 12.826648, 11.824585, 10.939843, 10.155102, 9.456046, 8.830772, 8.269335, 7.763376, 7.305837, 6.890734, 6.512964, 6.168164, 5.852585, 5.562987},
{56.185628, 48.255445, 41.931776, 36.318650, 32.135119, 28.629664, 25.664642, 23.136575, 20.965772, 19.089757, 17.458890, 16.033310, 14.780732, 13.674804, 12.693878, 11.820057, 11.038465, 10.336669, 9.704220, 9.132296, 8.613418, 8.141205, 7.710205, 7.315731, 6.953733}}};

double lat_slo_arr[3][5] = {{10.0, 20.0, 30.0, 40.0, 50.0},{20.0, 40.0, 60.0, 80.0, 100.0},{40.0, 80.0, 120.0, 160.0, 200.0}};*/

//Budgets array;
//mean_bud_arr[i][j][k]; 
//i: percentiles(0: 0.95; 1:0.99; 2:0.999);
//j: 5 latency SLOs (ms) (for P95: 10, 15, 20, 25, 30);
//j: 5 latency SLOs (ms) (for P99: 20, 25, 30, 35, 40);
//j: 5 latency SLOs (ms) (for P99.9: 30, 40, 50, 60, 70);
//k: the gamma value increase from 0.5 to 2.9 by 0.01;
double mean_bud_arr[3][5][25]={{{5.131450, 4.651425, 4.244414, 3.864302, 3.569121, 3.313855, 3.092326, 2.899501, 2.731222, 2.584030, 2.455029, 2.341790, 2.242270, 2.154748, 2.077770, 2.010106, 1.950714, 1.898711, 1.853346, 1.813979, 1.780067, 1.751148, 1.726828, 1.706775, 1.690706}, {7.697174, 6.977138, 6.366621, 5.796452, 5.353682, 4.970783, 4.638490, 4.349252, 4.096834, 3.876045, 3.682543, 3.512685, 3.363405, 3.232122, 3.116655, 3.015159, 2.926072, 2.848067, 2.780019, 2.720969, 2.670101, 2.626722, 2.590242, 2.560162, 2.536060}, {10.262899, 9.302850, 8.488828, 7.728603, 7.138243, 6.627711, 6.184653, 5.799002, 5.462445, 5.168060, 4.910057, 4.683579, 4.484540, 4.309496, 4.155539, 4.020212, 3.901429, 3.797423, 3.706692, 3.627959, 3.560134, 3.502296, 3.453656, 3.413549, 3.381413}, {12.828624, 11.628563, 10.611035, 9.660754, 8.922804, 8.284639, 7.730816, 7.248753, 6.828056, 6.460075, 6.137572, 5.854474, 5.605675, 5.386869, 5.194424, 5.025264, 4.876786, 4.746779, 4.633366, 4.534948, 4.450168, 4.377870, 4.317070, 4.266936, 4.226766}, {15.394349, 13.954275, 12.733242, 11.592905, 10.707364, 9.941566, 9.276979, 8.698503, 8.193667, 7.752090, 7.365086, 7.025369, 6.726810, 6.464243, 6.233309, 6.030317, 5.852143, 5.696134, 5.560039, 5.441938, 5.340202, 5.253444, 5.180484, 5.120324, 5.072119}}, 
{{7.648282, 6.724423, 5.965503, 5.274765, 4.749083, 4.301143, 3.916705, 3.584702, 3.296363, 3.044633, 2.823784, 2.629126, 2.456798, 2.303598, 2.166862, 2.044362, 1.934224, 1.834868, 1.744953, 1.663338, 1.589047, 1.521242, 1.459204, 1.402308, 1.350014}, {9.560353, 8.405529, 7.456878, 6.593456, 5.936354, 5.376429, 4.895881, 4.480878, 4.120453, 3.805791, 3.529730, 3.286408, 3.070997, 2.879497, 2.708578, 2.555453, 2.417781, 2.293585, 2.181191, 2.079172, 1.986308, 1.901553, 1.824005, 1.752886, 1.687517}, {11.472423, 10.086635, 8.948254, 7.912147, 7.123625, 6.451714, 5.875057, 5.377053, 4.944544, 4.566949, 4.235675, 3.943689, 3.685196, 3.455397, 3.250293, 3.066543, 2.901337, 2.752302, 2.617430, 2.495007, 2.383570, 2.281864, 2.188806, 2.103463, 2.025020}, {13.384494, 11.767741, 10.439630, 9.230839, 8.310895, 7.527000, 6.854233, 6.273229, 5.768635, 5.328107, 4.941621, 4.600971, 4.299396, 4.031296, 3.792009, 3.577634, 3.384893, 3.211019, 3.053668, 2.910841, 2.780832, 2.662174, 2.553607, 2.454040, 2.362524}, {15.296564, 13.448846, 11.931005, 10.549530, 9.498166, 8.602286, 7.833410, 7.169405, 6.592725, 6.089265, 5.647567, 5.258252, 4.913595, 4.607195, 4.333724, 4.088724, 3.868449, 3.669737, 3.489906, 3.326675, 3.178093, 3.042485, 2.918408, 2.804617, 2.700027}}, 
{{8.427844, 7.238317, 6.289766, 5.447797, 4.820268, 4.294450, 3.849696, 3.470486, 3.144866, 2.863464, 2.618834, 2.404997, 2.217110, 2.051221, 1.904082, 1.773009, 1.655770, 1.550500, 1.455633, 1.369844, 1.292013, 1.221181, 1.156531, 1.097360, 1.043060}, {11.237126, 9.651089, 8.386355, 7.263730, 6.427024, 5.725933, 5.132928, 4.627315, 4.193154, 3.817951, 3.491778, 3.206662, 2.956146, 2.734961, 2.538776, 2.364011, 2.207693, 2.067334, 1.940844, 1.826459, 1.722684, 1.628241, 1.542041, 1.463146, 1.390747}, {14.046407, 12.063861, 10.482944, 9.079662, 8.033780, 7.157416, 6.416161, 5.784144, 5.241443, 4.772439, 4.364723, 4.008328, 3.695183, 3.418701, 3.173469, 2.955014, 2.759616, 2.584167, 2.426055, 2.283074, 2.153354, 2.035301, 1.927551, 1.828933, 1.738433}, {16.855689, 14.476633, 12.579533, 10.895595, 9.640536, 8.588899, 7.699393, 6.940973, 6.289732, 5.726927, 5.237667, 4.809993, 4.434220, 4.102441, 3.808163, 3.546017, 3.311539, 3.101001, 2.911266, 2.739689, 2.584025, 2.442361, 2.313062, 2.194719, 2.086120}, {19.664970, 16.889406, 14.676121, 12.711527, 11.247292, 10.020382, 8.982625, 8.097801, 7.338020, 6.681415, 6.110612, 5.611659, 5.173256, 4.786181, 4.442857, 4.137020, 3.863463, 3.617834, 3.396477, 3.196304, 3.014696, 2.849422, 2.698572, 2.560506, 2.433807}}};

double lat_slo_arr[3][5] = {{10.0, 15.0, 20.0, 25.0, 30.0},{20.0, 25.0, 30.0, 35.0, 40.0},{30.0, 40.0, 50.0, 60.0, 70.0}};

double lat_per[3] = {0.95, 0.99, 0.999};
int per_n = 3;
int slo_n = 5;

//2020.8.21 the parameters of budget curves;
double bud_para_arr[3][5][3] = {{{1.57336, -7.13503, 0.24573}//0.95, 10ms;
                             ,{2.36004, -10.70255, 0.24573}//0.95, 15ms;
							 ,{3.14672, -14.27006, 0.24573}//0.95, 20ms;
							 ,{3.9334, -17.83758, 0.24573}//0.95, 25ms;
							 ,{4.72008, -21.4051, 0.24573}}//0.95, 30ms;
                             ,{{1.21451, -12.70085, 0.24779}//0.99, 20ms;
							 ,{1.51814, -15.87607, 0.24779}//0.99, 25ms;
							 ,{1.82177, -19.05128, 0.24779}//0.99, 30ms;
							 ,{2.12539, -22.2265, 0.24779}//0.99, 35ms;
							 ,{2.42902, -25.40171, 0.24779}}//0.99, 40ms;
							 ,{{0.97334, -15.68257, 0.21657}//0.999, 30ms;
							 ,{1.29779, -20.9101, 0.21657}//0.999, 40ms;
							 ,{1.62224, -26.13761, 0.21657}//0.999, 50ms;
							 ,{1.94669, -31.36514, 0.21657}//0.999, 60ms;
							 ,{2.27113, -36.59266, 0.21657}}};//0.999, 70ms;

//SLO requirements and  gamma(STD/mean)->indices i, j, k for the budget array;
int latency_slo_val(double latency, double per, double gamma, int * i, int * j, int * k)
{
	int i_ret  = 1;
	if(i==NULL || j==NULL || k==NULL)
		return -1;

	int ii=0;
	
	for(ii=0;ii<per_n;ii++){
		double ab = per - lat_per[ii];
		if(ab < 0)
			ab = -ab; 
		if(ab < 0.001)
			break;
	}

	//printf("\np ii =%d  per = %f   lat_per[ii] = %f   ads = %f", ii, per, lat_per[ii], per - lat_per[ii]);

	if(ii>=per_n)
	{
		return -1;
	}

	*i = ii;

	for(ii=0;ii<slo_n;ii++){
		if(lat_slo_arr[*i][ii] > latency + 0.005)
			break;
	}

	if(ii>=slo_n) ii = slo_n;
	if(ii<=0)  ii = 1;
	*j = ii-1;

	*k = (int)((gamma - 0.5)/0.1) + 1;

	if(*k > 24) *k = 24;

	return i_ret;
}

double get_bg(double latency, double per, double gamma)
{
	double bg = 0.0;
	int i,j,k;
	
	int f = latency_slo_val(latency, per, gamma, &i, &j, &k);
	//printf("\nf=%d", f);

	if(f>0){
		if(gamma<=2.9){
			bg = mean_bud_arr[i][j][k];
		}else{ //for the value greater than 2.9; 2020.8.22;
			double a = bud_para_arr[i][j][0];
			double b = bud_para_arr[i][j][1];
			double c = bud_para_arr[i][j][2];

			bg = a - b * pow(c, gamma);
			bg *= 0.9;
		}
	}
	
    return bg;
}


//Rolling queues for storing all the request latencies from each individual user (e.g., capacity=1024 per user);
//#define Q_capacity 1024
#define Q_capacity 128
#define Q_freq 40
#define MAX_PER 3

//the number of requests for tail latency prediction; 2020.3.15;
//#define P_size 1024
#define P_size 128

//for statistics;
double app_lat_arr[MAX_FD_NUM][Q_capacity];
//for tail latency prediction; 2020.3.15;
double pre_lat_arr[MAX_FD_NUM][P_size];
int p_front[MAX_FD_NUM], p_rear[MAX_FD_NUM], p_req_n[MAX_FD_NUM], p_req_n_all[MAX_FD_NUM];
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

double app_lat_sum[MAX_FD_NUM];
double app_square_sum[MAX_FD_NUM];
double app_lat_sum_all[MAX_FD_NUM];
double app_square_sum_all[MAX_FD_NUM];
int front[MAX_FD_NUM], rear[MAX_FD_NUM], req_n[MAX_FD_NUM];
//the mean goal (data series) for each circular queue; (2020.1.22)
int front_a = -1, rear_a = -1, req_n_a = 0;

//mean values for all the queues;
double app_mean_arr[MAX_FD_NUM];
//std values for all the queues;
double app_std_arr[MAX_FD_NUM];
//mean values over all the request for all the queues;
double app_mean_allreq_arr[MAX_FD_NUM];
//std values of all the requests for all the queues;
double app_std_allreq_arr[MAX_FD_NUM];
//P95, P99, P99.9 latency violate signal (1: violate, 0: compliance) for all the queues;
int app_ptail_arr[MAX_FD_NUM][MAX_PER];
//for local measure window; 2020.2.24;
int app_ptail_loc[MAX_FD_NUM][MAX_PER];
//for global time period; 2020.2.24;
int app_ptail_glb[MAX_FD_NUM][MAX_PER];
//the number of latency violations out of 1024 requests;
int app_latvio_arr[MAX_FD_NUM][MAX_PER];
///////////////////////////////////////////////////////////////////////////////////////
//total IO violations; 2020.2.23;
//the total number of latency violations out of all the requests;
double app_latvio_tot[MAX_FD_NUM][MAX_PER];
double app_req_tot[MAX_FD_NUM];
//total IO statistics for 10-sec interval throughput; 2020.3.22;
double req_tot_all = 0;
double last_req_tot_all = 0;
long long last_period = 0;
double min_thpt_n = 9999999;
double min_thpt_x = 0;
//2020.8.30 average throughput;
double xput_tot_all = 0;
///////////////////////////////////////////////////////////////////////////////////////
//latency slos for percentiles (P95, P99, P99.9,  and 0 value is invalid, ms);
double app_latslo_arr[MAX_FD_NUM][MAX_PER];
//the mean goal for each queue;
double app_meanslo_arr[MAX_FD_NUM];
//the mean goal for each queue (stable average); 2020.6.6;
double sta_meanslo_arr[MAX_FD_NUM];
//the mean goal for each queue (total); 2020.6.6;
double tot_meanslo_arr[MAX_FD_NUM];
//the mean goal for each queue (times); 2020.6.6;
double times_meanslo_arr[MAX_FD_NUM];
//the throughput goal for each queue;
double app_thptslo_arr[MAX_FD_NUM];
//the correction for estimation; 2020.8.13;
double correction_arr[MAX_FD_NUM];
double perror_arr[MAX_FD_NUM];
double quota_arr[MAX_FD_NUM];
double his_quota_arr[MAX_FD_NUM];
//////////////////////////////////////////////////////////
//only for print; 2020.2.24;
double app_pnt_arr[MAX_FD_NUM];
////////////////////////////////////////////////////////////

//the mean goal (data series) for each queue; (2020.1.22)
#define SERN 16
double meanslo_cir_arr[SERN][MAX_FD_NUM];
//percentiles;
int percentiles[MAX_PER] = {950, 990, 999};

//the mean latency for all the requests;
double lat_mean_sta = 0;

//the latency STD for all the requests;
double lat_std_sta = 0;

//////////////////////////////////////////////////////////////////////////////////////
//The algorithm for computing tail latency at (P95, P99. P99.9)
//support the maximum latency is 1000 * 10 (unit is 100 us);
//2020.1.26;
#define MAX_LAT_PNT 1000 * 10
//#define MAX_GUA_NUM 128
#define MAX_GUA_NUM 256 // Extension 2020.9.4;
int histogram[MAX_GUA_NUM][MAX_LAT_PNT];
int ops_total[MAX_GUA_NUM];
double lat_p_arr[MAX_GUA_NUM];
double lat_t_arr[MAX_GUA_NUM];

//tell if the idx-indexed user is priviliged (due to tail latency slos); (2020.1.22)
int is_user_priviliged(int idx)
{
	int i_ret = 0, j=0;
	double tslo = 0.0;

	if(idx<=0 || idx>=fd_id_ptr)
		return i_ret;

	i_ret = flow_id_arr[idx].is_priviliged;

	//Have prespecified latency slos;
	//for(j=0; j<MAX_PER; j++){ tslo += app_latslo_arr[idx][j];}

	//if(tslo > 0.1) i_ret = 1;

	return i_ret;
}

//get the number of priviliged users;
int get_user_priviliged(){
	int i=0;
	int p_num = 0;
	for(i=1;i<=fd_id_ptr;i++){
			if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
				if( is_user_priviliged(i)>0)
					p_num++;
			}
	}
	return p_num;
}

//get the number of priviliged users;
int get_dry_user_priviliged(){
	int i=0;
	int p_num = 0;
	for(i=2;i<=fd_id_ptr;i++){
				if( is_user_priviliged(i)>0)
					p_num++;
	}
	return p_num;
}

//get the number of users; //2021.9.1
int get_dry_users(){
	int i=0;
	int p_num = 0;
	for(i=1;i<=fd_id_ptr;i++){
				if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2)
					p_num++;
	}
	return p_num;
}

//get the number of priviliged users;
int get_dry_user_unpriviliged(){
	int i=0;
	int p_num = 0;
	for(i=2;i<=fd_id_ptr;i++){
				if( is_user_priviliged(i)>0)
					p_num++;
	}
	return fd_id_ptr - p_num - 1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//Running status 1: high load (HL); 0: low load (LL); //2020.8.12;
void set_tail_slo_clear()
{
	sys_aggregate_status = 0;
}

int set_tail_slo_status(int status)
{
	int i_ret = 1;
	sys_aggregate_status += status;
	return i_ret;
}

void io_sta_status()
{
	if(sys_running_status==0){
		sys_LL_ios += 1.0;
	}else{
		sys_HL_ios += 1.0;
	}
}

//BE user I/O regulation 2020.8.13;
int BR()
{
	int i_ret = 1;
	int pro_i = 1;
	//using the static processing;
	if(be_num<1 || his_BE_xput < 0.0001) {
		i_ret = max_iodelay_ratio;
	}
	//Running status 1: high load (HL); 0: low load (LL); //2020.8.12;
    else{
		//A delay unit is 200 us;
		//i_ret = (int)((5.0 * 1000.0)/his_BE_xput);
		if(thread_con > 1 && fd_id_ptr > 1){
			float pro_f = (((float)fd_id_ptr - (float)be_num) / ((float)thread_con - (float)be_num));
			pro_i = (fd_id_ptr - be_num) / (thread_con - be_num);
			if(pro_f - (float)pro_i > 0.5)
			   pro_i += 1;
		}
		
		if(pro_i > 1)
			i_ret = (int)((5.0 * 5.0 * 1000.0)/(his_BE_xput * ((float)pro_i - 1.0)));
		else
			i_ret = (int)((5.0 * 1000.0)/his_BE_xput);

		if(i_ret < 1)
			i_ret = 1;
		else if(i_ret > max_iodelay_ratio)
			i_ret = max_iodelay_ratio;
	}
	return i_ret;
}

//LR user I/O regulation 2020.8.13;
int LR_algo(int i)
{
	int i_ret = 1;
	//using the static processing;
	if(be_num<1) return 0;

	//check if any tail latency SLO violated; 2020.2.23;
	 int k=0, signal = 0, worst_sig = 0;
	 for(k=0;k<MAX_PER;k++) {
		//the mode of tail latency guarantee; 2020.2.24;
		if(tail_guarantee_mode == GLB_LOC_SEN)
		{
			signal += app_ptail_arr[i][k];
			//worst signal for 100% percentile guarantee; 2020.2.25;
			//worst_sig += app_latvio_tot[i][k] + app_latvio_arr[i][k];
		}
		else if(tail_guarantee_mode == GLB_NON_SEN)
		{
			signal += app_ptail_glb[i][k];
			//worst signal for 100% percentile guarantee; 2020.2.25;
			//worst_sig += app_latvio_tot[i][k];
		}
		else if(tail_guarantee_mode == NON_LOC_SEN)
		{
			signal += app_ptail_loc[i][k];
			//worst signal for 100% percentile guarantee; 2020.2.25;
			//worst_sig += app_latvio_arr[i][k];
		}
	}

	//Actual tail latency SLO enforcement feedback based adjustment; 2020.8.13;
	if(signal > 0){
		if(perror_arr[i] >= 0.11)  
			perror_arr[i] *= 0.9;
	}else{
		//if(perror_arr[i] <= 1.96)  
		//	perror_arr[i] += 0.04;
		perror_arr[i] = 1.0; //after 2020.8.19;
	}

	//if (app_mean_arr[i] > correction_arr[i] * app_meanslo_arr[i]){
	  if(1){
		double mate = 1.0/perror_arr[i];
		Quota_f = 1;

		if(his_BE_xput>0.01){
			quota_arr[i] = ((mate * app_thptslo_arr[i])/his_BE_xput) * ((double)DATA_SET/2.0);
			//quota_arr[i] = ((mate * app_thptslo_arr[i])/his_BE_xput) * (double)DATA_SET;
			//quota_arr[i] = ((app_thptslo_arr[i])/BE_xput) * (double)DATA_SET;

            //system is now in the congestion situation, BE user takes the minimum quota of throughput (far smaller than his_BE_xput); 2020.8.22;
			if(sys_state==1){
				quota_arr[i] *= (double)DATA_SET;
			}
			
			//Have history debt to pay off; 2020.8.22;
			if(signal > 0){
				quota_arr[i] = DATA_SET * max_provision_ratio;
			}
			
			if(quota_arr[i] < (double)DATA_SET){
				quota_arr[i] = (double)DATA_SET;
			}
			if(quota_arr[i] > max_quota){
				quota_arr[i] = max_quota;
			}

			iterative_moving_ave(&his_quota_arr[i], &quota_arr[i], his_moving_ratio);

			if (app_mean_arr[i] > correction_arr[i] * app_meanslo_arr[i]){
				if(tail_lat_guarantee) //Control tail latency SLO enforcement, added by ning at 2020.9.15;
					req_token[i] = (int)quota_arr[i];
			}
		}
	}

	return i_ret;
}

int BE_xput_update()
{
	int i_ret = 1;

	//get the number of unpriviliged users;
    be_num = get_dry_user_unpriviliged();
	//if(be_num>0){
	if(be_num>0 && sys_LL_xput > sys_HL_xput){
		//BE_xput = (his_sys_HL_xput - LS_xput_bg)/be_num;
		BE_xput = (sys_HL_xput - LS_xput_bg)/be_num;
		if(BE_xput < min_BE_xput)
			BE_xput = min_BE_xput;
		if(BE_xput > 1000)
			BE_xput = 1000;
		iterative_moving_ave(&his_BE_xput, &BE_xput, 0.5);
	}

	return i_ret;
}

//After the derivation of LS user's total throughput budget; 2020.8.13
int LR_budget()
{
	int i=0;
	int i_ret = 1;

	BE_xput_update();

	for(i=1;i<=fd_id_ptr;i++){
			if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
				if( is_user_priviliged(i)>0){
					//LR user I/O regulation 2020.8.13;
					LR_algo(i);
				}	
			}
	}

	return i_ret;
}

int set_start_time_status()
{
	int i_ret  = 1;
	//Initial LL load;
	if(pre_sys_running_status==-1 && sys_running_status==0){
		//Time interval controlling; 
		sc_gettime(&sys_LL_start);
	}
	//Initial HL load;
	else if(pre_sys_running_status==-1 && sys_running_status==1){
		//Time interval controlling; 
		sc_gettime(&sys_HL_start);
	}
	//from LL to HL;
	else if(pre_sys_running_status < sys_running_status){
		//Time interval controlling; 
		sc_gettime(&sys_HL_start);
		sys_HL_ios = 0.0;
		//Statistics for LL; 
		period_LL = mtime_since_now(&sys_LL_start);
		sys_LL_xput = (1000.0 * sys_LL_ios)/(double)period_LL;
		iterative_moving_ave(&his_sys_LL_xput, &sys_LL_xput, his_moving_ratio);
		tot_period_LL += period_LL;
		//Update average throughput;
		if(sys_HL_xput > 0.000001){
			sys_ave_xput = (sys_HL_xput * (double)period_HL)/((double)period_HL + (double)period_LL) + (sys_LL_xput * (double)period_LL)/((double)period_HL + (double)period_LL);
			iterative_moving_ave(&his_sys_ave_xput, &sys_ave_xput, his_moving_ratio);
		}
		//After the derivation of LS user's total throughput budget; 2020.8.13
		//LR_budget();
	}
	//from HL to LL;
	else if(pre_sys_running_status > sys_running_status){
		//Time interval controlling; 
		sc_gettime(&sys_LL_start);
		sys_LL_ios = 0.0;
		//Statistics for HL; 
		period_HL = mtime_since_now(&sys_HL_start);
		sys_HL_xput = (1000.0 * sys_HL_ios)/(double)period_HL;
		iterative_moving_ave(&his_sys_HL_xput, &sys_HL_xput, his_moving_ratio);
		tot_period_HL += period_HL;
		//Update average throughput;
		if(sys_LL_xput > 0.000001){
			sys_ave_xput = (sys_HL_xput * (double)period_HL)/((double)period_HL + (double)period_LL) + (sys_LL_xput * (double)period_LL)/((double)period_HL + (double)period_LL);
			iterative_moving_ave(&his_sys_ave_xput, &sys_ave_xput, his_moving_ratio);
		}
		//After the derivation of LS user's total throughput budget; 2020.8.13
		LR_budget();
	}

	//After the derivation of LS user's total throughput budget; 2020.8.13
	//LR_budget();
	return i_ret;
}

void set_tail_slo_conclude()
{
	pre_sys_running_status = sys_running_status;
	if(sys_aggregate_status == 0){
		sys_running_status = 0;
	}else{
		sys_running_status = 1;
	}
	set_start_time_status();
}
///////////////////////////////////////////////////////////////////////////////////////////////////

//histogram statistics; 2020.1.27
int add_histogram(int idx, unsigned long long it_val)
{
	int i_ret = 1;
	if(idx<0 || idx>=MAX_GUA_NUM) return 0;
	//Obtain latency in the metric of 100us;
	int lat_d = it_val/100;
	if(lat_d < MAX_LAT_PNT) histogram[idx][lat_d]++;
	ops_total[idx]++;
	return i_ret;
}

//the idx user;
//lat_p95: P95 tail latency in ms (23.5 ms);
//lat_p99: P99 tail latency in ms (23.5 ms);
//lat_p99.9: P99.9 tail latency in ms (23.5 ms);
int get_tail_latency(int idx, double * lat_p95, double * lat_p99, double * lat_p999)
{
	int i_ret = 1, i=0, opc = 0, opn1 = 0, opn2 = 0, opn3 = 0;
	if(idx<0 || idx>=MAX_GUA_NUM) return 0;
	if(ops_total[idx]<1024) return 0;

	for(i=0; i < MAX_LAT_PNT; i++){
		opc += histogram[idx][i];
		double per =  ((double)opc * 100.0)/((double)ops_total[idx]);

		if(per >= 95.0 && !opn1) {*lat_p95 = ((double)i * 100.0)/1000.0; opn1++;}
		else if (per >= 99.0 && !opn2) {*lat_p99 = ((double)i * 100.0)/1000.0; opn2++;}
		else if (per >= 99.9 && !opn3) {*lat_p999 = ((double)i * 100.0)/1000.0; opn3++;}

		if(opn1 >0 && opn2 > 0 && opn3 > 0) break;
	}

	//clr_histogram();

	return i_ret;
}

//the idx user;
//lat_p99: P99 tail latency in ms (23.5 ms);
//pred_lat_p99: the estimated P99 tail latency;
int pnt_int = 0;
int get_tail_latency_p99(int idx, double * lat_p99, double * pred_lat_p99)
{
	int i_ret = 0, i=0, opc = 0, opn2 = 0;
	if(idx<0 || idx>=MAX_GUA_NUM) return 0;
	if(ops_total[idx]<Q_capacity) return 0;
	
	if(pnt_int++>=Q_freq){
		if(app_mean_arr[idx]<=0.01 && app_std_arr[idx]<=0.01) return 0;

		for(i=0; i < MAX_LAT_PNT; i++){
			opc += histogram[idx][i];
			double per =  ((double)opc * 100.0)/((double)ops_total[idx]);
			if (per >= 99.0 && !opn2) {*lat_p99 = ((double)i * 100.0)/1000.0; opn2++; break;}
		}

		*pred_lat_p99 = find_tail(app_mean_arr[idx], app_std_arr[idx] * app_std_arr[idx], 0.99,  1);
		pnt_int = 0;
		i_ret = 1;
	}

	//clr_histogram();

	return i_ret;
}

//the idx user;
//it_val: latency in ms (23.5 ms);
int tail_latency_checkin(int idx, double it_val)
{
	int i_ret = 1;
	if(idx<0 || idx>=MAX_GUA_NUM) return 0;
	//Obtain latency in the metric of 100us;
	int lat_d = (int)(it_val * 10);
	if(lat_d < MAX_LAT_PNT) histogram[idx][lat_d]++;
	ops_total[idx]++;
	return i_ret;
}

//the idx user;
//it_val: latency in ms (23.5 ms);
int tail_latency_checkout(int idx, double it_val)
{
	int i_ret = 1;
	if(idx<0 || idx>=MAX_GUA_NUM) return 0;
	//Obtain latency in the metric of 100us;
	int lat_d = (int)(it_val * 10);
	if(lat_d < MAX_LAT_PNT) histogram[idx][lat_d]--;
	ops_total[idx]--;
	return i_ret;
}

void clr_histogram()
{
	//support the maximum latency is 1000 * 100 (unit is 10 us); 2020.1.26;
	memset(histogram, 0, MAX_GUA_NUM * MAX_LAT_PNT *sizeof(int));
	memset(ops_total, 0, MAX_GUA_NUM * sizeof(int));
}
//////////////////////////////////////////////////////////////////////////////////////

//latency slos input;
void lat_slo_input()
{
	int i=0;

	//latency-sensitive users;
	/*for(i=2;i<=3;i++){
	//A host version;
	//for(i=1;i<=11;i++){
		app_latslo_arr[i][0] = 15.0;
		
		//app_latslo_arr[i][1] = 35.0;
		app_latslo_arr[i][1] = 25.0;

		app_latslo_arr[i][2] = 40.0;
		//app_latslo_arr[i][2] = 50.0;
		//app_latslo_arr[i][2] = 60.0;
		flow_id_arr[i].is_priviliged = 1;
		
		if(static_pri_set>0){ //2020.4.17; Static priority setting;
			req_token[i] = DATA_SET * max_provision_ratio;
			//flow_id_arr[i].times_delay = max_iodelay_ratio;
			///////////////////////////////////////////////////////////////////////////////
			//quota_arr[i] = 32; //2020.8.18 TEST;
			///////////////////////////////////////////////////////////////////////////////
		}
	}*/

    for(i=64;i<=64+11;i++){
	//for(i=2;i<=11;i++){
	//for(i=2;i<=201;i++){ //Extension 2020.9.4;
		//app_latslo_arr[i][0] = 20.0;
		
		//app_latslo_arr[i][1] = 35.0;
		//app_latslo_arr[i][1] = 30.0;

		//app_latslo_arr[i][2] = 55.0;
		//app_latslo_arr[i][2] = 50.0;
		//app_latslo_arr[i][2] = 60.0;
		//for read workload;
		app_latslo_arr[i][0] = 5.0;
		app_latslo_arr[i][1] = 10.0;
		app_latslo_arr[i][2] = 20.0;

		//for 50/50 read/write workloads;
		//app_latslo_arr[i][0] = 20.0;
		//app_latslo_arr[i][1] = 40.0;
		//app_latslo_arr[i][2] = 60.0;

		flow_id_arr[i].is_priviliged = 1;

		quota_arr[i] = DATA_SET * max_provision_ratio;  //2020.8.27 TEST;
		
		if(static_pri_set>0){ //2020.4.17; Static priority setting;
			if(tail_lat_guarantee){ //Control tail latency SLO enforcement, added by ning at 2020.9.15;
				req_token[i] = DATA_SET * max_provision_ratio;
				//flow_id_arr[i].times_delay = max_iodelay_ratio;
				///////////////////////////////////////////////////////////////////////////////
				quota_arr[i] = DATA_SET * max_provision_ratio;  //2020.8.18 TEST;
				///////////////////////////////////////////////////////////////////////////////
			}
		}
	}

	//latency-sensitive users;
	/*for(i=1;i<=91;i++){
	//A host version;
	//for(i=1;i<=11;i++){
		app_latslo_arr[i][0] = 20.0;
		
		//app_latslo_arr[i][1] = 35.0;
		app_latslo_arr[i][1] = 35.0;

		app_latslo_arr[i][2] = 60.0;
		//app_latslo_arr[i][2] = 50.0;
		//app_latslo_arr[i][2] = 60.0;
		flow_id_arr[i].is_priviliged = 1;
		
		if(static_pri_set>0){ //2020.4.17; Static priority setting;
			req_token[i] = DATA_SET * max_provision_ratio;
			//flow_id_arr[i].times_delay = max_iodelay_ratio;
		}
	}*/
	
	//VM2; 25 users, the first 5 users have MP tail latency SLOs (workloadcz);
	/*for(i=2;i<=2+4;i++){
		app_latslo_arr[i][0] = 10.0;
		
		//app_latslo_arr[i][1] = 35.0;
		app_latslo_arr[i][1] = 20.0;

		app_latslo_arr[i][2] = 30.0;
		//app_latslo_arr[i][2] = 50.0;
		//app_latslo_arr[i][2] = 60.0;
		flow_id_arr[i].is_priviliged = 1;
		
		if(static_pri_set>0){ //2020.4.17; Static priority setting;
			req_token[i] = DATA_SET * max_provision_ratio;
			//flow_id_arr[i].times_delay = max_iodelay_ratio;
		}
	}

	//VM3; 25 users, the first 5 users have MP tail latency SLOs (workloadcz20);
	for(i=28;i<=28+4;i++){
		app_latslo_arr[i][0] = 15.0;
		
		//app_latslo_arr[i][1] = 35.0;
		app_latslo_arr[i][1] = 30.0;

		app_latslo_arr[i][2] = 50.0;
		//app_latslo_arr[i][2] = 50.0;
		//app_latslo_arr[i][2] = 60.0;
		flow_id_arr[i].is_priviliged = 1;
		
		if(static_pri_set>0){ //2020.4.17; Static priority setting;
			req_token[i] = DATA_SET * max_provision_ratio;
			//flow_id_arr[i].times_delay = max_iodelay_ratio;
		}
	}

	//VM4; 25 users, the first 5 users have MP tail latency SLOs (workloadcz40);
	for(i=54;i<=54+4;i++){
		app_latslo_arr[i][0] = 20.0;
		
		//app_latslo_arr[i][1] = 35.0;
		app_latslo_arr[i][1] = 30.0;

		app_latslo_arr[i][2] = 40.0;
		//app_latslo_arr[i][2] = 50.0;
		//app_latslo_arr[i][2] = 60.0;
		flow_id_arr[i].is_priviliged = 1;
		
		if(static_pri_set>0){ //2020.4.17; Static priority setting;
			req_token[i] = DATA_SET * max_provision_ratio;
			//flow_id_arr[i].times_delay = max_iodelay_ratio;
		}
	}

	//VM5; 25 users, the first 5 users have MP tail latency SLOs (workloadcz60);
	for(i=80;i<=80+4;i++){
		app_latslo_arr[i][0] = 10.0;
		
		//app_latslo_arr[i][1] = 35.0;
		app_latslo_arr[i][1] = 20.0;

		app_latslo_arr[i][2] = 40.0;
		//app_latslo_arr[i][2] = 50.0;
		//app_latslo_arr[i][2] = 60.0;
		flow_id_arr[i].is_priviliged = 1;
		
		if(static_pri_set>0){ //2020.4.17; Static priority setting;
			req_token[i] = DATA_SET * max_provision_ratio;
			//flow_id_arr[i].times_delay = max_iodelay_ratio;
		}
	}*/

	//Batch users (BE for throughput SLOs); 2020.2.24;
    for(i=12;i<=102;i++){
		//ops/sec;
		app_thptslo_arr[i] = 100.0;
	}
}


//initialization;
void init_cir_queue()
{
    memset(app_lat_arr, 0, MAX_FD_NUM * Q_capacity * sizeof(double));
	//for tail latency prediction; 2020.3.15;
	memset(pre_lat_arr, 0, MAX_FD_NUM * P_size * sizeof(double));
	memset(app_lat_sum, 0, MAX_FD_NUM * sizeof(double));
	memset(app_square_sum, 0, MAX_FD_NUM * sizeof(double));
	memset(app_lat_sum_all, 0, MAX_FD_NUM * sizeof(double));
	memset(app_square_sum_all, 0, MAX_FD_NUM * sizeof(double));

	//memset(front, 0, MAX_FD_NUM * sizeof(int));
	//memset(rear, 0, MAX_FD_NUM * sizeof(int));

	 memset(app_mean_arr, 0, MAX_FD_NUM *sizeof(double));
	//std values for all the queues;
	 memset(app_std_arr, 0, MAX_FD_NUM *sizeof(double));
	 //mean values over all the request for all the queues;
	 memset(app_mean_allreq_arr, 0, MAX_FD_NUM *sizeof(double));
	//std values of all the requests for all the queues;
	 memset(app_std_allreq_arr, 0, MAX_FD_NUM *sizeof(double));
	//P95, P99, P99.9 latency violate signal (1: violate, 0: compliance) for all the queues;
	 memset(app_ptail_arr, 0, MAX_FD_NUM * MAX_PER * sizeof(int));
	 memset(app_ptail_loc, 0, MAX_FD_NUM * MAX_PER * sizeof(int));
	 memset(app_ptail_glb, 0, MAX_FD_NUM * MAX_PER * sizeof(int));
	//the number of latency violations out of 1024 requests;
	 memset(app_latvio_arr, 0, MAX_FD_NUM * MAX_PER * sizeof(int));
	 ///////////////////////////////////////////////////////////////////////////////////////
	//total IO violations; 2020.2.23;
	//the total number of latency violations out of all the requests;
	memset(app_latvio_tot, 0, MAX_FD_NUM * MAX_PER * sizeof(double));
	memset(app_req_tot, 0, MAX_FD_NUM * sizeof(double));
	///////////////////////////////////////////////////////////////////////////////////////
	//latency slos for percentiles (P95, P99, P99.9,  and 0 value is invalid, ms);
	 memset(app_latslo_arr, 0, MAX_FD_NUM * MAX_PER * sizeof(double));
	 //the mean goal for each queue;
	 memset(app_meanslo_arr, 0, MAX_FD_NUM *sizeof(double));
	  //the throughput goal for each queue;
	 memset(app_thptslo_arr, 0, MAX_FD_NUM *sizeof(double));
	//the mean goal (data series) for each queue; (2020.1.22)
	 memset(meanslo_cir_arr, 0, SERN * MAX_FD_NUM * sizeof(double));

	memset(lat_p_arr, 0, MAX_GUA_NUM * sizeof(double));
	memset(lat_t_arr, 0, MAX_GUA_NUM * sizeof(double));

	//////////////////////////////////////////////////////////
	//only for print; 2020.2.24;
	memset(app_pnt_arr, 0, MAX_FD_NUM * sizeof(double));
	////////////////////////////////////////////////////////////

	//the mean goal for each queue (stable average); 2020.6.6;
	memset(sta_meanslo_arr, 0, MAX_FD_NUM *sizeof(double));
	//the mean goal for each queue (total); 2020.6.6;
	memset(tot_meanslo_arr, 0, MAX_FD_NUM *sizeof(double));
	//the mean goal for each queue (times); 2020.6.6;
	memset(times_meanslo_arr, 0, MAX_FD_NUM *sizeof(double));

	//the correction for estimation; 2020.8.13;
	 memset(correction_arr, 0, MAX_FD_NUM *sizeof(double));
	 memset(quota_arr, 0, MAX_FD_NUM *sizeof(double));
	 memset(his_quota_arr, 0, MAX_FD_NUM *sizeof(double));
	 memset(perror_arr, 0, MAX_FD_NUM *sizeof(double));
	
	int i=0;
	for(i=0;i<MAX_FD_NUM;i++)
	{
		front[i] = -1;
		rear[i] = -1;
		//for tail latency prediction; 2020.3.15;
		p_front[i] = -1;
		p_rear[i] = -1;
		//the correction for estimation; 2020.8.13;
		correction_arr[i] = prediction_E;
		perror_arr[i] = 1.0;
	}

	memset(req_n, 0, MAX_FD_NUM * sizeof(int));
	//for tail latency prediction; 2020.3.15;
	memset(p_req_n, 0, MAX_FD_NUM * sizeof(int));
	memset(p_req_n_all, 0, MAX_FD_NUM * sizeof(int));
	
	//////////////////////////////////////////////////////////////////////////////////////
	 clr_histogram();
	//////////////////////////////////////////////////////////////////////////////////////
}

//check in tail latency violation;
int check_tail_in(double lat, int idx)
{
	int i_ret  = 1, i;

	//2020.8.30 no valid data for tail latency guarantee;
	if(!data_rec_f || !record_reqs)
		return i_ret;
	//////////////////////////////////////////////////

	//total IO violations; 2020.2.23;
	//the total number of latency violations out of all the requests;
	app_req_tot[idx] += 1.0;

	for(i=0;i<MAX_PER;i++){
		//if(lat > app_latslo_arr[idx][i])
		if( app_latslo_arr[idx][i] > 0.01 && lat > app_latslo_arr[idx][i]) //check the valid of SLO, 2020.8.25;
		{
			//the total number of latency violations out of all the requests;
			app_latvio_tot[idx][i] += 1.0;
			double lat_vio_r = (1000 * app_latvio_tot[idx][i])/app_req_tot[idx];
			
            //the number of latency violations out of 1024 requests;
			app_latvio_arr[idx][i]++;
			//violating Px tail latency slo;
			if(app_latvio_arr[idx][i] > 1000 - percentiles[i]  //local time window: tail latencies violations;
		      || lat_vio_r * 1.05 > 1000.0 - (double)percentiles[i]) //global time window: tail latencies violations; 2020.2.23;
				app_ptail_arr[idx][i] = 1;

			if(app_latvio_arr[idx][i] > 1000 - percentiles[i]) { //local time window: tail latencies violations;
				app_ptail_loc[idx][i] = 1;
			}

			if(lat_vio_r * 1.05 > 1000.0 - (double)percentiles[i]){ //global time window: tail latencies violations; 2020.2.23;
				app_ptail_glb[idx][i] = 1;
			}
		}
	}

	return i_ret;
}

//check out tail latency violation;
int check_tail_out(double lat, int idx)
{
	int i_ret  = 1, i;

	//2020.8.30 no valid data for tail latency guarantee;
	if(!data_rec_f || !record_reqs)
		return i_ret;
	//////////////////////////////////////////////////

	for(i=0;i<MAX_PER;i++){
		//if(lat > app_latslo_arr[idx][i])
		if( app_latslo_arr[idx][i] > 0.01 && lat > app_latslo_arr[idx][i]) //check the valid of SLO, 2020.8.25;
		{
			if(app_latvio_arr[idx][i] >= 1)
				app_latvio_arr[idx][i]--;

			double lat_vio_r = (1000 * app_latvio_tot[idx][i])/app_req_tot[idx];

			//violating Px tail latency slo;
			if(app_latvio_arr[idx][i] <= 1000 - percentiles[i]  //local time window: tail latencies violations;
		&&lat_vio_r * 1.05 < 1000.0 - (double)percentiles[i]) //global time window: tail latencies violations; 2020.2.23;
				app_ptail_arr[idx][i] = 0;

			if(app_latvio_arr[idx][i] <= 1000 - percentiles[i]) { //local time window: tail latencies violations;
				app_ptail_loc[idx][i] = 0;
			}

			if(lat_vio_r * 1.05 <= 1000.0 - (double)percentiles[i]){ //global time window: tail latencies violations; 2020.2.23;
				app_ptail_glb[idx][i] = 0;
			}
		}
	}

	return i_ret;
}

//queue is full or not;
int is_full(int idx)
{
    if( (front[idx] == rear[idx] + 1) || (front[idx] == 0 && rear[idx] == Q_capacity-1)) return 1;
    return 0;
}

//for tail latency prediction; 2020.3.15;
int p_is_full(int idx)
{
    if( (p_front[idx] == p_rear[idx] + 1) || (p_front[idx] == 0 && p_rear[idx] == P_size-1)) return 1;
    return 0;
}

//queue is full or not;
int is_full_a()
{
    if( (front_a == rear_a + 1) || (front_a == 0 && rear_a == SERN-1)) return 1;
    return 0;
}

//queue is empty or not;
int is_empty(int idx)
{
    if(front[idx] == -1) return 1;
    return 0;
}

//for tail latency prediction; 2020.3.15;
int p_is_empty(int idx)
{
    if(p_front[idx] == -1) return 1;
    return 0;
}

//queue is empty or not;
int is_empty_a()
{
    if(front_a == -1) return 1;
    return 0;
}

//keep the necessary statistics for tail latency prediction; 2020.3.15;
void p_de_cir_queue(int idx)
{
	if(idx<0 || idx>=MAX_FD_NUM) return;
    double element = 0.0;
    if(p_is_empty(idx)) {
        return -1;
    } else {
        element = pre_lat_arr[idx][p_front[idx]];
		app_lat_sum[idx] -= element;
		app_square_sum[idx] -= element * element;

		p_req_n[idx]--;

        if (p_front[idx] == p_rear[idx]){
            p_front[idx] = -1;
            p_rear[idx] = -1;
        }
        else {
            p_front[idx] = (p_front[idx] + 1) % P_size;
        }
        return element;
    }
}

//delete the 1st element of the idx queue;
double de_cir_queue(int idx)
{
	if(idx<0 || idx>=MAX_FD_NUM) return;
    double element = 0.0;
    if(is_empty(idx)) {
        return -1;
    } else {
		//keep the necessary statistics for tail latency prediction; 2020.3.15;
        element = app_lat_arr[idx][front[idx]];
		/*app_lat_sum[idx] -= element;
		app_square_sum[idx] -= element * element;*/

		 //check out tail latency violation;
         check_tail_out(element, idx);

		 ///////////////////////////////////////////////////////////////////////////
		//histogram statistics; 2020.1.27
		 tail_latency_checkout(idx, element);
		///////////////////////////////////////////////////////////////////////////

		req_n[idx]--;

        if (front[idx] == rear[idx]){
            front[idx] = -1;
            rear[idx] = -1;
        }
        else {
            front[idx] = (front[idx] + 1) % Q_capacity;
        }
        return element;
    }
}

//delete the 1st element of the idx queue;
void de_cir_queue_a()
{
    if(is_empty_a()) {
        return -1;
    } else {

		req_n_a--;

        if (front_a == rear_a){
            front_a = -1;
            rear_a = -1;
        }
        else {
            front_a = (front_a + 1) % SERN;
        }
        return ;
    }
}

//keep the necessary statistics for tail latency prediction; 2020.3.15;
void p_en_cir_queue(int idx, unsigned long long it_val)
{	 
	if(idx<0 || idx>=MAX_FD_NUM || it_val>99999999.9) return;

	 double element =  ((double)it_val)/1000.0; //ms;
	 app_lat_sum[idx] += element;
	 app_square_sum[idx] += element * element;

	 app_lat_sum_all[idx] += element;
	 app_square_sum_all[idx] += element * element;

    if(p_is_full(idx)) p_de_cir_queue(idx);

	p_req_n[idx]++;
	p_req_n_all[idx]++;
    
    if(p_front[idx] == -1) p_front[idx] = 0;
    p_rear[idx] = (p_rear[idx] + 1) % P_size;
    pre_lat_arr[idx][p_rear[idx]] = element;
}

//add the element to the idx queue;
void en_cir_queue(int idx, unsigned long long it_val)
{	
	if(idx<0 || idx>=MAX_FD_NUM || it_val>99999999.9) return;
	///////////////////////////////////////////////////////////////////////////
	//histogram statistics; 2020.1.27
	 //add_histogram(idx, it_val);
	///////////////////////////////////////////////////////////////////////////
	 double element =  ((double)it_val)/1000.0; //ms;
	 //keep the necessary statistics for tail latency prediction; 2020.3.15;
	 /*app_lat_sum[idx] += element;
	 app_square_sum[idx] += element * element;*/

	 //check in tail latency violation;
     check_tail_in(element, idx);

	 ///////////////////////////////////////////////////////////////////////////
	//histogram statistics; 2020.1.27
	 tail_latency_checkin(idx, element);
	///////////////////////////////////////////////////////////////////////////

    if(is_full(idx)) de_cir_queue(idx);

	req_n[idx]++;
    
    if(front[idx] == -1) front[idx] = 0;
    rear[idx] = (rear[idx] + 1) % Q_capacity;
    app_lat_arr[idx][rear[idx]] = element;
}

//add the element to the idx queue; (2020.1.22)
void en_cir_queue_a()
{	 
    if(is_full_a()) de_cir_queue_a();

	req_n_a++;
    
    if(front_a == -1) front_a = 0;
    rear_a = (rear_a + 1) % SERN;
   
	memcpy(meanslo_cir_arr[rear_a], app_meanslo_arr, MAX_FD_NUM *sizeof(double));
}

//calculate the mean latency for the idx queue;
double cal_mean(int idx)
{
	double d_ret = 0.0;

	if(idx<0 || idx>=MAX_FD_NUM)
		return d_ret;

	//if(req_n[idx]>0)
	//	d_ret =  app_lat_sum[idx]/req_n[idx];

	if(p_req_n[idx]>0)
		d_ret =  app_lat_sum[idx]/p_req_n[idx];

	return d_ret;
}

//calculate the mean latency of all the requests for the idx queue;
double cal_mean_allreq(int idx)
{
	double d_ret = 0.0;

	if(idx<0 || idx>=MAX_FD_NUM)
		return d_ret;

	if(p_req_n_all[idx]>0)
		d_ret =  app_lat_sum_all[idx]/p_req_n_all[idx];

	return d_ret;
}

//calculate the latency STD for the idx queue;
double cal_std(int idx)
{
	double d_ret = 0.0;

	if(idx<0 || idx>=MAX_FD_NUM)
		return d_ret;

	/*if(req_n[idx]>0)
	{
		double mean =  app_lat_sum[idx]/(double)req_n[idx];
		double square = app_square_sum[idx]/(double)req_n[idx];
		d_ret = sqrt(square - mean * mean);
	}*/

	if(p_req_n[idx]>0)
	{
		double mean =  app_lat_sum[idx]/(double)p_req_n[idx];
		double square = app_square_sum[idx]/(double)p_req_n[idx];
		d_ret = sqrt(square - mean * mean);
	}

	return d_ret;
}

//calculate the latency STD of all the requests for the idx queue;
double cal_std_allreq(int idx)
{
	double d_ret = 0.0;

	if(idx<0 || idx>=MAX_FD_NUM)
		return d_ret;

	if(p_req_n_all[idx]>0)
	{
		double mean =  app_lat_sum_all[idx]/(double)p_req_n_all[idx];
		double square = app_square_sum_all[idx]/(double)p_req_n_all[idx];
		d_ret = sqrt(square - mean * mean);
	}

	return d_ret;
}

//calculate the latency mean and STD for each individual queue;
int cal_mean_std_users()
{
	int i_ret=1, i=0;

	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM)
		return i_ret;

	for(i=1;i<fd_id_ptr;i++){
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
			app_mean_arr[i] = cal_mean(i);
			app_std_arr[i] = cal_std(i);
		}
	}

	return i_ret;
}

//calculate gamma for a specific queue;
double gamma_val(int idx)
{
	double d_ret = -1.0;

	if(idx<0 || idx>=MAX_FD_NUM)
		return d_ret;

	//if(p_req_n[idx]<P_size) 
	//	return (double)p_req_n[idx];

	double std = cal_std(idx);
	double mean = cal_mean(idx);

	app_mean_arr[idx] = mean;
	app_std_arr[idx] = std;

	double std_allreq = cal_std_allreq(idx);
	double mean_allreq = cal_mean_allreq(idx);

	app_mean_allreq_arr[idx] = mean_allreq;
	app_std_allreq_arr[idx] = std_allreq;

	if(mean > 0.001){
		d_ret = std/mean;
	}
	
	return d_ret;
}

//calculate the mean latency for all the requests;
double cal_mean_all()
{
	double d_ret = 0.0;
	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM)
		return d_ret;

	int i=0;
	int all_req_num = 0;
	double sum_all = 0.0;

	for(i=1; i<fd_id_ptr;i++)
	{
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2)
		{
			sum_all += app_lat_sum[i];
			//all_req_num += req_n[i];
			all_req_num += p_req_n[i];
		}
	}

	if(all_req_num>0)
	{
		d_ret = sum_all/(double)all_req_num;
		lat_mean_sta = d_ret;
	}

	return d_ret;
}

//calculate the latency STD for all the requests;
double cal_std_all()
{
	double d_ret = 0.0;
	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM)
		return d_ret;

	int i=0;
	int all_req_num = 0;
	double sum_all = 0.0;
	double square_all = 0.0;
	double mean = 0.0, squ = 0.0;

	for(i=1; i<fd_id_ptr;i++)
	{
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2)
		{
			sum_all += app_lat_sum[i];
			square_all += app_square_sum[i];
			//all_req_num += req_n[i];
			all_req_num += p_req_n[i];
		}
	}

	if(all_req_num>0)
	{
		mean = sum_all/(double)all_req_num;
		squ = square_all/(double)all_req_num;
		d_ret = sqrt(squ - mean * mean);
		lat_std_sta = d_ret;
	}

	return d_ret;
}

//change scheduling mode; (2020.1.7)
void set_scheduling_mode(int mode)
{
	sched_mode = mode;
	//return;
}

//tell if all the tail latency violation signals are clear; (2020.1.7)
int lat_vio_clear()
{
	int i_ret = 0;
	int i,j;

	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM)
		return i_ret;
	
	for(i=1;i<fd_id_ptr;i++){
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
			    double tslo = 0.0;
				//Have prespecified latency slos;
				for(j=0; j<MAX_PER; j++){ tslo += app_latslo_arr[i][j];}
				if(tslo > 0.1){
					    int k=0, signal = 0;
						for(k=0;k<MAX_PER;k++) 
							//the mode of tail latency guarantee; 2020.2.24;
							if(tail_guarantee_mode == GLB_LOC_SEN)
								signal += app_ptail_arr[i][k];
						    else if(tail_guarantee_mode == GLB_NON_SEN)
								signal += app_ptail_glb[i][k];
							else if(tail_guarantee_mode == NON_LOC_SEN)
								signal += app_ptail_loc[i][k];
						if(signal>0) break;
				}
		}
	}

	if(i>=fd_id_ptr) i_ret = 1;

	return i_ret;
}

//update the I/O delay time of unpriviliged users; (2020.1.22)
//enable: enable this functionality;
int set_iodelay(int enable, int times)
{
	int i_ret = 1, i=0;
	if(!enable) return 0;

	if(times <1)  times = 1;
	if(times > max_iodelay_ratio) times = max_iodelay_ratio;

	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM)
		return i_ret;
	
	for(i=1;i<fd_id_ptr;i++){
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
			if( !is_user_priviliged(i))
				flow_id_arr[i].times_delay = times;
		}
	}

	return i_ret;
}

//update the I/O delay time of unpriviliged users; (2020.1.22)
//enable: enable this functionality;
int set_iodelay_i(int enable, int i, int times)
{
	int i_ret = 1;
	if(!enable) return 0;

	if(times <1)  times = 1;
	if(times > max_iodelay_ratio) times = max_iodelay_ratio;

	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM)
		return i_ret;

	if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && !is_user_priviliged(i))
				flow_id_arr[i].times_delay = times;

	return i_ret;
}

//1) >= 4 steps  reduced by 15%; trigger delay time exponentially increased until 16 times;  check_budget_red(idx, 4, -0.15);
//2) >= 8 steps  increased  by 30%; -= 2  check_budget_red(idx, 8, 0.30);
int check_budget_red(int idx, int offset, double limit_ratio)
{
	int i_ret = 0;

	if(idx<=0 || idx>=fd_id_ptr)
		return i_ret;

	int x_ind = ((rear_a - offset) + SERN)%SERN;

	double var =  meanslo_cir_arr[rear_a][idx] - meanslo_cir_arr[x_ind][idx];

	if((var > -0.1 && var <0.1) || meanslo_cir_arr[x_ind][idx]<0.1) return i_ret;

	var = var/meanslo_cir_arr[x_ind][idx];
	
	//-0.15 reduced by over 15%;
	if(limit_ratio < 0 && var < limit_ratio) {
		i_ret = 1;
	}
	//0.30 increased by over 30%;
	else if(limit_ratio > 0 && var > limit_ratio){
		i_ret = 1;
	}
    
	return i_ret;
}

//2020.7.16  Thoughput allocation target based on the estimation for tail latency and throughput SLOs and the current actual throughput;
int thpt_target_current(double * thpt_tgt, double * thpt_cur)
{
	int i_f = 1;
	if(thpt_tgt==NULL || thpt_cur==NULL)  return -1;

	int i=0;
	*thpt_tgt = 0;
	*thpt_cur = 0;
	double thpt_can = 0;

	for(i=2;i<=fd_id_ptr;i++){
			if(flow_id_arr[i].sched_avoid_f == 2){
				thpt_can = app_thptslo_arr[i];
				*thpt_cur += app_pnt_arr[i];
				if(is_user_priviliged(i)>0){
					if(app_meanslo_arr[i] >0.001){
						double thslo = 1000/app_meanslo_arr[i] ;
						if(thslo > app_thptslo_arr[i]){
							thpt_can = thslo;
						}
					}
				}
				*thpt_tgt += thpt_can;
			}
	}

	return i_f;
}

//detecting I/O congestion or over-provisioning state; 
int detect_iostate()
{
	int i_ret = 0, i=0, qsum = 0, psum = 0, sum = 0, spu_n = 0, rn = 0, vn = 0;

	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM)
		return i_ret;

	//Static settings are always applied to the scheduling //2020.8.21;
	if(static_pri_set) 
		return i_ret;
	
	for(i=1;i<fd_id_ptr;i++){
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
			if( is_user_priviliged(i)){
				if(check_budget_red(i, 4, -0.15)) qsum ++;
				else if(check_budget_red(i, 8, 0.30)) psum++;
				sum++;
			
			///////////////////////////////////////////////////////////////////////////////
			//check if any tail latency SLO violated; 2020.2.23;
			int k=0, signal = 0, worst_sig = 0;
			for(k=0;k<MAX_PER;k++) {
				//signal += app_ptail_arr[i][k];
				//the mode of tail latency guarantee; 2020.2.24;
				if(tail_guarantee_mode == GLB_LOC_SEN)
				{
					signal += app_ptail_arr[i][k];
					//worst signal for 100% percentile guarantee; 2020.2.25;
					worst_sig += app_latvio_tot[i][k] + app_latvio_arr[i][k];
				}
				else if(tail_guarantee_mode == GLB_NON_SEN)
				{
					signal += app_ptail_glb[i][k];
					//worst signal for 100% percentile guarantee; 2020.2.25;
					worst_sig += app_latvio_tot[i][k];
				}
				else if(tail_guarantee_mode == NON_LOC_SEN)
				{
					signal += app_ptail_loc[i][k];
					//worst signal for 100% percentile guarantee; 2020.2.25;
					worst_sig += app_latvio_arr[i][k];
				}
				
				//worst signal for 100% percentile guarantee; 2020.2.25;
				//worst_sig += app_latvio_arr[i][k];
			}
			///////////////////////////////////////////////////////////////////////////////

			//Decision flag; 2020.2.25
			int decision_f = 0;
			//Only from tail latency measure;
			if(tail_trigger_mode == MEASURE_SIG)  decision_f = (signal > 0);
			//Only from tail latency prediction;
			if(tail_trigger_mode == PREDICTION_SIG)  decision_f = (app_mean_arr[i] > correction_arr[i] * app_meanslo_arr[i]);
			//From the combination of tail latency prediction & measure;
			if(tail_trigger_mode == PRED_MEA_SIG)  decision_f = (app_mean_arr[i] > correction_arr[i] * app_meanslo_arr[i] || signal > 0);
			//From 100% percentile guarantee;
			if(tail_trigger_mode == WORST_SIG)  decision_f = (worst_sig > 0);
			
			//if(decision_f)   //before 2020.8.17;
			if(decision_f/* || signal > 0*/)   //before 2020.8.17;
		    // if(app_mean_arr[i] > 0.95 * app_meanslo_arr[i] 
			 //||  signal > 0)  //check if any tail latency SLO violated; 2020.2.23;
				 rn++;
			
			//2020.8.20 MP tail latency SLO enforcement status, violate or not?;
			if(signal > 0){
				vn++;
			}

				//get the number of scheduled priviliged users;
				if(flow_id_arr[i].req_quota > 0) spu_n++;
			}
		}
	}

	if(sum > 0){
		double q_r = ((double)qsum * 100)/(double)sum;
		double p_r = ((double)psum * 100)/(double)sum;

		pu_n = sum;
		sched_pu_n = spu_n;
		
		//I/O congestion;
		if(rn>0){
			i_ret = 1;
		}
		//over-provisioning state;
		else if(rn<=0)
			i_ret = 2;

		//state of IO stack for tail latency enforcement;; 1/22/2020;
		last_sys_state = sys_state;
		sys_state = i_ret;

		//2020.8.20;
		if(tail_trigger_mode == PREDICTION_SIG){
			if(last_sys_state==0 && sys_state==1)
				i_ret = 1;
			else if(last_sys_state==0 && sys_state==2)
				i_ret = 2;
			//from IO congestion to overprovisioning, it requires a clear bill of violations; 2020.8.20; 
			else if(last_sys_state==1 && sys_state==2){
				if(vn > 0){
					if(!guarantee_smooth){
						sys_state = 1;
						i_ret = 1;
					}
					else
					   i_ret = 2;
				}
				else
					i_ret = 2;
			}
			else if(last_sys_state==2 && sys_state==1)
				i_ret = 1;
			else if(last_sys_state==sys_state)
				i_ret = sys_state;
		}
	}

	return i_ret;
}

//adjust the resource allocation to unpriviliged users according to I/O state; (2020.1.22)
int adjust_unpriviliged_users(int guarantee)
{
	int i_ret = 0, i=0;

	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM)
		return i_ret;

	//2020.7.17 if you don't need to guarantee tail latency SLOs, just return;
	if(!guarantee) return i_ret;
	
	i_ret = detect_iostate();

	if(!i_ret) 
		return i_ret;

	for(i=1;i<fd_id_ptr;i++){
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){

			if(! is_user_priviliged(i)){
				if(i_ret==1){
					//flow_id_arr[i].times_delay = 1 * max_iodelay_ratio;
					//BE user I/O regulation 2020.8.13;
					//2020.8.20;
				if(tail_trigger_mode == PREDICTION_SIG){
					flow_id_arr[i].times_delay = BR();
					//flow_id_arr[i].times_delay = 1;
				}else{
					flow_id_arr[i].times_delay = max_iodelay_ratio;
				}
					req_token[i] = 1;
					//req_token[i] = DATA_SET; //TEST 2020.8.21;
					////////////////////////////////////////////////////////////////////
					/*if(i<12)
					{
						char str_line[32];
						sprintf(str_line, "DEBUG [%4d] \n", i);
						fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
						fflush(wstream_mem[0]);
					}*/
					////////////////////////////////////////////////////////////////////
				}
				else if(i_ret==2){
					flow_id_arr[i].times_delay = 1;
					req_token[i] = DATA_SET;
				}
			}
		}
	}

	return i_ret;
}

//translate latency slos into throughput slos; 
//gamma is the default value of STD/mean;
void translate_lat_slo(double g)
{
	int i,j;

	if(fd_id_ptr<=0 || fd_id_ptr>=MAX_FD_NUM)
		return ;

	//the smallest mean slo reuqired for the priviliged users' tail latency SLOs; 2020.6.5;
	double smallest_mean_slo = 99999999.9;

	//Running status 1: high load (HL); 0: low load (LL); //2020.8.12;
    set_tail_slo_clear();

	//LS user's total throughput budget; 2020.8.13;
	LS_xput_bg = 0.0;
	
	for(i=1;i<fd_id_ptr;i++){
		if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2){
			app_meanslo_arr[i] = 999999;
			for(j=0; j<MAX_PER; j++){
				if(app_latslo_arr[i][j]>0.1){
					//calculate gamma for a specific queue;
					double ga = gamma_val(i);
					///////////////////////////////////
					 //2020.8.18 for time stamps;
					/* if(print_class<=3)
					  {
							if(ga > 2.9){
								char str_line[32];
								sprintf(str_line, "ga = %8.2f \n", ga);
								fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
								fflush(wstream_mem[0]);
							}
					  }*/
						///////////////////////////////////
					//if(ga <0.1 || ga > 2.9) ga = g;
					if(ga < 0.1) ga = 0.1;
					double xpt = 0.02;
					//if(ga <= 2.9){
					if(1){
						xpt = get_bg(app_latslo_arr[i][j], ((double)percentiles[j])/1000.0, ga);
					}
					if(xpt>0.1 && xpt <app_meanslo_arr[i]){
						app_meanslo_arr[i] = xpt;
					}
				}
			}
			if(app_meanslo_arr[i] > 999900){
				app_meanslo_arr[i] = 0.0;
				//app_thptslo_arr[i] = 0.0;
			}
			else{
				if(app_meanslo_arr[i] > 0.01)
				{
					app_thptslo_arr[i] = 1000/app_meanslo_arr[i];
					//LS user's total throughput budget; 2020.8.13;
					LS_xput_bg += app_thptslo_arr[i];

					//the smallest mean slo reuqired for the priviliged users' tail latency SLOs; 2020.6.5;
						if(app_meanslo_arr[i] < smallest_mean_slo)
							smallest_mean_slo = app_meanslo_arr[i];

					//the mean goal for each queue (total); 2020.6.6;
					 tot_meanslo_arr[i] += app_meanslo_arr[i];
					 times_meanslo_arr[i] += 1.0;
					 sta_meanslo_arr[i] =  tot_meanslo_arr[i]/times_meanslo_arr[i];


					//Enable guarantee functionality for tail latency slos; 2020.1.5;
					//...to be continued;
					if(tail_lat_guarantee) //if tail latency guarantee mode 1: enable; 
					{
						 int k=0, signal = 0, worst_sig = 0;
						for(k=0;k<MAX_PER;k++) {
							//signal += app_ptail_arr[i][k];
							//the mode of tail latency guarantee; 2020.2.24;
							if(tail_guarantee_mode == GLB_LOC_SEN)
							{
								signal += app_ptail_arr[i][k];
								//worst signal for 100% percentile guarantee; 2020.2.25;
								worst_sig += app_latvio_tot[i][k] + app_latvio_arr[i][k];
							}
							else if(tail_guarantee_mode == GLB_NON_SEN)
							{
								signal += app_ptail_glb[i][k];
								//worst signal for 100% percentile guarantee; 2020.2.25;
								worst_sig += app_latvio_tot[i][k];
							}
							else if(tail_guarantee_mode == NON_LOC_SEN)
							{
								signal += app_ptail_loc[i][k];
								//worst signal for 100% percentile guarantee; 2020.2.25;
								worst_sig += app_latvio_arr[i][k];
							}

							//worst signal for 100% percentile guarantee; 2020.2.25;
							//worst_sig += app_latvio_arr[i][k];
						}
						
						//Decision flag; 2020.2.25
						int decision_f = 0;
						//Only from tail latency measure;
						if(tail_trigger_mode == MEASURE_SIG)  decision_f = (signal > 0);
						//Only from tail latency prediction;
						if(tail_trigger_mode == PREDICTION_SIG)  decision_f = (app_mean_arr[i] > correction_arr[i] * app_meanslo_arr[i]);
						//From the combination of tail latency prediction & measure;
						if(tail_trigger_mode == PRED_MEA_SIG)  decision_f = (app_mean_arr[i] > correction_arr[i] * app_meanslo_arr[i] && signal > 0);
						//From 100% percentile guarantee;
						if(tail_trigger_mode == WORST_SIG)  decision_f = (worst_sig > 0);

						//Actual tail latency SLO enforcement feedback based adjustment; 2020.8.13;
						/*	if(signal > 0){
								if(correction_arr[i] >= 0.51)  
									correction_arr[i] -= 0.01;
							}else{
								if(correction_arr[i] <= 1.495)  
									correction_arr[i] += 0.005;
							}*/
						/////////////////////////////////////////////////////////////////////////////////////////////////////////

						//Running status 1: high load (HL); 0: low load (LL); //2020.8.12;
                        set_tail_slo_status(decision_f);
						
						//Static settings are always applied to the scheduling //2020.8.21;
						 if(static_pri_set) decision_f = 1;
						
						if(decision_f)
						//if(app_mean_arr[i] > 0.95 * app_meanslo_arr[i] && signal > 0)
						//if(app_mean_arr[i] > 0.95 * app_meanslo_arr[i] || signal > 0) //2020.2.24 considering three factors: prediction, local time window, long-term;
						{
							 //set_scheduling_mode(FAIRNESS); //disable 1/23/2020;
							 if(!static_pri_set){
								 double dt  =  (double)req_token[i] * ((1.1 * app_mean_arr[i])/app_meanslo_arr[i] + 1); 

								//the smallest mean slo reuqired for the priviliged users' tail latency SLOs; 2020.6.5;
								double dd = dt; 
								if(least_mean_slo > 0.00001){	
									//dd = (double)DATA_SET * (double)max_provision_ratio * (least_mean_slo/app_meanslo_arr[i]);
									double ud = 99999999.99;
									int uu=0;
									for(uu=0;uu<fd_id_ptr;uu++){
										if(is_user_priviliged(uu)){
												if(sta_meanslo_arr[uu] >0.00001 && sta_meanslo_arr[uu]<ud)
													ud = sta_meanslo_arr[uu];
										}
									}
									if(ud > 99999999.0) ud = sta_meanslo_arr[i];
									dd = (double)DATA_SET * (double)max_provision_ratio * (ud/sta_meanslo_arr[i]);
									if(dd >  (double)DATA_SET * (double)max_provision_ratio)
										dd = (double)DATA_SET * (double)max_provision_ratio;
									//else if(dd < (double)DATA_SET)
									//	dd = (double)DATA_SET;
									else if(dd < (double)DATA_SET * (ud/sta_meanslo_arr[i])) {//2020.6.7;
										dd = (double)DATA_SET * (ud/sta_meanslo_arr[i]);
										if(dd<2.0) dd = 2.0;
									}
								}else{
									dd = (double)DATA_SET * (double)max_provision_ratio;
								}
								
								if(quota_arr[i]<1.0){ //if dynamic mechanism is disabled, go through the static processing; 2020.8.14;
									 if(dt > (double)DATA_SET * max_provision_ratio)
										 //req_token[i] = DATA_SET * max_provision_ratio;
										 req_token[i] = (int)dd;
									 else
										 req_token[i] = (int)dt;
								}else{
									//dynamic mechanism; 2020.8.14;
									if(tail_trigger_mode == WORST_SIG || tail_trigger_mode == MEASURE_SIG)
										req_token[i] = DATA_SET * max_provision_ratio; //2020.4.17; Static priority setting;
									else
										req_token[i] = (int)quota_arr[i];
								}
							 }else{
								req_token[i] = DATA_SET * max_provision_ratio; //2020.4.17; Static priority setting;
							 }
						}
						else{
							double ud = 99999999.99;
							int uu=0;
							for(uu=0;uu<fd_id_ptr;uu++){
								if(is_user_priviliged(uu)){
										if(sta_meanslo_arr[uu] >0.00001 && sta_meanslo_arr[uu]<ud)
											ud = sta_meanslo_arr[uu];
								}
							}
							if(ud > 99999999.0) ud = sta_meanslo_arr[i];
							 double req_t =  (double)DATA_SET * (ud/sta_meanslo_arr[i]);
							 int req_tn = req_t;
							 if(req_tn<2) req_tn = 2;
							 if(req_tn>DATA_SET) req_tn = DATA_SET;
							//if((signal<=0 && req_token[i] > DATA_SET) || (tail_trigger_mode == WORST_SIG && data_rec_f==1)){
							//if((signal<=0 && req_token[i] > req_tn) || (tail_trigger_mode == WORST_SIG && data_rec_f==1)){ //2020.6.7
							if((/*signal<=0 &&*/ req_token[i] > req_tn) || (tail_trigger_mode == WORST_SIG && data_rec_f==1)){ //2020.8.13
								 //recording latencies for users;
								 if(record_reqs<=0) record_reqs = 1;
								 //tell if all the tail latency violation signals are clear; (2020.1.7)
								if (lat_vio_clear() > 0)
									set_scheduling_mode(EFFICIENT);
								if(sched_mode == EFFICIENT && !static_pri_set)
									req_token[i]--; 
							 }
						}
					}
					else{ if(record_reqs<=0) record_reqs = 1; }
				}
			}
		}
	}

	//Running status 1: high load (HL); 0: low load (LL); //2020.8.12;
    set_tail_slo_conclude();

	//the smallest mean slo reuqired for the priviliged users' tail latency SLOs; 2020.6.5;
	least_mean_slo = smallest_mean_slo;
	/*least_mean_tot += smallest_mean_slo;
	least_mean_num += 1.0;
	least_mean_slo = least_mean_tot/least_mean_num;*/

	//add the element to the idx queue; (2020.1.22)
    en_cir_queue_a();
	//adjust the resource allocation to unpriviliged users according to I/O state; (2020.1.22)
    adjust_unpriviliged_users(tail_lat_guarantee);
}

//check latency slo viable; (1: viable; 0: failure)
//reserve refers to the ratio of throughput allocated to other users without latency slos;
int check_lat_slo(double max_thpt, double reserve)
{
	int i_ret  = 1;
	int i;
	double total_thpt = 0.0;
	for(i=1;i<MAX_FD_NUM;i++){
		total_thpt += app_thptslo_arr[i];
	}

	if(total_thpt > max_thpt * (1.0 - reserve))
		i_ret = 0;

	return i_ret;
}

//===================================================//
//Proportional resource sharing between LS users and BE users; 2020.4.18;

//1) get the control target derived from average mean lat among LS users; 2020.4.18;
double get_target_ls_mean()
{
	double d_v = 0.0;
	int ls_n = 0;

	int i=0;
	for(i=1;i<=fd_id_ptr;i++){
		if(is_active(fd_id_list[i]) 
	&& flow_id_arr[i].sched_avoid_f == 2 
	&& flow_id_arr[i].is_priviliged > 0){
				d_v +=  app_mean_arr[i];
				ls_n++;
		}
	}

	if(ls_n>0){
		d_v /= (double)ls_n;
	}

	d_v *= (double)max_provision_ratio;
	pri_target = d_v;
	return d_v;
}

//2) Adaptive control; 2020.4.18;
void adaptive_control_delay(int i)
{
	double target = pri_target;
	if(target<=0.01) return;
		if(is_active(fd_id_list[i]) 
	&& flow_id_arr[i].sched_avoid_f == 2 
	&& flow_id_arr[i].is_priviliged <= 0){
			if(app_mean_arr[i] > 1.1 * target){
				if(app_mean_arr[i] < 1.2  * target){
					if( flow_id_arr[i].wt_ratio >=1)
						flow_id_arr[i].wt_ratio -= 1;
				}else{
					if(flow_id_arr[i].wt_ratio >=2)
						flow_id_arr[i].wt_ratio /= 2;
				}
			}else if(app_mean_arr[i] < 0.9 * target){
				if(app_mean_arr[i] > 0.8  * target){
					if( flow_id_arr[i].wt_ratio <=499)
						flow_id_arr[i].wt_ratio += 1;
				}else{
					if(flow_id_arr[i].wt_ratio <=100){
						if(flow_id_arr[i].wt_ratio==0)
							flow_id_arr[i].wt_ratio = 1;
						flow_id_arr[i].wt_ratio *= 2;
					}
				}
			}
		}
}

//===================================================//

/**************************************************************/
//Parameter y0;
double yy0 = 0.0;

//Parameter A;
double A = 0.0;

//Parameter gamma;
double gammag = 0.0;

//initialization;
void set(double thpt0, int p0)
{
	app_thpt0 = thpt0;
	app_p0 = p0;
}

//calculate theta;
double thpt_theta(double thptx)
{
	double d_ret = 0.0;
	if(app_thpt0 > 0.5)
	{
		d_ret = (thptx - app_thpt0)/app_thpt0;
	}
	return d_ret;
}

//calculate alpha;
double alpha_cal(int p1, double thptx)
{
	double d_ret = 0.0;
	if(p1<=1 || app_p0<=0)
		return d_ret;

	double theta = thpt_theta(thptx);
	d_ret = (((double)app_p0-1) * (double)p1 + (double)app_p0 *(double)p1*theta)/((double)app_p0 * ((double)p1-1)*(theta+1));

	return d_ret;
}

//calculate throughput from alpha;
double throughput_cal(int p1, double alpha)
{
	double d_ret = 0.0;
	double theta =  0.0;

	 theta  = (((double)app_p0 - 1) * (double)p1 -  alpha * (double)app_p0 * ((double)p1-1))/((alpha * (double)app_p0 * ((double)p1-1) - (double)app_p0 * (double)p1));
	 d_ret = theta * (double)app_thpt0;

	 return d_ret;
}

//calculate the extreme value of alpha;
double alpha_limit_hat(double thptx)
{
	double d_ret = 0.0;
	
	if(app_p0<=0)
		return d_ret;

	double theta = thpt_theta(thptx);

	d_ret = 1 - (1/((double)app_p0 * (theta + 1)));
	yy0 = d_ret;
	A = 1 - yy0;

	return d_ret;
}

//calculate gamma from alpha;
double gamma_cal(int p1, double thptx)
{
	double d_ret = 0.0;

	if(A==0) return d_ret;

	double alpha = alpha_cal(p1, thptx);
	//y = y0 + A * e^(gamma * P);
	d_ret = log((alpha - yy0)/A)/(double)p1;

	gammag = d_ret;

	return d_ret;
}

//apples functionality;
int apples_cal(int p1, double thptx, double thpti)
{
	if(p1<=1)
		return -1;

	alpha_limit_hat(thpti);
	gamma_cal(p1, thptx);
	
	return 1;
}

//compute alpha from P;
double alpha_p(int p1)
{
	double d_ret = 0.0;
	d_ret = yy0 + A * pow(2.71828, gammag * p1);
	return d_ret;
}

//compute throughput from P;
double thpt_p(int p1)
{
	double d_ret = 0.0;
	double alp = alpha_p(p1);
	d_ret = throughput_cal(p1+1,  alp);
	return d_ret;
}

//control knob P decided by throughput;
int cal_p_from_thpt(double thptx)
{
	int i_ret = 4;
	double last_thpt = 0;
	double curr_thpt = 1;

	//2020.7.17 plot the P-throughput curve;
	char str_linex[128];
	sprintf(str_linex, ">>>> Plot P-throughput curve <<<<\n");
	fwrite(str_linex,1,strlen(str_linex),wstream_mem[0]);
	fflush(wstream_mem[0]);
	for(i_ret=1;i_ret<1024;i_ret++){
		sprintf(str_linex, "%8.3f\n", thpt_p(i_ret));
		fwrite(str_linex,1,strlen(str_linex),wstream_mem[0]);
		fflush(wstream_mem[0]);
	}
	sprintf(str_linex, ">>>> End P-throughput curve <<<<\n");
	fwrite(str_linex,1,strlen(str_linex),wstream_mem[0]);
	fflush(wstream_mem[0]);
	///////////////////////////////////////////////////////

	for(i_ret=4; i_ret<1024 && curr_thpt>last_thpt; i_ret++)
	{
		last_thpt = curr_thpt;
		curr_thpt =  thpt_p(i_ret);

		if(curr_thpt>=thptx)
			break;
	}

	i_ret -= 2;

	//Considering the dedicated scheduling channels for previliged users; 2020.3.23;
	int pu = get_user_priviliged(); 
	i_ret += pu;

	if(i_ret > (fd_id_ptr-2)/2)
		i_ret = (fd_id_ptr-2)/2;

	return i_ret;
}

/********************************************************************************************************************************/
//initialization;
void set1(double thpt0, int p0)
{
	app_thpt0 = thpt0;
	app_p0 = p0;
}

//calculate gamma from alpha;
double gamma_cal1(int p1, double thptx, double thpti)
{
	double d_ret = 0.0;

	gammag = (1/(double)p1) * (log((double)p1-1.0) - log((double)p1-1.0 + (double)app_p0 * thpti/app_thpt0 - (double)p1 * thpti/thptx));

	d_ret = gammag;

	return d_ret;
}

double A_cal1(double thpti)
{
	return 1.0 - 1.0/((double)app_p0 * thpti/app_thpt0);
}

double B_cal1(double thpti)
{
	return 1.0/((double)app_p0 * thpti/app_thpt0);
}

//compute throughput from P;
double thpt_p1(int p1, double thpti)
{
	double d_ret = 0.0;
	d_ret = ((double)p1 * app_thpt0)/((double)app_p0 + ((double)p1 - 1) * ((1.0 - pow(2.71828, -gammag * (double)p1))/(thpti/app_thpt0)));
	return d_ret;
}

//Tell if the throughput is valid for derivation; 2020.8.23;
int xput_valid()
{
	double dv1 = 0, dv2 = 0;
	int i_ret = 0;
	if(app_thptx/app_thpti > 0.8 && app_thptx/app_thpti < 0.9)
		app_thptx *= 1.1;
	dv1 = (double)app_p0 * app_thpti /app_thpt0;
	dv2 = (double)app_px * app_thpti /app_thptx;
	if((double)app_px-1.0 + dv1 - dv2 >  0.000001){
		i_ret = 1;
	}else{
		if(fd_id_ptr - 1 - thread_con < 4)
			i_ret = -1;
	}
	return i_ret;
}

//control knob P decided by throughput;
int cal_p_from_thpt1(double thptx, double thpti)
{
	int i_ret = 4;
	double last_thpt = 0;
	double curr_thpt = 1;

	//2020.7.17 plot the P-throughput curve;
	/*char str_linex[128];
	sprintf(str_linex, ">>>> Plot P-throughput curve <<<<\n");
	fwrite(str_linex,1,strlen(str_linex),wstream_mem[0]);
	fflush(wstream_mem[0]);
	for(i_ret=1;i_ret<fd_id_ptr;i_ret++){
		sprintf(str_linex, "%8.3f\n", thpt_p1(i_ret, thpti));
		fwrite(str_linex,1,strlen(str_linex),wstream_mem[0]);
		fflush(wstream_mem[0]);
	}
	sprintf(str_linex, ">>>> End P-throughput curve <<<<\n");
	fwrite(str_linex,1,strlen(str_linex),wstream_mem[0]);
	fflush(wstream_mem[0]);*/
	///////////////////////////////////////////////////////

	for(i_ret=4; i_ret<fd_id_ptr && curr_thpt>last_thpt; i_ret++)
	{
		last_thpt = curr_thpt;
		curr_thpt =  thpt_p1(i_ret, thpti);

		if(curr_thpt>=thptx)
			break;
	}

	i_ret -= 1;

	//Considering the dedicated scheduling channels for previliged users; 2020.3.23;
	//int pu = get_user_priviliged(); 
	//i_ret += pu;

	/*if(i_ret > (fd_id_ptr-2)/2)
		i_ret = (fd_id_ptr-2)/2;*/

	return i_ret;
}


/********************************************************************************************************************************/
//Newton calculation;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Tell if the gamma is valid;
int tell_valid_gamma(double gamma){
	int i_ret = 1;
	double f, g;

	f=(pow(EV, -gamma*P0)-pow(EV,-gamma*P1))*(P1-1);
	g=(pow(EV, -gamma*P0)-pow(EV,-gamma*P2))*(P2-1);

	if(f-g < 0.00000001 && f-g > -0.00000001)
		i_ret = 0;

	return i_ret;
}

//calculate B value in Eq. (5)
double B_value(double gamma)
{
	  double f0, f1, f2,f3;

	  f1=P1*lambda0/lambda1-P2*lambda0/lambda2;
	  f2=(pow(EV, -gamma*P0)-pow(EV,-gamma*P1))*(P1-1);
	  f3=(pow(EV, -gamma*P0)-pow(EV,-gamma*P2))*(P2-1);

	   f0=f1/P0/(f2-f3);
	   
	   return f0;
}

//derivative funtion of B_value
double par_B(double gamma)
{
	  double f1,f2;
	  double xx,yy,zz;

	  f1=(pow(EV,-gamma*P0)-pow(EV,-gamma*P1))*(P1-1)-(pow(EV,-gamma*P0)-pow(EV,-gamma*P2))*(P2-1);
	  f1=f1*P0;
	  xx=(P2*lambda0/lambda2-P1*lambda0/lambda1)*P0;
	  yy=(P1*pow(EV,-gamma*P1)-P0*pow(EV,-gamma*P0))*(P1-1);
	  zz=(P2*pow(EV,-gamma*P2)-P0*pow(EV,-gamma*P0))*(P2-1);
	  f2=xx*(yy-zz)/f1/f1;

	  return f2;
}

//modified function from Eq. (5), defined as 
//f(gamma)=P0+B*P0*(e^(-gamma*P0)-e^(-gamma*P)*(P-1)-P*lmabda(P0)/lmabda(P1)
double fgamma(double gamma){
	  double xx;
	 
	  xx=P0+B_value(gamma)*P0*(pow(EV,-gamma*P0)-pow(EV,-gamma*P1))*(P1-1)-P1*lambda0/lambda1; 

	  return xx;
}

//derivative of function fgamma
double par_fgamma(double gamma)
{
	  double xx, yy, zz;

	  xx=B_value(gamma)*P0*(P1*pow(EV,-gamma*P1)-P0*pow(EV,-gamma*P0))*(P1-1);
	  yy=P0*(pow(EV,-gamma*P0)-pow(EV,-gamma*P1))*(P1-1)*par_B(gamma);
	  zz=xx+yy;

	  return zz;
}

//throughput function, i.e., lambda(P) defined in Eq. (5)
double tput(double gamma, double P)
{ double x;

  x=P*lambda0/(P0+B_value(gamma)*P0*(pow(EV,-gamma*P0)-pow(EV,-gamma*P))*(P-1));

  return x;
}

int newton()
{
	int i,j,k;
    double  gamma;
    double x,y,z;
	double last_thpt = 0.0;
	double curr_thpt = 1.0;
	int i_ret = 4;

     //set initial value x
     x=0.01;
     i=0;

     while(1){i++;
	 		 //Tell if the gamma is valid;
			if(!tell_valid_gamma(x)){
				return 0;
			}

			y=fgamma(x);
			if(fabs(y)<epslan) { break; }
		   
			x=x-fgamma(x)/par_fgamma(x);
      }

	// printf("\ngamma: %8.3f", x);
	
      for(y=1;y<1025 && curr_thpt>last_thpt;y++){
		  last_thpt = curr_thpt;
		   curr_thpt = tput(x,y);
		   //printf("\nP: %4.0f  throughput:  %8.3f", y, curr_thpt);
      }

	  i_ret = y - 2.0;

	  return i_ret;
}
/********************************************************************************************************************************/
#endif