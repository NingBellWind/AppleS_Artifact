gcc sys_xpslo_mon.c -lsyscall_intercept -fpic -shared -o sys_xpslo_mon.so
#gcc -o predic_disk_q predic_disk_q.c
#gcc -o vmmon vmmon.c

