#ifndef OPTALGO_H
#define OPTALGO_H

#include <unistd.h>
#include <math.h>
#include <sys/time.h>
#include <time.h>
#include "common.h"
#include "rec.h"
#include "tail.h"

//The Algorithms used to optimize I/O throughput or I/O latency for threads;
//Input: I/O throughput (KB/s) and block-level I/O latency (ms) averaged over the lastest second;
//Output: (Concurrency: thread_con; Efficiency: DATA_SET; Throttling level: throttling_level)
//Comment: Every group of settings is required to accespt a 10-times check. Each time will last
////////////////  a ALS-standard time (0.5 s by default). 
//Logic 1   : For the hard-throttling mode, check the sensitivity of efficiency and concurrency. The
//////////////// basic way to implement this idea is to measure the average throughput and latency under
//////////////// each group of settings. The range of  Concurrency is [1, sch_thread_num/2] and the range of 
//////////////// Efficiency is [1, 100]. Thus, the exploration space is  sch_thread_num/2 * 100. It is infeasible
//////////////// to test so many groups.  So we decouple these two parameters. Set Concurrency at 1 and set
//////////////// Efficiency at 1 and 1000 respectively. In this way, we check the sensitivity of Efficiency to 
//////////////// I/O performance. And I/O throughput is the first factor we will consider in the optimization.
////////////////  If the ratio of Throughput_100 and Throughput_1 is less than 1.2, we then think that Efficiency
////////////////  is insensitive to I/O performance and set it at 1for good fairness, otherwise we set it at 100.
////////////////  And then we optimize Concurrency by a binary-search algorithm.  
//Logic 2   : For the soft-throttling mode, check the sensitivity of efficiency, concurrency and throttling level.
//////////////// First, we investigate the sensitivity of throttling level under the default settings of efficiency and
//////////////// concurrency. Specifically, we increase throttling level by 5 (1ms) until the first thoughput reduction.
//////////////// And then we set throttling_level at last value. We follow the same logic to Logic1 to obtain the 
//////////////// optimized settings for efficiency and concurrency.
//Criteria   : (Most preferable)               Throughput improvment and queue length reduction.             (I/O throughput, average I/O latency and tail latency will be improved)
//////////////// (The 2nd-level preferable) Throughput improvment and queue length almost the same.  (I/O throughput and average I/O latency will be improved)
//////////////// (The 3nd-level preferable) Throughput almost the same and queue length reduction.      (Tail I/O latency will be improved)

int c_op_finished = 0;
int e_op_finished = 0;
int t_op_finished = 0;

//Original bandwidth; 2019.3.4;
float ori_bw = 0;
float ori_ratio_bw = 1.1;
//Original queue length; 2019.8.23;
float ori_ql = 0;
float ori_ss = 0;

int algo_op_class(float ratio_bw, float ratio_dd)
{
	int e_op_class = 0;

	if(ratio_bw > 1.03 && ratio_dd < 0.9)
	//if(ratio_bw > 1.05 && ratio_dd < 0.9)
	{
		e_op_class = 1;
	}
	else if((ratio_bw > 1.02 && ratio_dd < 60) 
		      || (ori_bw>1 && ori_ratio_bw < 0.99 && ratio_bw > 0.99)) //Need to surpass the original bandwidth;
	//else if(ratio_bw > 1.05 && ratio_dd < 1.2)
	{
		e_op_class = 2;
	}
	else if(ratio_bw > 0.90 && ratio_dd < 0.3)
	{
		e_op_class = 3;
	}

	return e_op_class;
}

int last_DATA_SET = 0;
float last_e_bw = 0;
float last_e_dd = 0;
int e_fir = 1;
//Improve efficiency optimization, 2019.4.1
int e_runs = 0;
int e_step = 1;

int efficiency_optimization(float bw, float dd)
{
	int i_ret = 1;
	float ratio_bw = 0;
	float ratio_dd = 0;

	struct timeval e;
	sc_gettime(&e);

	char str_line[256];
	int i=0;

	if(e_fir)
	{
			//Original bandwidth; 2019.3.4;
			if(ori_bw>1)
			{
				ori_ratio_bw = bw/ori_bw;
			}

			last_e_bw = bw;
			last_e_dd = dd;
			last_DATA_SET = DATA_SET;
			//The initial value of DATA_SET; 2019.4.1;
			DATA_SET = 4;
			//e_step = 4;
			e_step = 16;
				
			for(i=1;i<=fd_id_ptr;i++)
			{
				//Initialize req_token[i];
				req_token[i] = DATA_SET;
			}
			//Original bandwidth; 2019.3.4;
			ori_bw = bw;
			sprintf(str_line, "Efficiency_optimization start! (%08d, %08d) <SET   BW: %8.2f  DD: %4.2f> [DATA_SET = %04d  thread_con = %04d  max_apples_delay = %04d  ORI_BW = %8.2f]\n"
									,  e.tv_sec, e.tv_usec,  bw, dd, DATA_SET, thread_con, max_apples_delay, ori_bw);
			mem_log(str_line, 3);
			e_fir = 0;
	}
	else
	{
			//Original bandwidth; 2019.3.4;
			if(ori_bw>1)
			{
				ori_ratio_bw = bw/ori_bw;
			}

			if(last_e_bw>1)
			{
				ratio_bw = bw/last_e_bw;
				last_e_bw = bw;
			}

			if(last_e_dd>0.1)
			{
				ratio_dd = dd/last_e_dd;
				last_e_dd = dd;
			}

			int op_class = algo_op_class(ratio_bw, ratio_dd);

			if(DATA_SET+e_step > 100 ||  (op_class<=0 && e_runs>=0))
			{
				    e_op_finished = 1;
					if(op_class<=0)
						DATA_SET = last_DATA_SET;

					for(i=1;i<=fd_id_ptr;i++)
					{
						//Setup req_token[i];
						req_token[i] = DATA_SET;

						if(req_token[i] < 1)
							req_token[i] = 1;
					}

					sprintf(str_line, "Efficiency_optimization finished! (%08d, %08d) <LEVEL: %3d, BW: %8.2f  OBW: %8.2f  DD: %4.2f  RB: %4.2f  RD: %4.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
									,  e.tv_sec, e.tv_usec, op_class, bw, dd, ratio_bw, ori_ratio_bw, ratio_dd, DATA_SET, thread_con, max_apples_delay);
					mem_log(str_line, 3);
					return 2;
			}

			e_runs++;
			
			last_DATA_SET = DATA_SET;

			DATA_SET += e_step;

		sprintf(str_line, "Efficiency_optimization (%08d, %08d) <LEVEL: %3d,  BW: %8.2f  OBW(%8.2f/%8.2f): %8.2f  DD: %4.2f  RB: %4.2f  RD: %4.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
								,  e.tv_sec, e.tv_usec, op_class, bw, bw, ori_bw, ori_ratio_bw,  dd,  ratio_bw, ratio_dd, DATA_SET, thread_con, max_apples_delay);
		mem_log(str_line, 3);
	}

	return i_ret;
}


int c_start = 1;
int c_end = 0;
float last_c_bw = 0;
float last_c_dd = 0;
int last_thread_con = 0;
int c_dir = -1;
int c_runs = 0;
int c_step = 1;


int concurrency_optimization(float bw, float dd, int mode)
{
	int i_ret = 1;
	float ratio_bw = 0;
	float ratio_dd = 0;

	struct timeval e;
	sc_gettime(&e);

	char str_line[256];

	//Concurrency must be tested under DATA_SET = 1; 2019.4.1;
	DATA_SET = 1;

	if(c_fir)
	{
		last_c_bw = bw;
		last_c_dd = dd;
		c_end = sch_thread_num/2;
		last_thread_con = thread_con;
		//c_step = sch_thread_num/32;
		c_step = sch_thread_num/64;

		if(c_step < 2)
			c_step = 2;

		if(mode)
			thread_con = (c_start + c_end)/2;
		else
			thread_con = c_step;
		c_fir = 0;
		sprintf(str_line, "Concurrency_optimization(Mode:%d) start! (%08d, %08d) <SET  S: %4d, E: %4d   BW: %8.2f  OBW: %8.2f  DD: %4.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
								,  mode, e.tv_sec, e.tv_usec,  c_start, c_end,  bw, ori_bw, dd, DATA_SET, thread_con, max_apples_delay);
		mem_log(str_line, 3);
	}
	else
	{
		if(last_c_bw > 1)
			ratio_bw = bw/last_c_bw;
		if(last_c_dd > 0.1)
			ratio_dd = dd/last_c_dd;

		last_c_bw = bw;
		last_c_dd = dd;

		//Original bandwidth; 2019.3.4;
		if(ori_bw>1)
		{
			ori_ratio_bw = bw/ori_bw;
		}

		//2019.4.1 max_apples_delay reference;
		if(max_apples_delay_ref > REST_TIME)
			 max_apples_delay = (2 * max_apples_delay_ref) / REST_TIME;

		int op_class = algo_op_class(ratio_bw, ratio_dd);
		
		if(mode)
		{
			if(thread_con - last_thread_con>1)
				c_dir = 1;
			else if(thread_con - last_thread_con<-1)
				c_dir = 0;
			else
			{
					c_op_finished = 1;
					sprintf(str_line, "Concurrency_optimization(Mode:%d) finished! (%08d, %08d) <LEVEL: %3d, S: %4d, E: %4d   BW: %8.2f  OBW: %8.2f  DD: %4.2f  RB: %4.2f  RD: %4.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
									,  mode, e.tv_sec, e.tv_usec, op_class, c_start, c_end,  bw, dd, ratio_bw, ori_ratio_bw, ratio_dd, DATA_SET, thread_con, max_apples_delay);
					mem_log(str_line, 3);
					return 2;
			}
		}
		else
		{
			if(thread_con+c_step > sch_thread_num/2 ||  (op_class<=0 && c_runs>2))
			{
				    c_op_finished = 1;
					if(op_class<=0)
						thread_con = last_thread_con;
					sprintf(str_line, "Concurrency_optimization(Mode:%d) finished! (%08d, %08d) <LEVEL: %3d, S: %4d, E: %4d   BW: %8.2f  OBW: %8.2f  DD: %4.2f  RB: %4.2f  RD: %4.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
									,  mode, e.tv_sec, e.tv_usec, op_class, c_start, c_end,  bw, dd, ratio_bw, ori_ratio_bw, ratio_dd, DATA_SET, thread_con, max_apples_delay);
					mem_log(str_line, 3);
					return 2;
			}
		}

		c_runs++;
		
		//Go for the opposite  dirction;
		if(op_class<=0)
		{
			//Become smaller;
			if(c_dir==1)
				c_end = thread_con;
			//Become bigger;
			else if(c_dir==0)
				c_start = thread_con;
		}
		//Go for the same  dirction;
		else
		{
			//Become bigger;
			if(c_dir==1)
				c_start = thread_con;
			//Become smaller;
			else if(c_dir==0)
				c_end = thread_con;
		}

		last_thread_con = thread_con;

		if(mode)
			thread_con = (c_start + c_end)/2;
		else
			thread_con += c_step;

		sprintf(str_line, "Concurrency_optimization(Mode:%d) (%08d, %08d) <LEVEL: %3d, S: %4d, E: %4d    BW: %8.2f  OBW(%8.2f/%8.2f): %8.2f  DD: %4.2f  RB: %4.2f  RD: %4.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
								,  mode, e.tv_sec, e.tv_usec, op_class, c_start, c_end,  bw, bw, ori_bw, ori_ratio_bw,  dd,  ratio_bw, ratio_dd, DATA_SET, thread_con, max_apples_delay);
		mem_log(str_line, 3);
	}

	return i_ret;
}


int t_start = 1;
int t_end = 100;
float last_t_bw = 0;
float last_t_dd = 0;
int t_fir = 1;
int last_throttling_level =  0;
int t_dir = -1;
int t_runs = 0;
int t_step = 1;

int throttling_level_optimization(float bw, float dd, int mode)
{
	int i_ret = 1;
	float ratio_bw = 0;
	float ratio_dd = 0;

	struct timeval e;
	sc_gettime(&e);

	char str_line[256];

	if(t_fir)
	{
		last_t_bw = bw;
		last_t_dd = dd;
		t_end = 100;
		last_throttling_level =  throttling_level;
		t_step = 10;
		if(mode)
			throttling_level = (t_start + t_end)/2;
		else
			throttling_level = t_step;
		t_fir = 0;
		sprintf(str_line, "Throttling_level_optimization(Mode:%d) start! (%08d, %08d) <SET  BW: %8.2f  DD: %4.2f> [DATA_SET = %4d  thread_con = %4d  throttling_level = %4d]\n"
								,  mode, e.tv_sec, e.tv_usec, bw, dd, DATA_SET, thread_con, throttling_level);
				mem_log(str_line, 3);
	}
	else
	{
		if(last_t_bw > 1)
			ratio_bw = bw/last_t_bw;
		if(last_t_dd > 0.1)
			ratio_dd = dd/last_t_dd;

		last_t_bw = bw;
		last_t_dd = dd;

		int op_class = algo_op_class(ratio_bw, ratio_dd);
		
		if(mode)
		{
			if(throttling_level - last_throttling_level>1)
				t_dir = 1;
			else if(throttling_level - last_throttling_level<-1)
				t_dir = 0;
			else
			{
					t_op_finished = 1;
					sprintf(str_line, "Throttling_level_optimization(Mode:%d) finished! (%08d, %08d) <LEVEL: %3d, S: %4d, E: %4d   BW: %8.2f  DD: %4.2f> [DATA_SET = %4d  thread_con = %4d  throttling_level = %4d]\n"
									,  mode, e.tv_sec, e.tv_usec, op_class, t_start, t_end,  bw, dd, DATA_SET, thread_con, throttling_level);
					mem_log(str_line, 3);
					return 2;
			}
		}
		else
		{
			if(throttling_level+t_step > 100 || (op_class<=0 && t_runs>1))
			{
				    t_op_finished = 1;
					if(op_class<=0)
						throttling_level = last_throttling_level;
					sprintf(str_line, "Throttling_level_optimization(Mode:%d) finished! (%08d, %08d) <LEVEL: %3d, S: %4d, E: %4d   BW: %8.2f  DD: %4.2f> [DATA_SET = %4d  thread_con = %4d  throttling_level = %4d]\n"
									,  mode, e.tv_sec, e.tv_usec, op_class, t_start, t_end,  bw, dd, DATA_SET, thread_con, throttling_level);
					mem_log(str_line, 3);
					return 2;
			}
		}

		t_runs++;
		
		//Go for the opposite  dirction;
		if(op_class<=0)
		{
			//Become smaller;
			if(t_dir==1)
				t_end = throttling_level;
			//Become bigger;
			else if(t_dir==0)
				t_start = throttling_level;
		}
		//Go for the same  dirction;
		else
		{
			//Become bigger;
			if(t_dir==1)
				t_start = throttling_level;
			//Become smaller;
			else if(t_dir==0)
				t_end = throttling_level;
		}

		last_throttling_level = throttling_level;

		if(mode)
			throttling_level = (t_start + t_end)/2;
		else
			throttling_level += t_step; 

		sprintf(str_line, "Throttling_level_optimization(Mode:%d) (%08d, %08d) <LEVEL: %3d, S: %4d, E: %4d    BW: %8.2f  DD: %4.2f> [DATA_SET = %4d  thread_con = %4d  throttling_level = %4d]\n"
								,  mode, e.tv_sec, e.tv_usec, op_class, t_start, t_end,  bw, dd, DATA_SET, thread_con, throttling_level);
		mem_log(str_line, 3);
	}

	return i_ret;
}

//General logic for optimization;
int opti_algo_logic(float bw, float dd, int mode)
{
	int i_ret = 1;
	//For the soft throttling;
	if(soft_throttling)
	{
		if(!t_op_finished)
			throttling_level_optimization(bw, dd, mode);
		else if(!e_op_finished)
			efficiency_optimization(bw, dd);
		else if(!c_op_finished)
			concurrency_optimization(bw, dd, mode);
	}
	//For the hard throttling;
	else
	{
		 //if(!e_op_finished)
		//	efficiency_optimization(bw, dd);
		//else if(!c_op_finished)
		//	concurrency_optimization(bw, dd, mode);

		 if(!c_op_finished)
			concurrency_optimization(bw, dd, mode);
		else if(!e_op_finished)
			efficiency_optimization(bw, dd);
	}
	return i_ret;
}

//Tell if optimization finished;  //2019.1.3;
int opt_finished()
{
	int i_ret = 0;
	if(soft_throttling)
	{
		if(t_op_finished && e_op_finished && c_op_finished)
			i_ret = 1;
	}
	else
	{
		//if(e_op_finished && c_op_finished)
		if(e_op_finished) //2020.8.24;
			i_ret = 1;
	}
	return i_ret;
}

//Set optimization flag;
void set_opt_flag(int t, int e, int c)
{
	t_op_finished = t;
	e_op_finished = e;
	//c_op_finished = c; //2020.8.24;
}

//P optimization; 2020.3.21;
int concurrency_opt(float bw, float min_bw, float dd, int mode)
{
	int i_ret = 1;
	float ratio_bw = 0;
	float ratio_dd = 0;

	//if(c_fir>=4) return 1;
	if(c_fir>=5) return 1; //2020.8.24;
    
	if(c_fir<4)  //2020.8.24;
		tail_lat_guarantee = 0;

	struct timeval e;
	sc_gettime(&e);

	char str_line[4096];
	memset(str_line, 0, 4096);

	//Concurrency must be tested under DATA_SET = 1; 2019.4.1;
	if(app_type==1){
	   if (app_fver>=8 && app_sver==0 && app_tver>=20){
			DATA_SET = 1;
			DATA_SET_min = 1;
	   }else{
		   DATA_SET = 16;
			DATA_SET_min = 16;
	   }
	}
	else{
		DATA_SET = 4;
		DATA_SET_min = 4;
	}

	if(!c_fir)
	{
		last_c_bw = bw;
		last_c_dd = dd;
		last_thread_con = thread_con;
		c_step = 2;

		if(c_step < 2)
			c_step = 2;

		//thread_con = 2;
		if(app_type==1)
			thread_con = 8;
		else
			thread_con = 8;

		c_fir = 1;
		sprintf(str_line, "P_optimization(Mode:%d) start round <sec: %4d, us: %4d   BW: %8.2f  OBW: %8.2f  DD: %4.2f> [DATA_SET = %4d  set thread_con = %4d  max_apples_delay = %4d]\n"
								,  mode, e.tv_sec, e.tv_usec,  bw, ori_bw, dd, DATA_SET, last_thread_con, max_apples_delay);
		mem_log(str_line, 3);
	}else if(c_fir==1){
		last_c_bw = bw;
		last_c_dd = dd;
		last_thread_con = thread_con;
		c_step = 2;

	   //normalized throuhput;
		app_thpt0 = bw;

		//minimal user parallelism;
		app_p0 = thread_con;

		//The throughput for the first point;
		lambda0= app_thpt0;

		//The user parallsliem limit for the first point;
		P0= app_p0;

		if(c_step < 2)
			c_step = 2;

		//thread_con = sch_thread_num;

		thread_con = 32;

		//disable_apples = 1;

		tail_measure = 1;

		c_fir = 2;
		sprintf(str_line, "P_optimization(Mode:%d) 1st round <sec: %4d, us: %4d   BW: %8.2f  OBW: %8.2f  DD: %4.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
								,  mode, e.tv_sec, e.tv_usec,  bw, ori_bw, dd, DATA_SET, last_thread_con, max_apples_delay);
		mem_log(str_line, 3);
	//}else if(c_fir==2){
	}else if(c_fir==3){
		last_c_bw = bw;
		last_c_dd = dd;
		last_thread_con = thread_con;
		c_step = 2;

		//The throuhput for all users;
        app_thpti = bw;
		
		//Prevent the disturbance of interim spikes;
		//if(app_thpti > app_thptx && app_thpti < 1.1 * app_thptx)
		//	app_thpti = 0.95 * app_thptx;

		//The throughput for the 2nd point;
		lambda1= app_thpti;

		//The user parallsliem limit for the 2nd point;
		P1= sch_thread_num/2;


		//Tell if the throughput is valid for derivation; 2020.8.23;
		int xf = xput_valid();

		if(NEWTON_F) xf = 1;

		if(!xf){
			sprintf(str_line, "P_optimization(Not valid!! GOTO the last measure processing... ) 3rd round <sec: %4d, us: %4d   BW: %8.2f  OBW: %8.2f  DD: %4.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
								,  e.tv_sec, e.tv_usec,  bw, ori_bw, dd, DATA_SET, last_thread_con, max_apples_delay);
		    mem_log(str_line, 3);
			//goto PL;
		}else{
			sprintf(str_line, "P_optimization(XF: %d) 3rd round <sec: %4d, us: %4d   BW: %8.2f  OBW: %8.2f  DD: %4.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
								,  xf, e.tv_sec, e.tv_usec,  bw, ori_bw, dd, DATA_SET, last_thread_con, max_apples_delay);
		    mem_log(str_line, 3);
		}

		min_thpt_x = min_bw;

		int ppp = 8;
		
		if(xf > 0){
			if(NEWTON_F){
				ppp = newton();
			}else{
				set1(app_thpt0, app_p0);
				//apples_cal(app_px, app_thptx, app_thpti);
				gamma_cal1(app_px, app_thptx, app_thpti);
				ppp = cal_p_from_thpt1(90000000.0, app_thpti);
			}

			sprintf(str_line, "P_optimization(XF: %d) P optimization <sec: %4d, us: %4d   P: %d  L: %d  [ %4.0f, %8.2f ], [ %4.0f, %8.2f ], [ %4.0f, %8.2f ]]\n"
								,  xf, e.tv_sec, e.tv_usec, ppp, DATA_SET, P0, lambda0, P1, lambda1, P2, lambda2);
		    mem_log(str_line, 3);

			if(ppp > fd_id_ptr - 2)
				ppp = fd_id_ptr - 2;
			//don't need user parallelism control;
			if(ppp<=0)
				ppp = sch_thread_num;
			//1: Enable user-level parallelism optimization 2020.8.25;
			//////////////////////////////////////////TEST 2022.1.23////////////////////////////////////////
			if(up_opt_f >0)
				thread_con = ppp;
			else
				thread_con = fd_id_ptr - 2;
			//////////////////////////////////////////TEST 2022.1.23////////////////////////////////////////
		}else{
			thread_con = fd_id_ptr - 2;
		}

		disable_apples = 0;

		c_fir = 4;
		sprintf(str_line, "P_optimization(Mode:%d) final round <sec: %4d, us: %4d   BW: %8.2f  OBW: %8.2f> [DATA_SET = %4d  opt_thread_con = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
								,  mode, e.tv_sec, e.tv_usec,  bw, ori_bw, DATA_SET, ppp, thread_con, max_apples_delay);
		mem_log(str_line, 3);

		set_opt_flag(1,1,1);

		record_reqs = 1;

		////////////////////////////////////////////////////////////////
		//2020.7.16 Output the initial value of P/L;
		char str_linex[16];
		
		if(1){
			int p0 = (int)P0, p1= (int)P1, p2= (int)P2;
			lseek(opt_handle[0], 0L, SEEK_SET);
			sprintf(str_linex, ",%d,%d,%d,%d,%d,%8.2f,%8.2f,%8.2f\n", ppp, DATA_SET, p0, p1, p2, lambda0, lambda1, lambda2);
			fwrite(str_linex,1,strlen(str_linex),wstream_opt[0]);
			fflush(wstream_opt[0]);
		}

	//}else if(c_fir==3){
	}else if(c_fir==2){

		last_c_bw = bw;
		last_c_dd = dd;
		last_thread_con = thread_con;
		c_step = 2;

		//The throuhput for all users;
        //app_thpti = bw;

		//The specific throuhput;
	    app_thptx = bw;
		//The specific user parallelism;
		app_px = thread_con;

		//The throughput for the 3rd point;
		lambda2= app_thptx;

		//The user parallsliem limit for the 3rd point;
		P2= app_px;

		//thread_con = thread_con + (fd_id_ptr - 1 - thread_con)/2;
		//if(thread_con > 32) thread_con = 32; //2021.2.19;

		//thread_con = 32;

		sprintf(str_line, "P_optimization(Mode:%d) 2nd round <sec: %4d, us: %4d   BW: %8.2f  OBW: %8.2f  DD: %4.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
								,  mode, e.tv_sec, e.tv_usec,  bw, ori_bw, dd, DATA_SET, thread_con, max_apples_delay);
		mem_log(str_line, 3);

		thread_con = sch_thread_num/2;

		c_fir = 3;
		////////////////////////////////////////////////////////////////////////
	}else if(c_fir==4){//2020.8.23 iteratively derivate the value of thread_con;

		last_c_bw = bw;
		last_c_dd = dd;
		last_thread_con = thread_con;
		c_step = 2;

		//The ratio of throughput variance;
        double xput_var_r = 1.0;

		if(app_thptx > 0.0)
			xput_var_r = bw/app_thptx;

		//The specific throuhput;
	    app_thptx = bw;
		
		//The throuhput for all users;
		app_thpti = xput_var_r * app_thptx;

		min_thpt_x = min_bw;
		
		//The throughput for the 2nd point;
		lambda1= app_thpti;

		//The throughput for the 3rd point;
		lambda2= app_thptx;

		//Tell if the throughput is valid for derivation; 2020.8.23;
		int xf = xput_valid();

		if(NEWTON_F) xf = 1;

		int ppp = 2;
		
		if(xf > 0){
		//if(xf > 0 && (sys_LL_xput > 0 || !tail_lat_opt)){ //2020.8.30;
			if(NEWTON_F){
				ppp = newton();
			}else{
				set1(app_thpt0, app_p0);
				//apples_cal(app_px, app_thptx, app_thpti);
				gamma_cal1(app_px, app_thptx, app_thpti);
				ppp = cal_p_from_thpt1(90000000.0, app_thpti);
			}

			if(ppp > fd_id_ptr - 2)
				ppp = fd_id_ptr - 2;
			//don't need user parallelism control;
			if(ppp<=0)
				//ppp = sch_thread_num;
				ppp = thread_con;
			//1: Enable user-level parallelism optimization 2020.8.25;
			//////////////////////////////////////////TEST 2022.1.23////////////////////////////////////////
			if(up_opt_f >0)
				thread_con = ppp;
			else
				thread_con = fd_id_ptr - 2;
			//////////////////////////////////////////TEST 2022.1.23////////////////////////////////////////
		}else{
			ppp = last_thread_con;
			thread_con = last_thread_con;
		}

		c_fir = 4;
		sprintf(str_line, "P_optimization(Update XF: %d) final round <sec: %4d, us: %4d   BW: %8.2f> [DATA_SET = %4d  opt_thread_con = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
									,  xf, e.tv_sec, e.tv_usec,  bw, DATA_SET, ppp, thread_con, max_apples_delay);
		mem_log(str_line, 3);
	}
}


//2019.8.23  TCP connection control law;
//the first run for control law;
#define INSTABLE 1
#define STABLE 0

int ctl_fir = 1;
float thpt_slo_min = 350 * 1000;
float thpt_slo_max = 500 * 1000;
float stack_lat_ms = 0;
float thpt_goal = 350 * 1000;
float last_ctl_bw = 10;
float last_ctl_dd = 0;
int C_state = INSTABLE;
float TIR_inc = 0.02;
float TIR_dec = -0.10;
float Q_ratio = 0.8;
//the value in the metric of 1/10000;
int MTD_lmt = 500;
float alpha = 0.5;
float C_w = 2;
int prev_c = 2;


int control_law(float bw, float dd, float ss, int mode)
{
	int i_ret = 0, i = 0;

	if(mode<=0) return 0;

	// TIR_{curr} = (Th_{curr}-Th_{prev})/Th_{prev};
	float TIR_curr = 0;
	//TIR_{min} = (Th_{curr}-Th_{min})/Th_{min};
	float TIR_min = 0;

	struct timeval e;
	sc_gettime(&e);

	char str_line[512];

	char s1[] = "START!";
    char s2[] = "INC1";
	char s3[] = "INC2";
	char s4[] = "STAB[+0]";
	char s5[] = "STAB[-1]";
	char s6[] = "INST";
	char s7[] = "LOC(-1)";
	char s8[] = "LOC(+1)";

	
	if(ctl_fir)
	{
		//Original bandwidth; 2019.3.4;
		ori_bw = bw;
		//Original queue length; 2019.8.23;
		ori_ql = dd;
		ori_ss = ss;
		if(stack_lat_ms<=0)
			stack_lat_ms = Q_ratio * dd * ss;
		ctl_fir = 0;
		thread_con = C_w;
		//Clear history data; 2019.8.28;
        his_sta_clear = 1;
		int ig = write_his_sig(his_sta_clear);
		sprintf(str_line, "CH = %02d  Control_Law(Min SLO:%8.2f, Max SLO:%8.2f, Lat SLO:%8.2f) %10.9s (%08d, %08d) <TIR_curr: %08.2f, TIR_min: %08.2f   BW: %08.2f  OBW: %08.2f  DD: %08.2f  ODD: %08.2f  FF: %08d  SS: %08.2f  OSS: %08.2f> [DATA_SET = %04d  thread_con = %04d  max_apples_delay = %04d]\n"
								,  ig, thpt_slo_min, thpt_slo_max, stack_lat_ms, s1, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, fairness_v, dd * ss, stack_lat_ms, DATA_SET, thread_con, max_apples_delay);
		mem_log(str_line, 3);
	}
	else
	{
		 //if(last_ctl_bw>0)
			TIR_curr = (bw - last_ctl_bw)/last_ctl_bw;

		last_ctl_bw = bw;
		
		if(thpt_slo_min>0)
			TIR_min = (bw - thpt_slo_min)/thpt_slo_min;

		  // The condition for exploring a higher C. 
		 if( C_state == INSTABLE && TIR_curr>TIR_inc && /*fairness_v < MTD_lmt &&*/ dd * ss < stack_lat_ms)
		{
			 prev_c = thread_con;
			if(bw < thpt_slo_min)
			{
				 //alpha * C_{weight} + alpha * C_{curr};
				 float c_inc = alpha * C_w + alpha * thread_con;
				thread_con += (int) c_inc;
				//sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f) INC1 (%08d, %08d) <TIR_curr: %8.2f, TIR_min: %8.2f   BW: %8.2f  OBW: %8.2f  DD: %8.2f  ODD: %8.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
				//				,  thpt_slo_min, thpt_slo_max, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, DATA_SET, thread_con, max_apples_delay);
				sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f, Lat SLO:%8.2f) %10.9s (%08d, %08d) <TIR_curr: %08.2f, TIR_min: %08.2f   BW: %08.2f  OBW: %08.2f  DD: %08.2f  ODD: %08.2f  FF: %08d  SS: %08.2f  OSS: %08.2f> [DATA_SET = %04d  thread_con = %04d  max_apples_delay = %04d]\n"
								,  thpt_slo_min, thpt_slo_max, stack_lat_ms, s2, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, fairness_v, dd * ss, stack_lat_ms, DATA_SET, thread_con, max_apples_delay);
		        mem_log(str_line, 3);
			}
			else
			{
				 //alpha * C_{weight}
				 float b_inc = alpha * C_w;
				thread_con += (int) b_inc;
				//sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f) INC2 (%08d, %08d) <TIR_curr: %8.2f, TIR_min: %8.2f   BW: %8.2f  OBW: %8.2f  DD: %8.2f  ODD: %8.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
				//				,  thpt_slo_min, thpt_slo_max, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, DATA_SET, thread_con, max_apples_delay);
				sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f, Lat SLO:%8.2f) %10.9s (%08d, %08d) <TIR_curr: %08.2f, TIR_min: %08.2f   BW: %08.2f  OBW: %08.2f  DD: %08.2f  ODD: %08.2f  FF: %08d  SS: %08.2f  OSS: %08.2f> [DATA_SET = %04d  thread_con = %04d  max_apples_delay = %04d]\n"
								,  thpt_slo_min, thpt_slo_max, stack_lat_ms, s3, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, fairness_v, dd * ss, stack_lat_ms, DATA_SET, thread_con, max_apples_delay);
		        mem_log(str_line, 3);
			}
		}

		/* The condition for determining the C value. */
        //else if(C_{state} == INSTABLE && (TIR_{curr}<=TIR_{inc} || MTD_{curr}>=MTD_{lmt} || QS_{curr}>=QS_{lmt}))
	    else if( C_state == INSTABLE && (TIR_curr<=TIR_inc || /*fairness_v >= MTD_lmt ||*/ dd * ss >= stack_lat_ms))
		{
			//C_{curr} = Max((C_{curr} + C_{prev})/2, 1);
			int it = (thread_con + prev_c)/2;
			if(it<1) it = 1;
			prev_c = thread_con;
			thread_con = it;
			C_state = STABLE;
			
			//If thpt_slo_min is not feasible;
			//if(bw < thpt_slo_min) 
			//	thpt_slo_min = bw;

			//sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f) STAB[+0] (%08d, %08d) <TIR_curr: %8.2f, TIR_min: %8.2f   BW: %8.2f  OBW: %8.2f  DD: %8.2f  ODD: %8.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
			//					,  thpt_slo_min, thpt_slo_max, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, DATA_SET, thread_con, max_apples_delay);
			sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f, Lat SLO:%8.2f) %10.9s (%08d, %08d) <TIR_curr: %08.2f, TIR_min: %08.2f   BW: %08.2f  OBW: %08.2f  DD: %08.2f  ODD: %08.2f  FF: %08d  SS: %08.2f  OSS: %08.2f> [DATA_SET = %04d  thread_con = %04d  max_apples_delay = %04d]\n"
								,  thpt_slo_min, thpt_slo_max, stack_lat_ms, s4, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, fairness_v, dd * ss, stack_lat_ms, DATA_SET, thread_con, max_apples_delay);
		    mem_log(str_line, 3);
		}

	   /* Any combination of the following 4 cases can impact the SLO guarantees */
       /*1. One or more applications start to run concurrently or existing concurrently-running applications impose a higher I/O load;*/
       /*2. One or more applications stop to run concurrently or existing concurrently-running applications reduce their I/O load;*/
       /*3. The target application shows a lower I/O load due to less intensive users I/O;*/
       /*4. The target application shows a higher I/O load due to more intensive users I/O;*/
       /*Any violations of fairness, throughput or queue slots quota SLOs will triger another round of exploration*/
      //else if(C_{state} == STABLE && (MTD_{curr}>MTD_{lmt} || QS_{curr}>QS_{lmt} || Min(TIR_{min}, TIR_{curr})<TIR_{dec}))
	    else if(C_state == STABLE && (/*fairness_v >= MTD_lmt || dd >= Q_ratio * ori_ql /*||*/ TIR_curr < TIR_dec || TIR_min < TIR_dec))
		{
			if( dd * ss >= stack_lat_ms)
			{
				 //C_{curr} =  alpha * C_{weight} + C_{curr}/2;
				 prev_c = thread_con;
				 float b_inc = alpha * C_w + thread_con/2;
				 thread_con = (int) b_inc;

				 //sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f) STAB[-1] (%08d, %08d) <TIR_curr: %8.2f, TIR_min: %8.2f   BW: %8.2f  OBW: %8.2f  DD: %8.2f  ODD: %8.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
				//				,  thpt_slo_min, thpt_slo_max, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, DATA_SET, thread_con, max_apples_delay);
				sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f, Lat SLO:%8.2f) %10.9s (%08d, %08d) <TIR_curr: %08.2f, TIR_min: %08.2f   BW: %08.2f  OBW: %08.2f  DD: %08.2f  ODD: %08.2f  FF: %08d  SS: %08.2f  OSS: %08.2f> [DATA_SET = %04d  thread_con = %04d  max_apples_delay = %04d]\n"
								,  thpt_slo_min, thpt_slo_max, stack_lat_ms, s5, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, fairness_v, dd * ss, stack_lat_ms, DATA_SET, thread_con, max_apples_delay);
				mem_log(str_line, 3);
			}
            else if(  dd * ss < stack_lat_ms/2 && TIR_min < TIR_dec)
			{
				C_state = INSTABLE;
				//ori_ql *= (1+TIR_min);

				//sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f) INST (%08d, %08d) <TIR_curr: %8.2f, TIR_min: %8.2f   BW: %8.2f  OBW: %8.2f  DD: %8.2f  ODD: %8.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
				//				,  thpt_slo_min, thpt_slo_max, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, DATA_SET, thread_con, max_apples_delay);
				sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f, Lat SLO:%8.2f) %10.9s (%08d, %08d) <TIR_curr: %08.2f, TIR_min: %08.2f   BW: %08.2f  OBW: %08.2f  DD: %08.2f  ODD: %08.2f  FF: %08d  SS: %08.2f  OSS: %08.2f> [DATA_SET = %04d  thread_con = %04d  max_apples_delay = %04d]\n"
								,  thpt_slo_min, thpt_slo_max, stack_lat_ms, s6, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, fairness_v, dd * ss, stack_lat_ms, DATA_SET, thread_con, max_apples_delay);
		        mem_log(str_line, 3);
			}
		}
		
		//Coordinate LOC control knob;
		else if(C_state == STABLE && (thpt_slo_max > thpt_slo_min && bw < thpt_slo_max && bw > thpt_slo_min))
		{
			 if(fairness_v >= fairness_high_b)
			{
				 for(i=1;i<=fd_id_ptr;i++)
				{
					//Setup req_token[i];
					DATA_SET /= fairness_step;
					req_token[i] /= fairness_step;
					if(req_token[i] < 1) req_token[i] = 1;

					//sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f) LOC(-1) (%08d, %08d) <TIR_curr: %8.2f, TIR_min: %8.2f   BW: %8.2f  OBW: %8.2f  DD: %8.2f  ODD: %8.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
					//				,  thpt_slo_min, thpt_slo_max, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, DATA_SET, thread_con, max_apples_delay);
					sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f, Lat SLO:%8.2f) %10.9s (%08d, %08d) <TIR_curr: %08.2f, TIR_min: %08.2f   BW: %08.2f  OBW: %08.2f  DD: %08.2f  ODD: %08.2f  FF: %08d  SS: %08.2f  OSS: %08.2f> [DATA_SET = %04d  thread_con = %04d  max_apples_delay = %04d]\n"
								,  thpt_slo_min, thpt_slo_max, stack_lat_ms, s7, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, fairness_v, dd * ss, stack_lat_ms, DATA_SET, thread_con, max_apples_delay);
					mem_log(str_line, 3);
				}
			}
			else if(fairness_v < fairness_low_b && fairness_v > 1 && last_fairness_v - fairness_v > fairness_low_b)
			{
				 DATA_SET += fairness_unit;

				 for(i=1;i<=fd_id_ptr;i++)
				{
					if(req_token[i]+fairness_unit <= 256)
					{
						req_token[i] += fairness_unit;
					}
				}

				//sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f) LOC(+1) (%08d, %08d) <TIR_curr: %8.2f, TIR_min: %8.2f   BW: %8.2f  OBW: %8.2f  DD: %8.2f  ODD: %8.2f> [DATA_SET = %4d  thread_con = %4d  max_apples_delay = %4d]\n"
				//					,  thpt_slo_min, thpt_slo_max, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, DATA_SET, thread_con, max_apples_delay);
				sprintf(str_line, "Control_Law(Min SLO:%8.2f, Max SLO:%8.2f, Lat SLO:%8.2f) %10.9s (%08d, %08d) <TIR_curr: %08.2f, TIR_min: %08.2f   BW: %08.2f  OBW: %08.2f  DD: %08.2f  ODD: %08.2f  FF: %08d  SS: %08.2f  OSS: %08.2f> [DATA_SET = %04d  thread_con = %04d  max_apples_delay = %04d]\n"
								,  thpt_slo_min, thpt_slo_max, stack_lat_ms, s8, e.tv_sec, e.tv_usec,  TIR_curr, TIR_min,  bw, ori_bw, dd,  ori_ql, fairness_v, dd * ss, stack_lat_ms, DATA_SET, thread_con, max_apples_delay);
				mem_log(str_line, 3);
			}

		}
	}

	return i_ret;
}

#endif