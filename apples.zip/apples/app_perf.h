/*
 This file provides an interface for user applications to export performance monitoring data to XPSLO++ system, which is the basis of QoE guaranteeing. 
 *
 *  Ning Li <leening0810@163.com> <ning.li@uta.edu>
 */

/*************************************************************/
/*     Application's performance output interface (APOI)     */
/*************************************************************/
#include <unistd.h>  
#include <stdlib.h>  
#include <stdio.h>  
#include <sys/shm.h> 
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/time.h>
#include <time.h>


//The number of allocated pages;
#define PAGES_NUMBER_L          32
#define SA_ONCE_NUM             1024
#define RATIO_SAM               2
#define BLKDEV_MAX_RQ           32
#define BLKDEV_MIN_RQ           1

char * p_data = NULL;

int add_iopsy = 0;
int add_bw = 0;
int add_io_size = 0;
int add_qs = 0;
int add_original_qlimit = 0;
int add_safeq_times = 0;
unsigned int add_violate = 0;
unsigned int add_violate_all = 0;
int add_p5 = 0;
int add_safe_qlen1 = 0;
int add_safe_qlen2 = 0;
int add_safe_qlen3 = 0;
int add_latency_y = 0;
unsigned long add_all_wait_time = 0;
unsigned long add_all_service_time = 0;
unsigned long add_service_time = 0;
unsigned int add_viosamples = 0;
unsigned int add_viosamples_all = 0;
unsigned int add_viosamples_alt = 0;
unsigned int add_viosamples_blt = 0;
unsigned int add_violate_arr[SA_ONCE_NUM];
unsigned int add_service_arr[SA_ONCE_NUM];
unsigned long long add_all_response_time = 0;
int add_response_idx = 0;
unsigned char add_safe_flag = 0;
unsigned char add_safe_flag_rec = 0;

unsigned int add_iopsx = 0;
int add_req_num = 0;
//unsigned int add_wait_req = 0;
unsigned long add_time_ms = 0;
unsigned int add_util = 0;
unsigned long add_com_req_num = 0;
unsigned long add_wait_time = 0;
int add_bw_sec_add_x = 0;
int add_all_qs = 0;

int add_mq = BLKDEV_MIN_RQ;
unsigned long add_qu_all_service_time = 0;
unsigned long add_qu_all_wait_time = 0;
unsigned long add_qu_com_req_num = 0;
unsigned long add_qu_service_time = 0;
unsigned long add_qu_wait_time = 0;
unsigned int add_qs_com_req_num = 0;
unsigned long add_qs_all_service_time = 0;
unsigned long add_qs_all_wait_time = 0;

//The threshold of AIO queue depth;
int aio_queue_depth = 1;

int v_err = 0;
int all_v = 0;

int betax = 1;
int xctl_beta_val = 1;
int xctl_qq_val = 5;
int xctl_sp_val = 2000;
unsigned long xsta_win = 20;
int xctl_st_val = 0;
int xctl_lat_val = 0;

unsigned long long last_us = 0;

 //Get the current time in the metric of millisecond;
static unsigned long long current_time()
{
	struct timeval tv;
	gettimeofday(&tv, NULL); 
	unsigned long long ret_val = tv.tv_sec * 1000000 +  tv.tv_usec; //us;
	//ret_val /= 1000; //ms;
	return ret_val;
}

//Recording;
FILE * wstream_vqc;

void APOI_init_rec()
{
	 wstream_vqc = NULL;
}

int APOI_open_cmd_log(char * experiment, int index)
{
	int i=0;
	char f_str[128];

	 APOI_init_rec();

	sprintf(f_str,"./%s/%d/aslo_vqc_log%d.txt", experiment, index, i+1);
	wstream_vqc = fopen(f_str,"w+");

	if(wstream_vqc==NULL)
		return 0;

	return 1;
}

int APOI_write_log(char * k_cmd)
{
	int r_f = 1;

	if(k_cmd==NULL || wstream_vqc==NULL)
		return 0;

	fwrite(k_cmd,1,strlen(k_cmd),wstream_vqc);
	fflush(wstream_vqc);

	return r_f;
}

int APOI_close_log()
{
	if(wstream_vqc!=NULL)
	{
		fclose(wstream_vqc);
		wstream_vqc = NULL;
	}
	return 1;
}

//Set the percentile;
int APOI_percentile(int per)
{
	if(per < 10 || per > 9999)
		return 0;
	xctl_st_val = per;
	return 1;
}

//Set the latency SLO;
int APOI_latency(int lat)
{
	if(lat <= 1)
		return 0;
	xctl_lat_val = lat;
	return 1;
}

//Initilization;
int APOI_interface_init(int per, int lat)
{
    void *shm = NULL;
    
    int shmid;

	char * shared = NULL;

	int r_f = APOI_percentile(per);

	if(r_f)
	  r_f = APOI_latency(lat);

	if(!r_f)
	{
		printf("\nAPOI >>>  Wrong inputs of the percentile or the latency SLO!\n");
	}
    
    shmid = shmget((key_t)1212, PAGES_NUMBER_L * 4096 * sizeof(char), 0666|IPC_CREAT);  

    if(shmid == -1)  
    {  
        fprintf(stderr, "APOI Cache shmget failed\n");  
        exit(EXIT_FAILURE);  
    }  
    
    shm = shmat(shmid, 0, 0);  
    if(shm == (void*)-1)  
    {  
        fprintf(stderr, "APOI Cache shmat failed\n");  
        exit(EXIT_FAILURE);  
    }  
    printf("\nAPOI Cache attached at %X\n", (int)shm);  
   
    shared = (char *)shm;
	
	p_data = shared;

    memset(shared, 0, PAGES_NUMBER_L * 4096 * sizeof(char));

	return 1;
}

//APOI hook function;
int APOI_interface_hook()
{
	void *shm = NULL;
    struct data_set *shared;
    int shmid;
    
    shmid = shmget((key_t)1212, PAGES_NUMBER_L * 4096 * sizeof(char), 0666|IPC_CREAT);  

    if(shmid == -1)  
    {  
        fprintf(stderr, "APOI Cache (hook) shmget failed\n");  
        exit(EXIT_FAILURE);  
    }  
    
    shm = shmat(shmid, 0, 0);  
    if(shm == (void*)-1)  
    {  
        fprintf(stderr, "APOI Cache (hook) shmat failed\n");  
        exit(EXIT_FAILURE);  
    }  
    printf("\nAPOI Cache (hook) at %X\n", (int)shm);  
   
    shared = (char *)shm;
	
	p_data = shared;
	return 1;
}

//Output the monitored perfomrance metrics;
int APOI_write(char * proc_str) {
	int i_ret = 1;
	if(proc_str==NULL) return 0;
	strcpy((unsigned char *) p_data, proc_str);
	//printf("\n%s\n",p_data);
	return i_ret;
}

//Read the monitored perfomrance metrics;
int APOI_read(char * proc_str) {
	int i_ret = 1;
	if(proc_str==NULL || p_data==NULL) return 0;
	strcpy(proc_str,(unsigned char *) p_data);
	return i_ret;
}

char * APOI_shared() {
	return p_data;
}

void APOI_memset()
{
	if(p_data!=NULL)
		memset(p_data, 0, PAGES_NUMBER_L * 4096 * sizeof(char));
}

int get_tail_sample_num(int tail_target)
{
	int sample_num = 1000;
	int st_limits[3] = {99,999,9999};

	if(tail_target<=st_limits[0])
		sample_num = st_limits[0] + 1;
	else if(tail_target>st_limits[0] && tail_target<=st_limits[1])
		sample_num = st_limits[1] + 1;
	else if(tail_target>st_limits[1] && tail_target<=st_limits[2])
		sample_num = st_limits[2] + 1;

	sample_num *= betax;

	return sample_num;
}

int get_tail_violate_lmt(int tail_target, int sample_num)
{
	int violate_lmt = 1;
	violate_lmt = sample_num - tail_target * betax;
	return violate_lmt;
}

int tail_enforce_logic (int tail_target, int new_samples, int new_violates, int lat_ctl)
{
	int act_flag = 0;
	int alphax = 1;
	int set_sp_val = xctl_sp_val;
	char xxstr[256];
	memset(xxstr, 0, 256 * sizeof(char));

	if(xctl_sp_val<=0)
		return act_flag;

	int req_sample_num =  get_tail_sample_num(tail_target);
	int req_violate_num =  get_tail_violate_lmt(tail_target, req_sample_num);

	add_viosamples_all += new_samples;
	add_violate_all += new_violates;
	add_viosamples_alt += new_samples;
	add_viosamples_blt += new_samples;

	unsigned int vio_lmt = 0;
	
	if(add_viosamples_alt >= req_sample_num)
	{
		vio_lmt = (req_violate_num * add_viosamples_all) / req_sample_num;

		if(vio_lmt < 1)
			vio_lmt = 1;

		v_err = (int)vio_lmt - (int)add_violate_all;
		all_v = vio_lmt;
		
		if(xctl_beta_val>0)
		{
			//2016.9.17;
			if(v_err > RATIO_SAM * xctl_qq_val * add_mq) //2016.5.17;
			{
				//if(add_qs >= add_mq * 500)
				{
					if(add_mq < BLKDEV_MAX_RQ)
					   add_mq++;
					else
					   add_mq = BLKDEV_MAX_RQ;

					act_flag = 1;
				}
			}
			//2016.9.17;
			else if (v_err < xctl_qq_val * add_mq)
			{
				    //2016.9.17;
					 if(add_mq > BLKDEV_MIN_RQ)
				     {
						   add_mq--;
						   //act_flag = 1;
					 }
					 act_flag = 1;
			}

			aio_queue_depth = add_mq;
		}

		///////////////////////////////////////////////
		//2016.1.2 print only;
		//if(1)
		sprintf(xxstr,"\nAPOI(%8d) [VCQ (%4d (ms))]   viosamples = %10d  violate = %10d  vio_lmt = %8d  v_err = %8d  mq = %5d  sp = %5d  ta = %8d"
		            ,current_time()%100000000, lat_ctl, add_viosamples_all, add_violate_all, vio_lmt, v_err, add_mq, xctl_sp_val, tail_target);
		APOI_write_log(xxstr);
		///////////////////////////////////////////////
		add_viosamples_alt = 0;
	}

	return act_flag;
}

static int exp_ver1 = 0;

char con_str[131072];

static int statistics_vm_queue(int span, int si)
{
	int i, vm_num=0, vm_idx=0;

	if(span<=0) return 0;

	char pstr[128];
	memset(pstr,0,128);

	vm_num = 1;

	int vm_id = 1;
	
	memset(con_str,0,131072 * sizeof(char));

    //=ver=0=vn=1=[1]ut=65=[1]st=200=[1]wt=5000
	exp_ver1++;
	if(exp_ver1>=10000) exp_ver1 = 1; //1~9999;
	sprintf(pstr,"=ver=%d=vn=%d",exp_ver1,vm_num);
	strcat(con_str,pstr);

	int iops = 1;
	int io_size = 4;
	int qs = 1;
	int bxnum = 0;
	
	//IO throughput; iops
	iops = add_iopsy;
	sprintf(pstr,"=%dth=%d",vm_id, iops);
	strcat(con_str,pstr);
	
	//Bandwidth; //unit KB/s;
	bxnum = add_bw;
	sprintf(pstr,"=%dbw=%d",vm_id, bxnum);
	strcat(con_str,pstr);
	
	//IO size 1000 * sectors;
	io_size = add_bw_sec_add_x;
	sprintf(pstr,"=%drs=%d",vm_id, io_size);
	strcat(con_str,pstr);

	//IO depth; *1000
	qs = add_qs;
	sprintf(pstr,"=%dqs=%d",vm_id, qs);

	strcat(con_str,pstr);

	//wait; us
	sprintf(pstr,"=%dwt=%d",vm_id, add_latency_y);
	strcat(con_str,pstr);

	//service time;  us
	sprintf(pstr,"=%dst=%d",vm_id, add_service_time);
	strcat(con_str,pstr);
	
	int violate_v = add_violate;

	//violates;  times;
	sprintf(pstr,"=%dve=%d",vm_id, violate_v);
	strcat(con_str,pstr);

	int viosamples_v = add_viosamples;

	//samples;  times;
	sprintf(pstr,"=%dsa=%d",vm_id, viosamples_v);
	strcat(con_str,pstr);

	//samples;  times;
	sprintf(pstr,"=%dv1=%d",vm_id, v_err); //2016.5.18
	strcat(con_str,pstr);

	//2015.5.31  temperarily for showing  io_size;
	sprintf(pstr,"=%dv2=%d",vm_id, all_v); //2016.5.18
	strcat(con_str,pstr);

	sprintf(pstr,"=%dv3=%d",vm_id, xctl_sp_val);
	strcat(con_str,pstr);

	int j = 0;
	
	//IO latency;
	sprintf(pstr,"=%dv4=", vm_id);
	strcat(con_str,pstr);

	int viosamples_once = viosamples_v;
	if(viosamples_once > SA_ONCE_NUM)
		viosamples_once = SA_ONCE_NUM;
	
	for(j=0;j<viosamples_once;j++)
	{
		if(j<viosamples_once-1)
			sprintf(pstr, "%d_", add_violate_arr[j]);
		else
			sprintf(pstr, "%d", add_violate_arr[j]);
		strcat(con_str,pstr);
	}

	//service time;
	sprintf(pstr,"=%dv5=", vm_id);
	strcat(con_str,pstr);

	for(j=0;j<viosamples_once;j++)
	{
		if(j<viosamples_once-1)
			sprintf(pstr, "%d_", add_service_arr[j]);
		else
			sprintf(pstr, "%d", add_service_arr[j]);
		strcat(con_str,pstr);
	}
	
	//response time;
	sprintf(pstr,"=%dT=%d",vm_id, span);
	strcat(con_str,pstr);

	add_viosamples = 0;
	add_violate = 0;
	add_all_response_time = 0;
	add_response_idx = 0;
	memset(add_violate_arr, 0, SA_ONCE_NUM * sizeof(unsigned int));
	memset(add_service_arr, 0, SA_ONCE_NUM * sizeof(unsigned int));
	add_bw_sec_add_x = 0;
					

	if(vm_num>0)
	{
		strcat(con_str,"=");
		APOI_write(con_str);
	}
	return vm_num;
}

//export_vm_info;
static int export_vm_info(int span, int si)
{
	int i, r_f = 0;

	char pstr[128];
	memset(pstr,0,128);

	int vm_idx = 0;
	int iopsx = 0;
	int wait_req = 0;

	int vm_num=1;

	sprintf(pstr,"=vn=%d=",vm_num);

	
	if(span!=0)
	{
		add_iopsx = 1000 * add_req_num * si / span;
		//add_wait_req = jiffies_to_msecs(add_time_ms);
		//add_wait_req = 1000 * wait_req *  si / span;
		add_util = 1000 * add_all_service_time * si/(1000 * span);
		if(add_util>1000)
			add_util = 1000;
		if(add_com_req_num > 0)
		{
			add_service_time = add_all_service_time/add_com_req_num;
			add_wait_time = add_all_wait_time/add_com_req_num;
			//2014.5.14
			add_latency_y = add_wait_time;
			add_iopsy = add_iopsx;
		}

		if(add_req_num > 0)
		{
			add_io_size = 1000 * add_bw_sec_add_x/add_req_num; //*1000
			add_qs = add_iopsx * add_latency_y / 1000; //*1000

			//2014 5.15
			add_bw = add_iopsx * add_io_size / 1000;
		}
	}

	add_req_num = 0;
	add_time_ms = 0;
	add_all_service_time = 0;
	add_all_wait_time = 0;
	add_com_req_num = 0;

	add_all_qs = 0;
	r_f++;
				
	statistics_vm_queue(span, 1000);
	return r_f;
}

static void APOI_RequestArrival()
{
	unsigned long long t = current_time();

	if(last_us<=0) last_us = t;
	else
	{
		if(t - last_us >= xsta_win * 1000)
		{
			int t_span = t - last_us;
			export_vm_info(t_span, 1000);
			last_us = t;
		}
	}
	
}

int APOI_statistics_io(unsigned long wt, unsigned long st, int kb_size)
{
	int sam_v = 0;
	int vio_v = 0;
	sam_v=1;

	add_com_req_num++;
	add_all_service_time += st;
	add_all_wait_time += wt;

	add_req_num++;
	add_bw_sec_add_x += kb_size;

	if(add_viosamples < SA_ONCE_NUM)
	{
		add_violate_arr[add_viosamples] = wt;
		add_service_arr[add_viosamples] = st;
		add_viosamples++;
	}

	unsigned long lng_lat_ctl = xctl_lat_val * 1000; //us
	
	if(wt >= lng_lat_ctl)
	{
		add_violate++;
		vio_v=1;
	}

	//tail_enforce_logic (xctl_st_val, sam_v, vio_v, xctl_lat_val);
	return 1;
}

int APOI_ctl(int new_samples, int new_violates)
{
	int r_f = 0;
	int a_f = tail_enforce_logic (xctl_st_val, new_samples, new_violates, xctl_lat_val);
	if(a_f > 0)
		r_f = aio_queue_depth;
	return r_f;
}

int get_file_line(char *pInputName, char *pOutputBuf, int cnt)  
{  
    FILE * fp;  
    int i=0;  
    char * line = NULL;  
    size_t len = 0;  
    ssize_t read;  
  
    fp = fopen(pInputName, "r");  
    if (fp == NULL)  
     return -1;  
  
    if(cnt<=0)  
         return -2;  
           
    while ((read = getline(&line, &len, fp)) != -1) {  
        ++i;  
        if(i>=cnt)  
            break;  
    }  
  
    if (line)  
    {  
        memcpy(pOutputBuf,line,strlen(line));  
        free(line);  
        return 1;   
    }  

	fclose(fp);
	fp = NULL;
  
    return -3;  
}  

// /root/mod_prob/PSLO_cfg.txt design��
// =per=999=lat=260=ip=1=id=1=n=3=ip1=224=ip2=222=ip3=223=
#define MAX_HOST_CON 8

//percentile;
//unsigned int per = 0;
//latency;
//unsigned int lat = 100;
//the id of VM;
//unsigned int ip = 1;
//the id of host;
//unsigned int id = 1;
//the number of hosts that are required to communicate with;
//unsigned int n = 3;
//the ip address array of the aforementioned host; 
//char * ip_arr[MAX_HOST_CON];

int APOI_config(unsigned int * per, 
                unsigned int * lat, 
				unsigned int * ip, 
				unsigned int * id, 
				unsigned int * n, 
				char ** ip_arr)
{
	int r_f = 1;
	char f_p[256];
	sprintf(f_p,"/root/sys_xpslo_mon_dis_host/PSLO_cfg.txt");

	char f_b[256];
	memset(f_b,0,256*sizeof(char));
	char id_str[64];
	memset(id_str,0,64*sizeof(char));

	r_f = get_file_line(f_p, f_b, 1); 

	char * appstr;


	if(r_f>0)
	{
		if ((appstr = strstr(f_b, "=per=")) != NULL)
		{
			sscanf(appstr, "=per=%u", per);

			printf("\n VM config per = %d", *per);

			if ((appstr = strstr(f_b, "=lat=")) != NULL)
			{
				sscanf(appstr, "=lat=%u", lat);

				printf("\n VM config lat = %d", *lat);
			}

			if ((appstr = strstr(f_b, "=ip=")) != NULL)
			{
				sscanf(appstr, "=ip=%u", ip);

				printf("\n VM config ip = %d", *ip);
			}

			if ((appstr = strstr(f_b, "=id=")) != NULL)
			{
				sscanf(appstr, "=id=%u", id);

				printf("\n VM config id = %d", *id);
			}

            //The IPs of hosts the VM needs inform;
			char f_p[256];
	        sprintf(f_p,"/root/sys_xpslo_mon_dis_host/VNet_cfg.txt");

			char * f_bb = NULL;

			char t_p[256];
			memset(t_p, 0, 256 * sizeof(char));

			r_f = get_file_line(f_p, t_p, 1);

			f_bb = strtok(t_p,"\r\n");

			*n = atoi(f_bb);

			printf("\n The number of hosts the VM needs inform: %d ||| SLO configurations as below:\n", *n);

			if(*n > MAX_HOST_CON)
			{
				printf("\n The number of hosts the VM needs inform exceeds the maximum value!\n");
				exit(0);
			}

			//The IP addresses;
			int i = 0;
			for(i=0;i<*n;i++)
			{
				r_f = get_file_line(f_p, t_p, i+2);

				if(r_f<0)
				{
					printf("\n Please make sure the configuration of VNet_cfg!\n");
					exit(0);
				}

				f_bb = strtok(t_p,"\r\n");

				strcpy(ip_arr[i], f_bb);

				printf("\nInformed host IP[%d] = %s\n",  i+1, ip_arr[i]);
			}

			printf("\n");

			/*if ((appstr = strstr(f_b, "=n=")) != NULL)
			{
				sscanf(appstr, "=n=%u", n);

				printf("\n VM config n = %d", *n);

				if(*n>0 && *n<=MAX_HOST_CON)
				{
					int i=0;

					for(i=0;i<*n;i++)
					{
						sprintf(id_str,"ip%d",i+1);

						if ((appstr = strstr(f_b, id_str)) != NULL)
						{
							sscanf(appstr+4, "%u", &ip_arr[i]);

							printf("\n VM config %s = %d", id_str, ip_arr[i]);
						}
					}
				}
			}*/
		}
	}

	return r_f;
}