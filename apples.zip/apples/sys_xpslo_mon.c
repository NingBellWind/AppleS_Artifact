#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/utsname.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/shm.h>  
#include <sys/timeb.h>
#include <math.h>
#include <assert.h>
//#include <engine.h>
#include <sys/time.h>

#include <libsyscall_intercept_hook_point.h>
#include <syscall.h>
#include <errno.h>

#include "common.h"
#include "time_sta.h"
#include "rec.h"
#include "shm.h"
#include "fd.h"
#include "queue.h"
#include "shm.h"
#include "opt_algo.h"
#include "tail.h"


static int read_num = 0;

//Time interval controlling; 2018.8.19
struct timeval time_us;
struct timeval time_us1;
int time_init = 1;
int time_init1 = 1;
unsigned long long tdiff = 0;
unsigned long long tdiff1= 0;
//Long-term statistical interval;;//8/26/2018;
int sta_long_idx = 0;
int sta_mid_idx = 0;
int wait_time = 1000;
float last_mutil = -1;

int inter_time = 100;

int main_time = 3000;

float last_dd = 0;

int ver_v = 0;
int last_ver_v = 0;

float dd = 0;

//Make statistics for syscalls; 2019.3.20;
void sys_call_sta(int syscall_number, int a0)
{
	//Intercept net I/O requests; //1/29/2019;
	  int ke = 0;
	  for(ke=0;ke<sys_call_idx;ke++)
	{
		  if(syscall_number==sys_call[ke])
			  break;
	}
	if(ke==sys_call_idx && sys_call_idx<511)
	{
		sys_call[sys_call_idx++] = syscall_number;
		sys_num[sys_call_idx-1] = 1;
		char f_str[256];
			  sprintf(f_str,">Sys_call[%03d]: %d, a0: %d\n"
									 , sys_call_idx, syscall_number, a0);
			  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
			  fflush(wstream_mem[0]);
	}
	else if(ke<sys_call_idx)
	{
		sys_num[ke]++;
	}

	//Statistics; 2019.1.9;
	    sys_total_num++;
		//pthread_rwlock_wrlock(&ctlock);
		//Time interval controlling; 2018.8.19
         //2019.1.9 change to ms;
		if(sys_total_num > 50000)
		{    
			        sys_total_num = 0;
			       //system call statistics; 2019.3.19;
					int y = 0;
					char f_str[256];

					for(y=0;y<sys_call_idx;y++)
					{
						if(y==0)
						{
						  sprintf(f_str,"\n\n========================\n");
						  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
						  fflush(wstream_mem[0]);
						}
						  sprintf(f_str,"==Sys_num[%03d]: %08d\n"
												 , sys_call[y], sys_num[y]);
						  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
						  fflush(wstream_mem[0]);
					}
		}
}

int mss = 1;


static int
hook(long syscall_number,
			long arg0, long arg1,
			long arg2, long arg3,
			long arg4, long arg5,
			long *result)
{
	
	int fd_id = arg0;

    //this for address offset;
	//long file_addr = arg1;
	//this for I/O size;
	long file_addr = arg2;

	int tid = 0;
	//for thread-user connection; 2020.3.29;
	int th_id = 0;

	float dd_ratio = 0;
	float de_ratio = 0;

    //Allow thread id query;
	if (syscall_number == 186)
		return 1;

	//Get thread id;
	if(!NET_ID_F)
		tid = (int)syscall(186);
	//for thread-user connection; 2020.3.29;
	else
		th_id =  (int)syscall(186);


	int inter_f = 0;

	//inter_f = Is_net_send(syscall_number);
	/*inter_f = Is_net_connect(syscall_number);

	//Tell if the system call is net-related I/O receiving; //2/1/2019;
	if(inter_f)
	{
		 //Socket analysis; 2019.2.26;
		if(NET_ID_F)
		{
			int s_idx = get_nd_idx(fd_id);
			if(s_idx<=0)
			{
				 Invoke_ND(fd_id, 1, tid);
				 s_idx = get_nd_idx(fd_id);
			}

			if(s_idx>0)
			{
				 socket_ana_func(inter_f, arg1, net_id_arr[s_idx].ip_str, &net_id_arr[s_idx].port);
			}
		}
	}*/

	//file handle; 2018.8.19;
    if(check_FD_noctl(fd_id, tid) || (tid == noctl_tid && noctl_tid > 0))//2018.11.5 adding the latter part. If it is control thread, don't need to delay;
	{
		if(!Is_net(syscall_number))
			return 1;
	}

	//Make statistics for syscalls; 2019.3.20;
     // sys_call_sta(syscall_number, fd_id);
	  //return 1;
	  ////////////////////////////////////////////////////////////////////////////////

   //Observe the content in the request; Statistics for networking I/O; 2019.1.24;
	/*if( //syscall_number == SYS_sendto
	   //|| syscall_number == SYS_recvfrom
	   //|| syscall_number == SYS_sendmsg
	   syscall_number == SYS_recvmsg)
	{
		//The lock for threads; //9/28/2018;
		//pthread_rwlock_wrlock(&rwlock);
		//Invoking a syscall for a NetID; //1/24/2019;
		//Invoke_ND_type(fd_id, syscall_number, tid);
		//Set up socket IDs for each correlated threads; 2019.1.24;
		//add_net_id_th(tid, fd_id);
		//Unlock threads; //9/28/2018;
		//pthread_rwlock_unlock(&rwlock);

		 char f_str[4096];
		 memset(f_str, 0, 4096);
		 int len = (int)arg2;
		 //if(len>255) len = 255;
		 if((char*)arg1!=NULL && mss)
		{
			 struct msghdr *msg = (struct msghdr *)arg1;
			 //memcpy(f_str, (char*)arg1, len);
			 //strcat(f_str, '\n');
			 sprintf(f_str, "sn:  %08d   len = %08d   p = %#x   r = %08d   arr_len = %8d   msg_len = %08d   msg: %s\n"
				                     , syscall_number, arg2, (char*)arg1, *result, msg->msg_iovlen, msg->msg_iov[0].iov_len, (char*)(msg->msg_iov[0].iov_base));
			 fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
			 fflush(wstream_mem[0]);

			 //mss = 0;
		}
		return 1;
	}*/

	

     //Intercept net I/O requests; //1/29/2019;
	if(NET_ID_F)
	{
		inter_f = Is_net_recv(syscall_number);
		//Tell if the system call is ppoll-related or epoll I/O receiving; //3/26/2019;
		if(inter_f<=0)
		{
			int intvf =  *result;
			inter_f = Is_poll_recv(syscall_number, intvf);

		     if(inter_f)
			{
				   struct pollfd * fds = (struct pollfd *)arg0;

				 	//Statistics; 2019.1.9;
					sys_total_num++;
					 //2019.1.9 change to ms;
					if(sys_total_num > 50000)
					{    
								sys_total_num = 0;
								 // if(*result > 0)
								{
									  char f_str[256];
									  //struct pollfd * fds = (struct pollfd *)arg0;
									  sprintf(f_str,">SC[%04d]: ag0 = %8d   fd1 = %8d   res: %4d\n"
															 , syscall_number, fd_id, fds[0].fd, intvf);
									 // fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
									//  fflush(wstream_mem[0]);
								}
					}
			}

			/*if(inter_f)
			{
				int ik  = *result;
				  if(ik > 0 && ik<10000 && data_rec_f)
				{
					  struct epoll_event * fds = (struct epoll_event *)arg1;
					  if(fds!=NULL)
					{
						  char f_str[3078];
						  char tt_str[32];
						  int yi = 0;
						  sprintf(f_str,">SC[%04d]: ag0 = %8d   res: %4d  fds : "
												 , syscall_number, arg0, ik);
						  for(yi=0;yi<ik && yi<100;yi++)
						 {
							sprintf(tt_str,"  %6d [%6d]",  fds[yi].data.fd, fds[yi].events);
							strcat(f_str, tt_str);
						 }
						  strcat(f_str, "\n");
						  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
						  fflush(wstream_mem[0]);
					}
				}
			}*/
		}
	}
	 //Intercept storage I/O requests; //1/29/2019;
	else
	{
		inter_f =  Is_storage(syscall_number);
	}

    //2019.12.5;
	int idx = 0;

	 if(inter_f) {
		
		//concurrent_ios ++;

		int i=0;

		//int idx = 0;

		read_num++;

		 //Use socket id to categorize I/O requests; //1/29/2019;
		 if(NET_ID_F)
		 {
			    //Tell if the system call is ppoll-related or epoll I/O receiving; //3/26/2019;
			  if(inter_f<PPOLL_D)
			 {
					tid = fd_id;

					 //if(!tell_socket_quality(fd_id, 1))
					 //		 return 1;
			 }
			  else if(inter_f==PPOLL_D)
			  {
					//PPOLL_D handing;
					 struct pollfd * fds = (struct pollfd *)arg0;
					  fd_id = fds[0].fd;
					  tid = fd_id;

					  int ik  = *result;

					   if(PPOLL_PNT==1)
						{
							   char f_str[256];

						        ppoll_anum++;
							    if(ik>1)
										ppoll_mnum++;

								if(ppoll_anum > 10000)
							  {
									float ra = (float)ppoll_mnum/(float)ppoll_anum;
									sprintf(f_str,"\n>> ppoll_anum: %08d   ppoll_mnum: %08d   ra: %f", ppoll_anum, ppoll_mnum, ra);
									//fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
									//fflush(wstream_mem[0]);
									//fwrite(f_str,1,strlen(f_str),wstream_interface[0]);
									//fflush(wstream_interface[0]);
									ppoll_anum = 0;
									ppoll_mnum = 0;
							  }
						}


					 // if(!tell_socket_quality(fd_id, 0))
						//  return 1;
			  }
			  else if(inter_f==EPOLL_D)
			  {
				  //EPOLL_D handing;
					struct epoll_event * fds = (struct epoll_event *)arg1;
					 if(fds!=NULL)
					  {
							  int yi = 0;
							  int ik  = *result;
							  
							  //If the first fd is invalid, just let it pass; 2019.4.3
							  fd_id = fds[0].data.fd;
							  tid = fd_id;
							  if(!tell_socket_quality(fd_id, 1) || fds[0].events!=EPOLLIN)
										 return 1;
							   
							   //2019.4.3;  PPOLL and RECV follow the original processing while EPOLL 
							   //is required to address multiple arrival requests at the same system call.
							  //During normal running, it's required to filter invalid sockets; 2019.4.3
							   if(data_rec_f==1)
							   {
								    if(check_FD(fd_id)!=1 || fds[0].events!=EPOLLIN)
										return 1;

									 epoll_anum++;

								      int active0 = 1;
								      int idx0 = get_fd_idx(fd_id);
									  //Tell if it is active; 2019.4.3
									  if(flow_id_arr[idx0].req_quota <= 0)
										  active0 = 0;
									  //Statistics for events indexed 0; 
										update_it_val(idx0, file_addr/1024, 1);
									
									/////////////////////////////////////////////////////
									  char f_str[4096];
									  char tt_str[32];
									  /////////////////////////////////////////////////////

									  for(yi=1;yi<ik && yi<256;yi++)
									  {

											  int xfd_id = fds[yi].data.fd;
											  //Tell if it is a logged socket; 2019.4.3
											  if(check_FD(xfd_id)==1 && fds[yi].events==EPOLLIN)
											  {
													int xidx = get_fd_idx(xfd_id);

													/////////////////////////////////////////////////////
												   if(yi==1)
												  {
														 if(EPOLL_PNT==1)
														  {
															    if(ik>=3)
																		epoll_mnum++;

																if(epoll_anum > 100000)
															  {
																	float ra = (float)epoll_mnum/(float)epoll_anum;
																	sprintf(f_str,"\n>> epoll_anum: %08d   epoll_mnum: %08d   ra: %f", epoll_anum, epoll_mnum, ra);
																	fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
																	fflush(wstream_mem[0]);
																	epoll_anum = 0;
																	epoll_mnum = 0;
															  }
														  }

														 if(EPOLL_PNT==2)
															sprintf(f_str,"\n>> u0: %06d", idx0);
												  }
												  /////////////////////////////////////////////////////
													
													/////////////////////////////////////////////////////
													 if(EPOLL_PNT==2)
												   {
														sprintf(tt_str,"  u%d: %06d",  yi, xidx);
														strcat(f_str, tt_str);
												   }
													/////////////////////////////////////////////////////

													 //Let the epoll wait pass only if it involves an event from an active user connection; 2019.4.3
													 if(flow_id_arr[xidx].req_quota > 0)
													  {
															if(active0<=0)
														   {
																fd_id = xfd_id;
																tid = fd_id;
																active0 = 1;

																/////////////////////////////////////////////////////
																 if(EPOLL_PNT==2)
															   {
																	sprintf(tt_str,"  [x %06d]",  xidx);
																	strcat(f_str, tt_str);
															   }
																/////////////////////////////////////////////////////
															}
															else
																flow_id_arr[xidx].req_quota--;
													  }
													//Statistics for events indexed from 1 to n; 
													update_it_val(xidx, file_addr/1024, 1);
													
													/////////////////////////////////////////////////////
													if(EPOLL_PNT==2)
												  {
														fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
														fflush(wstream_mem[0]);
												  }
													/////////////////////////////////////////////////////
											  }
									  }
							   }
					  }
			  }
		 }

		 if(THREAD_ID_F)
		{
			 if(!NET_ID_F || inter_f==PPOLL_D) Invoke_FD(tid, 1); //2020.7.17 add if(!NET_ID_F) add inter_f==PPOLL_D, make MySQL work;
			 idx = get_fd_idx(tid);
		}
		 else
		{
			 //if(!NET_ID_F) Invoke_FD(fd_id, 1); //2020.7.17 add if(!NET_ID_F)
			 if(!NET_ID_F || inter_f==PPOLL_D) {
				 Invoke_FD(fd_id, 1); //2020.7.17 add if(!NET_ID_F) 2020.9.18 add inter_f==PPOLL_D, make MySQL work;
				  //print; //////////////////////////////////////////////////////////////////////////////////////////////////////////
				if(print_class<=0)
				{
					  char f_str[128];
					  sprintf(f_str,"{%d, %d, %s, %d}\n"
											 ,idx, inter_f, flow_id_arr[idx].ip_str, flow_id_arr[idx].port);
					  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
					  fflush(wstream_mem[0]);
				}
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			 }
			idx = get_fd_idx(fd_id);
		}
		
		if(idx < MAX_FD_NUM && idx>0)
		{
			//update net info; 2019.2.26;
			//if(flow_id_arr[idx].port<=0)
			 if(NET_ID_F)
			{
				 socket_ana_foo(fd_id, flow_id_arr[idx].ip_str, &flow_id_arr[idx].port);

				 //print; //////////////////////////////////////////////////////////////////////////////////////////////////////////
				if(print_class<=0)
				{
					  char f_str[128];
					  sprintf(f_str,"{%d, %d, %s, %d}\n"
											 ,idx, inter_f, flow_id_arr[idx].ip_str, flow_id_arr[idx].port);
					  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
					  fflush(wstream_mem[0]);
				}
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}

			//Recording I/O requests; 2018.12.19
			//if(data_rec_f==1 || tail_measure==1)
			{
				//Not dealing with EPOLL case; 2019.4.3
				if(THREAD_ID_F || (NET_ID_F && inter_f<EPOLL_D))
					    if(inter_f==PPOLL_D){
					        //total IO statistics for 10-sec interval throughput; 2021.2.19;
							req_tot_all += 1.0;
							update_it_val(idx, file_addr/1024, 1); //Make MySQL work; 2020.9.18;
							//The type of the target server application; 1: MySQL 2021.2.19;
							if(app_type==0)   {
								app_type = 1;
								char p_str[128];
							    sprintf(p_str,"\n{Target DB: MySQL %d}\n", app_version);
							    fwrite(p_str,1,strlen(p_str),wstream_mem[0]);
							    fflush(wstream_mem[0]);
							}
				        }
				        else{
							update_st_val(idx, file_addr/1024);
							//The type of the target server application; 1: MongoDB 2021.2.19;
						    if(app_type==0)  {
								app_type =2;
								//To check the version of the target DB; 2021.2.20;
								check_db_version(app_type);
								char p_str[128];
							    sprintf(p_str,"\n{Target DB: MongoDB %d}\n", app_version);
							    fwrite(p_str,1,strlen(p_str),wstream_mem[0]);
							    fflush(wstream_mem[0]);
							}
						}

						 //print; //////////////////////////////////////////////////////////////////////////////////////////////////////////
						if(print_class<=0)
						{
							  char f_str[128];
							  sprintf(f_str,"{%d, %d, %s, %d}\n"
													 ,idx, inter_f, flow_id_arr[idx].ip_str, flow_id_arr[idx].port);
							  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
							  fflush(wstream_mem[0]);
						}
						///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}

			 //the number of concurrent thread within 250 ms;//9/8/2018;
			 if(THREAD_ID_F)
				 set_fd_con_threads(tid);
			 else
				set_fd_con_threads(fd_id);

			 //int dev_q = get_diskstats_io(DEV);
			 int dev_q = 0;

			  long    currpos = 0; 

			  if(!NET_ID_F)
			{
					currpos = lseek(fd_id, 0, SEEK_CUR); 

					//Distinct file names;  /11/5/2018;
					ana_file_id(tid, fd_id);

					//Set up file IDs for each correlated threads 2018.11.5;
					add_file_id_th(tid, fd_id);
			}

			//Set up thread IDs for each correlated users; 2020.3.29;
            add_thread_id_th(idx, th_id);

             //buffer the requests with the same address; 10/8/2018;
			//if(data_rec_f==1 && record_reqs==1)
			//		buf_req_same_addr(idx, file_addr, currpos, tid);
			
			//Run the thread or sleep it //APP-RSS 2018.10.22;
			if(!disable_apples && eff_flag>0)
			{
					run_thread(idx);
			}
		}
		
	   //Statistics; 2019.1.9;
		pthread_rwlock_wrlock(&ctlock);
		//Time interval controlling; 2018.8.19
		if(time_init)
		{
			 sc_gettime(&time_us);
			 time_init = 0;
		}
		else
		{
			struct timeval t;
			sc_gettime(&t);
			//tdiff = utime_since(&time_us, &t);
			//2019.1.9 change to ms;
			tdiff = mtime_since(&time_us, &t);
		}


         //2019.1.9 change to ms, every 100 ms; 
		if(tdiff > CTL_T_NUM/1000)
		{
				float mutil = 0;
				float ss = 0;
				float  r_io_ave = 0;
				float  w_io_ave = 0;
				float  r_bw_ave = 0;
				float  w_bw_ave = 0;
				float  rw_io_ave = 0;
				float  rw_bw_ave = 0;

				int ss_i = 0;

				int i_f = get_util_d(&ver_v, &mutil, &dd, &ss, &r_io_ave, &w_io_ave, &r_bw_ave, &w_bw_ave, &rw_io_ave, &rw_bw_ave);

				//Recording the service time obtained under the baseline environment;//9/20/2018;
				
				//Get concurrency; 2018.12.27;
				//show_thread_concurrency(idx);

				 ///////////////////////////////////////////////////////////////////////////////////////////////////////////
			if(0)
			{
               //Disabled at 8/21/2018;
			  char f_str[512];
			  struct timeval e;
		      sc_gettime(&e);
			   //  (%08d, %08d, %08d, %08d, %08d) arg1, arg2, arg3, arg4, arg5, 
			   sprintf(f_str,"[S  fd : %05d  tn: %05d  td: %08d]  (%08d, %08d) >>  s_v = %06d  actives = %08d  it = %08d  concurrent_ios = %06d  dd = %08.2f  base_ss = %06.2f  ss_ratio = %06.2f  ss = %06.2f  threshold_q = %08d\n"
				                     , fd_id,  fd_id_ptr, tid, e.tv_sec, e.tv_usec, s_v, active_thread_num, flow_id_arr[idx].it_val, concurrent_ios, dd,  base_ss, ss_ratio, ss, threshold_q);
				fwrite(f_str,1,strlen(f_str),wstream_que[i]);
				fflush(wstream_que[i]);
			}
				///////////////////////////////////////////////////////////////////////////////////////////////////////////

				//APP-RSS 2018.10.22;
				int sh_can = should_run_sched();

				//2019.1.1 All the managed threads are ready;
				 int s_flag = should_run_experiment();

				//The lock for threads; //9/28/2018;
				//pthread_rwlock_wrlock(&ctlock);

				if(sh_can > 0 && s_flag > 0)
			   {
					//The lock for threads; //9/28/2018;
					//pthread_rwlock_wrlock(&ctlock);

					if(sched_run_once>0)
				   {
						//Tell if we need to control the thread; 2018.11.5
						poll_thread_ctl_info();
						get_thread_con(16);
						sched_run_once = 0;
						//2019.1.1
						sctl_flag = 1;
				   }
				    //The lock for threads; //9/28/2018;
					//pthread_rwlock_unlock(&ctlock);

				   //thread_scheduler(idx);

					if(!data_rec_f /*&& opt_finished()*/)
				   {
						eff_idx++;
						if(eff_idx>eff_delay)
					   {
								/////////////////////////////////////////////////////////////////////////////////
							//starting clock for 10-sec interval throughput; 2020.3.22;
						   if(eff_flag<=0){
								sc_gettime(&istart);
								req_tot_all = 0.0;
									//////////////////////////////////////////////////////////////////////////
									char str_linex[64];
									sprintf(str_linex, "\nInit istart: req_tot_all=%f\n"
												, req_tot_all);
											fwrite(str_linex,1,strlen(str_linex),wstream_mem[0]);
											fflush(wstream_mem[0]);
									////////////////////////////////////////////////////////////////
						   }
							/////////////////////////////////////////////////////////////////////////////////
							eff_flag = 1;
							if(eff_flag==1 && eff_idx>= eff_delay+STA_CYCLE*(1000000/CTL_T_NUM)) eff_flag++;
					   }
				   }

                   if(!data_rec_f && opt_finished() && eff_flag>0)
				   {
					   struct timeval e;
						sc_gettime(&e);
						unsigned long long ttu = utime_since(&pre_point, &e);
						if(ttu>=10000000)
						{
							//Read user-centric priority configurations; 2019.3.6
							read_pri_sig();
							data_rec_f = 1;
							char str_line[64];
							//The start time for throughput statistics (ms); 2018.11.12;
							//sta_start_time = ( e.tv_sec%1000000) * 1000 + e.tv_usec/1000;
							sta_start_ms = e.tv_usec/1000;
							sta_start_time = e.tv_sec;
							//sta_start_time *= 1000;
							//sta_start_time +=  e.tv_usec/1000;
							//Recording system starting clock; 2020.2.24
							sc_gettime(&estart);
							sprintf(str_line, "Recording app_cs_num = %d  data_rec_f = %d  sctl_flag = %d  (%08d, %08d) timeline: (%08d, %08d)  fd_id_ptr: %d\n"
								, app_cs_num, data_rec_f, sctl_flag, e.tv_sec, e.tv_usec, sta_start_time, sta_start_ms, fd_id_ptr);
							fwrite(str_line,1,strlen(str_line),wstream_mem[0]);
							fflush(wstream_mem[0]);
						}
				   }
			   }

               //2019.1.1;
			   //Get the number of managed threads;
				int m_n = get_thread_man();
			   if(m_n > 0)
			  {
					   thread_scheduler(idx, 0);
			  }
				
			    //Recording I/O requests;
				if(data_rec_f==1)
			   {
						//2018.12.13 to decide when to run als control;
						//Get average I/O completions; 2019.8.28;
						get_ave_speed();
						als_ctl = read_als_sig();
						pnt_FD_sta(1);
			   }

			   //Clean visiting times; 8/21/2018;
				clean_visits_rec();

				if(last_dd > 0 
			 && ver_v != last_ver_v 
			&& sh_can > 0 
			&& s_flag > 0)
			   {

				//General logic for optimization;
				 //opti_algo_logic(rw_bw_ave, dd, opt_mode_set);

				 //P optimization; 2020.3.21;
				//concurrency_opt(rw_bw_ave, dd, opt_mode_set);

				//Control law  2019.8.26;
				 //control_law(rw_bw_ave, dd, ss, eff_flag);
				
				   last_ver_v = ver_v;
			   }

			   last_dd = dd;

			    //The lock for threads; //9/28/2018;
				//pthread_rwlock_unlock(&ctlock);

				read_num = 0;

				//Time interval controlling; 2018.8.19
				sc_gettime(&time_us);

				//Clean visiting times; 8/21/2018;
				//clean_visits_rec();

				//the number of concurrent thread within 250 ms;//9/8/2018;
				clear_con_threads();


				//Mid-term statistical interval, every 10 * 100ms;//8/26/2018;
				sta_mid_idx ++;
				if(sta_mid_idx>=CTL_M_NUM)
			   {
						//Efficiency control unit for fairness; 2019.4.18;
						eff_fairness_guarantee(1);
						sta_mid_idx = 0;

					////////////////////////////////////////////////////////////////
					//2020.7.16 Output throughput statistics to interface;
					/*char str_linex[128];
					double thpt_target = 0.0;
					double thpt_present = 0.0;
					//2020.7.16  Thoughput allocation target based on the estimation for tail latency and throughput SLOs and the current actual throughput;
					if(c_op_finished){
						thpt_target_current(&thpt_target, &thpt_present);
						lseek(interface_handle[0], 0L, SEEK_SET);
						sprintf(str_linex, ",%d,%8.3f,%8.3f\n", sta_mid_idx, thpt_target, thpt_present);
						fwrite(str_linex,1,strlen(str_linex),wstream_interface[0]);
						fflush(wstream_interface[0]);
					}*/
					////////////////////////////////////////////////////////////////////////
			    }

				//Long-term statistical interval;;//8/26/2018;
				sta_long_idx ++;

				if(sta_long_idx>=CTL_L_NUM)
				{
					//////////////////////////////////////////////////////////////////////////
					char str_linex[128];
					////////////////////////////////////////////////////////////////

					 if(!c_op_finished){
					 //if(1) {//TEST 2022.1.22;
						//total IO statistics for 10-sec interval throughput; 2020.3.22;
						if(i_sta_index>0){
							i_sta_index--;
							req_tot_all = 0;
							last_req_tot_all = 0;
							last_period = 0;
							min_thpt_n = 9999999;
							sc_gettime(&istart);
							/////////////////////////////////////////////////////////////
							sprintf(str_linex, "\nSkipping i_sta_index: %d\n"
									, i_sta_index);
								fwrite(str_linex,1,strlen(str_linex),wstream_mem[0]);
								fflush(wstream_mem[0]);
							/////////////////////////////////////////////////////////////
						}else{
							long long period = mtime_since_now(&istart);
							double this_thpt_n = (1000.0 * (req_tot_all - last_req_tot_all))/(double)(period - last_period);
							//for LL state performance profiling; 2020.8.30;
							//double sysput = sys_LL_xput * tot_ratio_LL + (1.0 - tot_ratio_LL) * sys_HL_xput;
							/*double sysput = sys_LL_xput;
							if(this_thpt_n < sysput)
								this_thpt_n = sysput;*/
							xput_tot_all += this_thpt_n;
							////////////////////////////////////////////////////////////////////
							if(this_thpt_n < min_thpt_n) min_thpt_n = this_thpt_n;
							last_period = period;
							last_req_tot_all = req_tot_all;
								//////////////////////////////////////////////////////////////
								//computing SD(latency)/Mean(latency);
								int i=0, j=0;
								double max_ga = 0.0;
								double min_ga = 10000.0;
								double ave_ga = 0.0;
								int cu = 0;

								for(i=1;i<=fd_id_ptr;i++){
										if(is_active(fd_id_list[i]) && flow_id_arr[i].sched_avoid_f == 2 && is_user_priviliged(i)){
												cu++;
												double ga = gamma_val(i);
												ave_ga += ga;
												if(ga > max_ga)
													max_ga = ga;
												if(ga < min_ga)
													min_ga = ga;
										}
								}

								if(cu>0){
									ave_ga /= cu;
								}
								/////////////////////////////////////////////////////////////
							sprintf(str_linex, "\nga: [   %4.2f,	%4.2f,	%4.2f   ]  period : %lld  tot: %8.3f  txt: %8.3f  min: %8.3f \n"
									, ave_ga,  ave_ga - min_ga, max_ga -  ave_ga , period, req_tot_all, this_thpt_n, min_thpt_n);
								fwrite(str_linex,1,strlen(str_linex),wstream_mem[0]);
								fflush(wstream_mem[0]);
							/////////////////////////////////////////////////////////////
							if(period > sample_times * 10000 || i_first_sta>0) {
							//if(period > 30000 || i_first_sta>0) {
							//if(period > 90000 || i_first_sta>0) {
							//if(period > 150000 || i_first_sta>0) {
								if(period > 0.1){
									double thpt_n = (1000.0 * req_tot_all)/(double)period;
									//2020.8.30;
									//if(thpt_n < xput_tot_all/sample_times)
									//	thpt_n = xput_tot_all/sample_times;
									xput_tot_all = 0.0;
									/////////////////////////////////////////
									//P optimization; 2020.3.21;
									concurrency_opt(thpt_n, min_thpt_n, 5, opt_mode_set);
									if(i_first_sta>0) i_first_sta = 0;
									i_sta_index = i_sta_intervals;
								}
							}
						}
						////////////////////////////////////////////////////////////////
					 }

					//Read user-centric priority configurations; 2019.3.6
					read_pri_sig();
					//Clean long-term visiting times; 8/26/2018;
					clean_long_visits_rec();
					//ctl_central_val = 0; //allowing continuous statistics;10/21/2018;
					sta_long_idx = 0;
				}
		}

		pthread_rwlock_unlock(&ctlock);
        
		return 1;
	} else {
		/*
		 * Ignore any other syscalls
		 * i.e.: pass them on to the kernel
		 * as would normally happen.
		 */
		  //Use socket id to categorize I/O requests; //1/29/2019;
		 if(NET_ID_F)
		 {
			
				 //Tell if a request has been completed; //12/5/2019;
				inter_f = Is_net_send(syscall_number);
				
				if(inter_f){

					Invoke_FD(fd_id, 1);
			        idx = get_fd_idx(fd_id);

					if(idx < MAX_FD_NUM && idx>0)
			       {
						//total IO statistics for 10-sec interval throughput; 2020.3.22;
						req_tot_all += 1.0;
						//Running status 1: high load (HL); 0: low load (LL); //2020.8.12;
						 io_sta_status();
						//pthread_rwlock_wrlock(&ctlock);
						update_it_val(idx, file_addr/1024, 0);
						 //buffer the requests with the same address; 10/8/2018;
						if(data_rec_f==1 && record_reqs==1)
								buf_req_same_addr(idx, file_addr, 0, idx);
						//pthread_rwlock_unlock(&ctlock);
				}
			}
		 }
		return 1;
	}
}

void func(int x)
{
	sctl_flag = 0;
}

void alarm_handle(int sig){    
	tb_scheduler();
}   

static __attribute__((constructor)) void
init(void)
{
	//RW lock Initialization; 2018.12.7;
	pthread_rwlock_init(&rwlock, NULL);
	pthread_rwlock_init(&ctlock, NULL);
	pthread_rwlock_init(&stlock, NULL);
	pthread_rwlock_init(&xtlock, NULL);
	//Initialization; 2018.12.6;
     fd_inv_init();
	  //To check the version of the target DB; 2021.2.20;
	 //Read critical resource configurations; 2018.11.5
      read_critical_cfg();

	//predicting I/O depth 9/9/2018;
	open_max_util();
	open_diskstats_io();

	 //To check the version of the target DB; 2021.2.20;
	 //Read critical resource configurations; 2018.11.5
     // read_critical_cfg();
	//app_type = 1;
	// check_db_version(app_type);
	 memset(db_str, 0, 64);
	 if(app_type==1)
		 sprintf(db_str, "MySQL %d", app_type);
	 else if((app_type==2))
		 sprintf(db_str, "MongoDB %d", app_type);
	 else
		 sprintf(db_str, "No_supported_DB");

	open_doc();
	//2018.12.13 to decide when to run als control;
     open_als_sig();
	 int als_ctl = read_als_sig();
	 //2019.8.29 Clear history data;
     open_his_sig(1);

	 //For P/L initial settings;
     open_P_L_set();

	 init_flow_arr();
	 init_buf();

	//initialization;
    init_cir_queue();

	//latency slos input;
	lat_slo_input();

	 //Get thread id;
	 if(noctl_tid<=0)
		noctl_tid = (int)syscall(186);

	//print; /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  char f_str[512];
	  struct timeval e;
      sc_gettime(&e);
	  sprintf(f_str,"Initialization (%08d, %08d) >>  noctl_tid = %04d   als_ctl = %04d  running in moderunning in mode[(database: %s, version:%d) (L_target: %d, P_target: %d)  eff_delay:%d  disable_apples:%d  control_interval: %d  expect_users: %d  fairness_f: %d  fairness_ub: %d  opt_run: %d]\n"
		                     , e.tv_sec, e.tv_usec, noctl_tid, als_ctl, db_str, app_version, DATA_SET, thread_con, eff_delay, disable_apples, CTL_T_NUM, expect_users, fairness_f, fairness_high_b, opt_run);
	  fwrite(f_str,1,strlen(f_str),wstream_mem[0]);
	  fflush(wstream_mem[0]);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

     //Read critical resource configurations; 2018.11.5
      //read_critical_cfg();

	  //Read user-centric priority configurations; 2019.3.6
      open_pri_sig();

	  //Need optimization or not; 1: run optimization; 0: don't need run;
       if(!opt_run) {
	   //if(1){  //TEST 2022.1.22;
		   set_opt_flag(1,1,1);
		   c_op_finished = 1; //2020.8.24;
	   }
		
	   //Token bucket algorithm; 2019.3.11;
	   if(tb_apples==1)
		{
			signal(SIGALRM,alarm_handle);
			set_time();
		}

	 //signal(SIGINT,func);
	// Set up the callback function
	intercept_hook_point = hook;
}
